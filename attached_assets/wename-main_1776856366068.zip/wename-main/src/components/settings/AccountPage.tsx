/**
 * AccountPage.tsx
 * ─────────────────────────────────────────────────────────────────────────────
 * Shows the user's account status and the primary auth entry point.
 *
 * AUTH ENTRY POINT:
 *   The "Sign in / Sign up" button here is the main way users start auth.
 *   It opens the AuthModal — nothing else in the app auto-triggers auth.
 *
 * TABLE MAPPING:
 *   authUser.email → auth.users.email (displayed to signed-in users)
 */

import { LogOut, Trash2, Shield, CheckCircle2, Mail, AlertCircle } from 'lucide-react';
import { SubPageHeader } from './SubPageHeader';
import { useAuth } from '../../context/AuthContext';
import { signInWithGoogle, signInWithEmailMagicLink } from '../../services/authService';
import { useState } from 'react';

interface AccountPageProps {
  onBack: () => void;
}

export function AccountPage({ onBack }: AccountPageProps) {
  const {
    isAuthenticated,
    authUser,
    signOut,
    deleteAccount,
  } = useAuth();
  const [signingOut, setSigningOut] = useState(false);
  const [deletePending, setDeletePending] = useState(false);
  const [deleteError, setDeleteError] = useState('');
  const [googleLoading, setGoogleLoading] = useState(false);
  const [googleError, setGoogleError] = useState('');
  const [email, setEmail] = useState('');
  const [emailLoading, setEmailLoading] = useState(false);
  const [emailError, setEmailError] = useState('');
  const [emailSent, setEmailSent] = useState(false);

  async function handleGoogleSignIn() {
    setGoogleLoading(true);
    setGoogleError('');
    try {
      await signInWithGoogle();
    } catch {
      setGoogleError('Google sign-in failed. Please try again.');
      setGoogleLoading(false);
    }
  }

  async function handleEmailSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      setEmailError('Please enter a valid email address.');
      return;
    }
    setEmailError('');
    setEmailLoading(true);
    try {
      await signInWithEmailMagicLink(email.trim());
      setEmailSent(true);
    } catch (err: unknown) {
      setEmailError(err instanceof Error ? err.message : 'Something went wrong. Please try again.');
    } finally {
      setEmailLoading(false);
    }
  }

  async function handleSignOut() {
    setSigningOut(true);
    await signOut();
    setSigningOut(false);
  }

  async function handleDeleteAccount() {
    if (!window.confirm('Are you sure? This permanently deletes all your data and cannot be undone.')) return;
    setDeletePending(true);
    setDeleteError('');
    try {
      await deleteAccount();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Account deletion is not yet available.';
      setDeleteError(msg);
    } finally {
      setDeletePending(false);
    }
  }

  return (
    <div className="flex-1 min-h-0 flex flex-col bg-parchment overflow-y-auto">
      <SubPageHeader title="Account" onBack={onBack} />

      <div className="flex-1 px-4 pb-10 pt-2 space-y-5">

        {/* ── Auth status card ─────────────────────────────────────────────── */}
        {isAuthenticated && authUser ? (
          <div className="bg-card rounded-2xl border border-border/60 shadow-sm px-4 py-5 space-y-3">
            <div className="flex items-center gap-3 pb-3 border-b border-border/50">
              <div className="w-10 h-10 rounded-full bg-grass/10 flex items-center justify-center">
                <CheckCircle2 size={18} className="text-grass" />
              </div>
              <div>
                <p className="font-display font-bold text-foreground text-sm">Signed In</p>
                <p className="text-xs text-muted-foreground font-display">{authUser.email}</p>
              </div>
            </div>
            <p className="text-sm text-muted-foreground font-display leading-relaxed">
              Your progress is saved and synced across all your devices.
            </p>
          </div>
        ) : (
          <div className="bg-card rounded-2xl border border-border/60 shadow-sm px-4 py-5 space-y-4">
            <div className="flex items-center gap-3 pb-3 border-b border-border/50">
              <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center">
                <Shield size={18} className="text-slate-500" />
              </div>
              <div>
                <p className="font-display font-bold text-foreground text-sm">Guest Mode</p>
                <p className="text-xs text-muted-foreground font-display">Names saved on this device only</p>
              </div>
            </div>

            <p className="text-sm text-muted-foreground font-display leading-relaxed">
              Create a free account to back up your names, sync across devices, and never lose your matches.
            </p>

            {/* Google sign-in — direct, no modal */}
            <button
              onClick={handleGoogleSignIn}
              disabled={googleLoading}
              className="w-full py-3.5 bg-card border border-border/60 text-foreground rounded-xl font-display font-bold text-sm flex items-center justify-center gap-2.5 active:scale-95 transition-all shadow-sm disabled:opacity-60 disabled:active:scale-100"
            >
              {googleLoading ? (
                <span className="animate-pulse font-display text-sm">Connecting to Google…</span>
              ) : (
                <>
                  <GoogleIcon />
                  Continue with Google
                </>
              )}
            </button>

            {googleError && (
              <p className="text-xs text-destructive font-display text-center">{googleError}</p>
            )}

            {/* Divider */}
            <div className="flex items-center gap-3">
              <div className="flex-1 h-px bg-border/60" />
              <span className="font-display text-xs text-muted-foreground">or</span>
              <div className="flex-1 h-px bg-border/60" />
            </div>

            {/* Email sign-in */}
            {emailSent ? (
              <div className="text-center py-2 space-y-1">
                <p className="font-display font-semibold text-sm text-foreground">Check your inbox</p>
                <p className="font-display text-xs text-muted-foreground">
                  We sent a sign-in link to <span className="font-bold text-foreground">{email}</span>
                </p>
              </div>
            ) : (
              <form onSubmit={handleEmailSubmit} className="space-y-2">
                <div className="relative">
                  <Mail size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => { setEmail(e.target.value); setEmailError(''); }}
                    placeholder="Enter your email"
                    disabled={googleLoading || emailLoading}
                    className="w-full pl-10 pr-4 py-3.5 bg-card border border-border/70 rounded-xl font-display text-sm text-foreground placeholder:text-muted-foreground/60 focus:outline-none focus:ring-2 focus:ring-boy/30 focus:border-boy/50 transition-all disabled:opacity-60"
                    autoComplete="email"
                  />
                </div>
                {emailError && (
                  <p className="text-xs text-destructive font-display flex items-center gap-1.5">
                    <AlertCircle size={12} />
                    {emailError}
                  </p>
                )}
                <button
                  type="submit"
                  disabled={googleLoading || emailLoading || !email}
                  className="w-full py-3.5 bg-boy text-white rounded-xl font-display font-bold text-sm flex items-center justify-center gap-2 active:scale-95 transition-all shadow-md disabled:opacity-50 disabled:cursor-not-allowed disabled:active:scale-100"
                >
                  {emailLoading ? (
                    <span className="animate-pulse">Sending sign-in link…</span>
                  ) : (
                    <>
                      <Mail size={15} />
                      Continue with Email
                    </>
                  )}
                </button>
              </form>
            )}
          </div>
        )}

        {/* ── Signed-in actions ────────────────────────────────────────────── */}
        {isAuthenticated && (
          <div className="bg-card rounded-2xl border border-border/60 shadow-sm px-4 divide-y divide-border/50">
            <div className="py-3.5 flex items-center gap-3">
              <Mail size={15} className="text-muted-foreground shrink-0" />
              <div>
                <p className="font-display font-semibold text-sm text-foreground">Email</p>
                <p className="font-display text-xs text-muted-foreground">{authUser?.email}</p>
              </div>
            </div>

            <button
              className="w-full flex items-center gap-3 py-3.5 text-left active:opacity-70 transition-opacity"
              onClick={handleSignOut}
              disabled={signingOut}
            >
              <LogOut size={16} className="text-muted-foreground shrink-0" />
              <span className="font-display font-semibold text-sm text-foreground">
                {signingOut ? 'Signing out…' : 'Sign Out'}
              </span>
            </button>
          </div>
        )}

        {/* ── Danger zone ──────────────────────────────────────────────────── */}
        {isAuthenticated && (
          <div className="pt-2 border-t border-border/50 space-y-2">
            <p className="text-xs font-display font-semibold text-muted-foreground uppercase tracking-wider px-1 mb-3">
              Danger Zone
            </p>
            <button
              onClick={handleDeleteAccount}
              disabled={deletePending}
              className="w-full py-3 rounded-2xl border border-destructive/30 bg-destructive/5 text-destructive font-display font-semibold text-sm flex items-center justify-center gap-2 active:scale-95 transition-all disabled:opacity-60 disabled:active:scale-100"
            >
              <Trash2 size={15} />
              {deletePending ? 'Deleting…' : 'Delete Account'}
            </button>
            {deleteError && (
              <p className="text-xs text-muted-foreground font-display text-center px-2">
                {deleteError}
              </p>
            )}
            {!deleteError && (
              <p className="text-xs text-muted-foreground font-display text-center">
                This permanently deletes all your data and cannot be undone
              </p>
            )}
            <p className="text-xs text-muted-foreground font-display text-center pt-1">
              You can also request deletion at{' '}
              <a
                href="/delete-account"
                target="_blank"
                rel="noopener noreferrer"
                className="text-sky-600 underline underline-offset-2"
              >
                wename.app/delete-account
              </a>
            </p>
          </div>
        )}
      </div>

    </div>
  );
}

function GoogleIcon() {
  return (
    <svg width="17" height="17" viewBox="0 0 24 24">
      <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
      <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
      <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
      <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
    </svg>
  );
}
