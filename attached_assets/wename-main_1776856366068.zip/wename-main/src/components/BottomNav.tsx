import { Heart, Settings } from "lucide-react";

type Tab = "swipe" | "names" | "settings";

interface BottomNavProps {
  active: Tab;
  onTabChange: (tab: Tab) => void;
  isBoy: boolean;
}

export default function BottomNav({ active, onTabChange, isBoy }: BottomNavProps) {
  const activeColor = isBoy ? "text-boy" : "text-girl-pink";

  const tabs: { id: Tab; label: string; icon: React.ReactNode }[] = [
    {
      id: "swipe",
      label: "Swipe",
      icon: <span className="text-base">🦋</span>,
    },
    {
      id: "names",
      label: "Names",
      icon: <Heart className="w-4 h-4 fill-current" />,
    },
    {
      id: "settings",
      label: "Settings",
      icon: <Settings className="w-4 h-4" />,
    },
  ];

  return (
    <div
      className="flex items-center justify-around py-2 border-t border-border/30 relative"
      style={{
        background: 'linear-gradient(to bottom, hsl(38 42% 91%) 0%, hsl(38 45% 93%) 100%)',
        boxShadow: '0 -2px 8px rgba(0, 0, 0, 0.06)'
      }}
    >
      {/* Subtle paper texture overlay */}
      <div className="absolute inset-0 bg-parchment/20 pointer-events-none mix-blend-overlay" />

      {tabs.map((tab) => {
        const isActive = active === tab.id;
        return (
          <button
            key={tab.id}
            onClick={() => onTabChange(tab.id)}
            className={`relative flex flex-col items-center gap-0.5 px-6 py-1 transition-all ${
              isActive ? activeColor : "text-muted-foreground/70"
            }`}
          >
            {/* Active background pill */}
            {isActive && (
              <div
                className="absolute inset-0 rounded-2xl -mx-2 -my-1 transition-all"
                style={{
                  backgroundColor: isBoy
                    ? 'hsla(214, 55%, 42%, 0.08)'
                    : 'hsla(345, 55%, 50%, 0.08)',
                  boxShadow: isBoy
                    ? '0 0 0 1px hsla(214, 55%, 42%, 0.15)'
                    : '0 0 0 1px hsla(345, 55%, 50%, 0.15)'
                }}
              />
            )}

            <div className="relative z-10">
              {tab.icon}
            </div>
            <span className={`relative z-10 text-[11px] font-display font-medium ${
              isActive ? 'opacity-100' : 'opacity-70'
            }`}>
              {tab.label}
            </span>
          </button>
        );
      })}
    </div>
  );
}
