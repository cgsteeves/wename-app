/*
  # Backfill emails from auth.users into public.users and keep them in sync

  ## Problem
  Users who signed in via OAuth or magic link had their email stored in
  auth.users but not copied into public.users.email.

  ## Changes

  ### 1. Backfill
  One-time UPDATE to copy auth.users.email → public.users.email for any
  row where email is currently null but auth.users has one.

  ### 2. Trigger function
  Creates sync_user_email_from_auth() — called by the trigger below.
  On every INSERT or UPDATE to auth.users, if the email changed it is
  written to the corresponding public.users row.

  ### 3. Trigger on auth.users
  Fires AFTER INSERT OR UPDATE OF email ON auth.users.
  Keeps public.users.email in sync with auth.users.email going forward.

  ### Security
  - Function runs as SECURITY DEFINER so the trigger can write to public.users
    regardless of RLS policies.
  - Only updates the email column — no other profile data is touched.
*/

-- ── 1. One-time backfill ─────────────────────────────────────────────────────
UPDATE public.users pu
SET
  email      = au.email,
  updated_at = now()
FROM auth.users au
WHERE pu.id = au.id
  AND au.email IS NOT NULL
  AND (pu.email IS NULL OR pu.email != au.email);

-- ── 2. Trigger function ──────────────────────────────────────────────────────
CREATE OR REPLACE FUNCTION public.sync_user_email_from_auth()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.email IS NOT NULL THEN
    UPDATE public.users
    SET
      email      = NEW.email,
      updated_at = now()
    WHERE id = NEW.id
      AND (email IS DISTINCT FROM NEW.email);
  END IF;
  RETURN NEW;
END;
$$;

-- ── 3. Attach trigger to auth.users ─────────────────────────────────────────
DROP TRIGGER IF EXISTS on_auth_user_email_change ON auth.users;

CREATE TRIGGER on_auth_user_email_change
  AFTER INSERT OR UPDATE OF email
  ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.sync_user_email_from_auth();
