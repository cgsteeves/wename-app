import { ChevronRight } from 'lucide-react';

interface SettingsRowProps {
  icon: React.ReactNode;
  iconBg?: string;
  title: string;
  summary?: string;
  onClick: () => void;
  destructive?: boolean;
}

export function SettingsRow({ icon, iconBg = 'bg-muted', title, summary, onClick, destructive = false }: SettingsRowProps) {
  return (
    <button
      onClick={onClick}
      className="w-full flex items-center gap-3.5 px-4 py-3.5 bg-card rounded-2xl border border-border/60 active:scale-[0.98] transition-transform shadow-sm hover:shadow-md"
    >
      <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${iconBg}`}>
        {icon}
      </div>
      <div className="flex-1 text-left min-w-0">
        <p className={`font-display font-semibold text-sm ${destructive ? 'text-destructive' : 'text-foreground'}`}>
          {title}
        </p>
        {summary && (
          <p className="text-xs text-muted-foreground font-display mt-0.5 truncate">{summary}</p>
        )}
      </div>
      <ChevronRight size={16} className="text-muted-foreground shrink-0" />
    </button>
  );
}

interface SettingsSectionProps {
  children: React.ReactNode;
  label?: string;
}

export function SettingsSection({ children, label }: SettingsSectionProps) {
  return (
    <div className="space-y-2">
      {label && (
        <p className="text-xs font-display font-semibold text-muted-foreground uppercase tracking-wider px-1 mb-1">
          {label}
        </p>
      )}
      <div className="space-y-2">
        {children}
      </div>
    </div>
  );
}
