/**
 * AuthCallback.tsx
 * ─────────────────────────────────────────────────────────────────────────────
 * Handles the /auth/callback route for ALL provider flows:
 *   - Email magic link (OTP / passwordless)
 *   - Google OAuth redirect
 *   - Apple OAuth redirect
 *
 * FLOW:
 *   1. Supabase auth automatically exchanges the URL tokens/code for a session
 *      when this page loads (handled internally by the Supabase JS client).
 *   2. We call getSession() to confirm the session is present.
 *   3. We call finalizeLogin() from authService which:
 *        a. Upserts the row in public.users using auth.users.id
 *        b. Merges any pre-existing guest data
 *        c. Saves the user ID to localStorage
 *   4. We redirect back to the root of the app.
 *
 * EXPO MIGRATION NOTE:
 *   In Expo, this component is replaced by a deep-link handler.
 *   The finalizeLogin() call remains identical — only the session
 *   retrieval method changes (from URL params to Expo AuthSession).
 */

import { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
import { finalizeLogin, consumePostAuthRedirect } from '../../services/authService';

type Status = 'loading' | 'success' | 'error';

export function AuthCallback() {
  const [status, setStatus] = useState<Status>('loading');
  const [errorMsg, setErrorMsg] = useState('');

  useEffect(() => {
    async function handleCallback() {
      try {
        // The Supabase JS client automatically parses the URL hash/query params
        // and exchanges them for a session on page load. We just need to read it.
        const { data, error } = await supabase.auth.getSession();
        if (error) throw error;

        if (!data.session) {
          // Sometimes the session arrives slightly after page load — wait briefly.
          await new Promise((res) => setTimeout(res, 800));
          const { data: retry, error: retryErr } = await supabase.auth.getSession();
          if (retryErr) throw retryErr;
          if (!retry.session) {
            throw new Error('No session found. Your sign-in link may have expired.');
          }
          const u = retry.session.user;
          await finalizeLogin(u.id, u.email ?? '');
        } else {
          const u = data.session.user;
          await finalizeLogin(u.id, u.email ?? '');
        }

        setStatus('success');
        const redirect = consumePostAuthRedirect();
        const destination = redirect ? `/?redirect=${encodeURIComponent(redirect)}` : '/';
        setTimeout(() => window.location.replace(destination), 1000);
      } catch (err: unknown) {
        setErrorMsg(err instanceof Error ? err.message : 'Sign-in failed. Please try again.');
        setStatus('error');
      }
    }

    handleCallback();
  }, []);

  const bgStyle = { backgroundColor: '#faf6f0' };
  const textureStyle = { backgroundImage: 'url(/paper-texture.jpg)', backgroundSize: 'cover' };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-6 relative" style={bgStyle}>
      <div className="absolute inset-0 opacity-20" style={textureStyle} />

      <div className="relative z-10 w-full max-w-xs">
        {status === 'loading' && <LoadingState />}
        {status === 'success' && <SuccessState />}
        {status === 'error' && <ErrorState errorMsg={errorMsg} />}
      </div>
    </div>
  );
}

function LoadingState() {
  return (
    <div className="text-center">
      <div className="w-16 h-16 rounded-2xl bg-white/80 border border-gray-200 shadow-sm flex items-center justify-center mx-auto mb-5">
        <div className="w-6 h-6 border-2 border-sky-400 border-t-transparent rounded-full animate-spin" />
      </div>
      <h2 style={{ fontFamily: 'Georgia, serif', color: '#2d5a1b', fontSize: '22px', fontWeight: 'bold', marginBottom: '8px' }}>
        Signing you in…
      </h2>
      <p style={{ fontFamily: 'system-ui, sans-serif', fontSize: '14px', color: '#888' }}>
        Just a moment while we set things up.
      </p>
    </div>
  );
}

function SuccessState() {
  return (
    <div className="text-center">
      <div className="w-16 h-16 rounded-2xl bg-white/80 border border-gray-200 shadow-sm flex items-center justify-center mx-auto mb-5">
        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#2d5a1b" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
          <polyline points="20 6 9 17 4 12" />
        </svg>
      </div>
      <h2 style={{ fontFamily: 'Georgia, serif', color: '#2d5a1b', fontSize: '22px', fontWeight: 'bold', marginBottom: '8px' }}>
        You're signed in!
      </h2>
      <p style={{ fontFamily: 'system-ui, sans-serif', fontSize: '14px', color: '#888' }}>
        Taking you back to the app…
      </p>
    </div>
  );
}

function ErrorState({ errorMsg }: { errorMsg: string }) {
  return (
    <div className="text-center">
      <div className="w-16 h-16 rounded-2xl bg-red-50 border border-red-200 flex items-center justify-center mx-auto mb-5">
        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#dc2626" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="12" cy="12" r="10" />
          <line x1="12" y1="8" x2="12" y2="12" />
          <line x1="12" y1="16" x2="12.01" y2="16" />
        </svg>
      </div>
      <h2 style={{ fontFamily: 'Georgia, serif', color: '#1a1a1a', fontSize: '22px', fontWeight: 'bold', marginBottom: '8px' }}>
        Sign-in failed
      </h2>
      <p style={{ fontFamily: 'system-ui, sans-serif', fontSize: '14px', color: '#888', marginBottom: '24px' }}>
        {errorMsg || 'Your link may have expired. Please try again.'}
      </p>
      <button
        onClick={() => window.location.replace('/')}
        style={{ width: '100%', padding: '14px', backgroundColor: '#5aabdf', color: 'white', borderRadius: '12px', fontFamily: 'system-ui, sans-serif', fontWeight: 'bold', fontSize: '14px', border: 'none', cursor: 'pointer' }}
      >
        Back to app
      </button>
    </div>
  );
}
