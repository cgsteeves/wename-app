/*
  # Fix name_packs and name_pack_memberships RLS for anon role

  ## Problem
  The app uses a custom users table with IDs stored in localStorage — no Supabase Auth session.
  All client requests therefore run as the `anon` role, but existing SELECT policies only grant
  access to `authenticated`. This causes name_packs to return empty arrays.

  ## Changes
  - Drop the `authenticated`-only SELECT policy on name_packs and recreate it for both anon + authenticated
  - Drop the `authenticated`-only SELECT policy on name_pack_memberships and recreate it for both roles
  - Drop the `authenticated`-only SELECT policy on names and recreate it for both roles
*/

-- name_packs
DROP POLICY IF EXISTS "Anyone can read name packs" ON name_packs;
CREATE POLICY "Anyone can read name packs"
  ON name_packs FOR SELECT
  TO anon, authenticated
  USING (true);

-- name_pack_memberships
DROP POLICY IF EXISTS "Anyone can read pack memberships" ON name_pack_memberships;
CREATE POLICY "Anyone can read pack memberships"
  ON name_pack_memberships FOR SELECT
  TO anon, authenticated
  USING (true);

-- names
DROP POLICY IF EXISTS "Anyone can read names" ON names;
CREATE POLICY "Anyone can read names"
  ON names FOR SELECT
  TO anon, authenticated
  USING (true);
