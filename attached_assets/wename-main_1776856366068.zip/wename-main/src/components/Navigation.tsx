import { Heart, Sparkles, Settings, ThumbsUp } from 'lucide-react';

type Tab = 'swipe' | 'matches' | 'liked' | 'settings';

type NavigationProps = {
  activeTab: Tab;
  onTabChange: (tab: Tab) => void;
};

export function Navigation({ activeTab, onTabChange }: NavigationProps) {
  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-gradient-to-r from-pink-100 via-yellow-100 to-blue-100 border-t-4 border-white shadow-2xl painted-texture">
      <div className="max-w-md mx-auto flex justify-around">
        <button
          onClick={() => onTabChange('swipe')}
          className={`flex-1 flex flex-col items-center py-3 px-4 transition-all ${
            activeTab === 'swipe'
              ? 'text-pink-600 scale-110'
              : 'text-gray-600 hover:text-gray-800'
          }`}
        >
          <Sparkles size={28} strokeWidth={2.5} />
          <span className="text-sm mt-1 font-bold">Swipe</span>
        </button>

        <button
          onClick={() => onTabChange('matches')}
          className={`flex-1 flex flex-col items-center py-3 px-4 transition-all ${
            activeTab === 'matches'
              ? 'text-pink-600 scale-110'
              : 'text-gray-600 hover:text-gray-800'
          }`}
        >
          <Heart size={28} strokeWidth={2.5} />
          <span className="text-sm mt-1 font-bold">Matches</span>
        </button>

        <button
          onClick={() => onTabChange('liked')}
          className={`flex-1 flex flex-col items-center py-3 px-4 transition-all ${
            activeTab === 'liked'
              ? 'text-pink-600 scale-110'
              : 'text-gray-600 hover:text-gray-800'
          }`}
        >
          <ThumbsUp size={28} strokeWidth={2.5} />
          <span className="text-sm mt-1 font-bold">Liked</span>
        </button>

        <button
          onClick={() => onTabChange('settings')}
          className={`flex-1 flex flex-col items-center py-3 px-4 transition-all ${
            activeTab === 'settings'
              ? 'text-pink-600 scale-110'
              : 'text-gray-600 hover:text-gray-800'
          }`}
        >
          <Settings size={28} strokeWidth={2.5} />
          <span className="text-sm mt-1 font-bold">Settings</span>
        </button>
      </div>
    </nav>
  );
}
