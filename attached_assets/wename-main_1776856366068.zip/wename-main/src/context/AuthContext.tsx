/**
 * AuthContext.tsx
 * ─────────────────────────────────────────────────────────────────────────────
 * Provides Supabase auth session state to the whole app.
 *
 * SESSION HANDLING:
 *   - Loads the existing session on mount (supabase.auth.getSession)
 *   - Subscribes to auth state changes (onAuthStateChange)
 *   - Exposes isAuthenticated, authUser, session, authLoading
 *
 * IMPORTANT: This context does NOT auto-open the auth modal.
 *            Auth is only triggered from explicit user actions.
 *
 * EXPO MIGRATION NOTE:
 *   In Expo, replace getSession() with a deep-link-aware session loader.
 *   The rest of the context shape stays the same.
 *
 * AUTH ENTRY POINTS (where the modal is opened):
 *   - AccountPage → "Create Account or Sign In" button
 *   Any other place that calls openAuthModal() explicitly.
 */

import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { Session, User as SupabaseUser } from '@supabase/supabase-js';
import { supabase } from '../lib/supabase';
import { signOut as authSignOut, deleteAccount as authDeleteAccount } from '../services/authService';

interface AuthContextValue {
  session: Session | null;
  authUser: SupabaseUser | null;
  isAuthenticated: boolean;
  authLoading: boolean;
  showAuthModal: boolean;
  openAuthModal: () => void;
  closeAuthModal: () => void;
  signOut: () => Promise<void>;
  deleteAccount: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [showAuthModal, setShowAuthModal] = useState(false);

  useEffect(() => {
    // Load current session on mount
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      setAuthLoading(false);
    });

    // Subscribe to auth state changes (sign-in, sign-out, token refresh, etc.)
    const { data: listener } = supabase.auth.onAuthStateChange((event, newSession) => {
      setSession(newSession);

      // On sign-in or user update, write the email to public.users.
      // This is a lightweight backstop — the full profile upsert happens
      // in finalizeLogin() (authService) after the /auth/callback flow.
      if (newSession?.user && (event === 'SIGNED_IN' || event === 'USER_UPDATED')) {
        const { id, email } = newSession.user;
        if (email) {
          (async () => {
            await supabase.from('users').upsert(
              { id, email },
              { onConflict: 'id', ignoreDuplicates: false }
            );
          })();
        }
      }
    });

    return () => listener.subscription.unsubscribe();
  }, []);

  async function signOut() {
    await authSignOut();
    setSession(null);
  }

  async function deleteAccount() {
    await authDeleteAccount();
    setSession(null);
  }

  return (
    <AuthContext.Provider
      value={{
        session,
        authUser: session?.user ?? null,
        isAuthenticated: !!session,
        authLoading,
        showAuthModal,
        openAuthModal: () => setShowAuthModal(true),
        closeAuthModal: () => setShowAuthModal(false),
        signOut,
        deleteAccount,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
