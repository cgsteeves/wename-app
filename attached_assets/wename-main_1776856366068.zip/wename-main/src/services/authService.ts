/**
 * authService.ts
 * ─────────────────────────────────────────────────────────────────────────────
 * Centralised auth service layer.
 *
 * TABLE RESPONSIBILITIES
 * ──────────────────────
 * auth.users  – Supabase-managed authentication identity.
 *               We never write to this directly; Supabase handles it.
 *               auth.users.id is the canonical user identity.
 *
 * public.users – App profile table.
 *                id MUST equal auth.users.id.
 *                We upsert here after every successful auth event.
 *
 * ARCHITECTURE NOTE (Expo migration)
 * ────────────────────────────────────
 * All Supabase auth calls are isolated here so that when moving to Expo /
 * React Native you only need to swap out the redirect URLs and provider
 * options — the calling components remain unchanged.
 */

import { supabase } from '../lib/supabase';
import { mergeGuestData } from '../utils/guestDataMerge';

const USER_ID_KEY = 'baby_picker_user_id';
export const POST_AUTH_REDIRECT_KEY = 'post_auth_redirect';

export function setPostAuthRedirect(destination: string): void {
  localStorage.setItem(POST_AUTH_REDIRECT_KEY, destination);
}

export function consumePostAuthRedirect(): string | null {
  const value = localStorage.getItem(POST_AUTH_REDIRECT_KEY);
  if (value) localStorage.removeItem(POST_AUTH_REDIRECT_KEY);
  return value;
}

// ─── Provider sign-in ────────────────────────────────────────────────────────

/**
 * Initiates Google OAuth sign-in.
 * Supabase redirects back to /auth/callback after the user authenticates.
 * The actual session and profile upsert happens in AuthCallback.
 */
export async function signInWithGoogle(): Promise<void> {
  await supabase.auth.signInWithOAuth({
    provider: 'google',
    options: {
      redirectTo: `${window.location.origin}/auth/callback`,
    },
  });
}

/**
 * Initiates Apple OAuth sign-in.
 * Supabase redirects back to /auth/callback after the user authenticates.
 */
export async function signInWithApple(): Promise<void> {
  await supabase.auth.signInWithOAuth({
    provider: 'apple',
    options: {
      redirectTo: `${window.location.origin}/auth/callback`,
    },
  });
}

/**
 * Sends a magic-link email via the send-magic-link Edge Function which uses
 * SendGrid to deliver a fully branded email. The link routes to /auth/callback
 * where the session is picked up and the profile is upserted.
 *
 * EMAIL FLOW:
 *   1. User enters email in AuthModal
 *   2. Edge Function generates a magic link via Admin API and sends via SendGrid
 *   3. User clicks link → /auth/callback
 *   4. AuthCallback calls finalizeLogin()
 */
export async function signInWithEmailMagicLink(email: string): Promise<void> {
  const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
  const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

  const response = await fetch(`${supabaseUrl}/functions/v1/send-magic-link`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${supabaseAnonKey}`,
      'Apikey': supabaseAnonKey,
    },
    body: JSON.stringify({
      email,
      redirectTo: `${window.location.origin}/auth/callback`,
    }),
  });

  if (!response.ok) {
    const data = await response.json().catch(() => ({}));
    throw new Error(data.error || 'Failed to send magic link');
  }
}

// ─── Post-auth profile upsert ────────────────────────────────────────────────

/**
 * Called after every successful authentication event.
 *
 * What this does:
 * 1. Upserts a row in public.users using the auth user's ID (never a
 *    random app-generated ID).
 * 2. Merges any pre-existing guest data (swipes, profile settings, matches)
 *    into the authenticated account if a different guest ID was in localStorage.
 * 3. Saves the auth user ID to localStorage so useUser() picks it up.
 *
 * Fields written to public.users:
 *   id           ← auth.users.id  (source of truth)
 *   email        ← auth.users.email
 *   display_name ← auth user metadata if available
 *   updated_at   ← now()
 */
export async function finalizeLogin(userId: string, email: string): Promise<void> {
  const updates: Record<string, unknown> = {
    id: userId,
    updated_at: new Date().toISOString(),
  };

  if (email) updates.email = email;

  // Only set display_name if auth metadata provides one and we haven't already
  // stored one in public.users — we fetch first to avoid overwriting.
  const { data: existingProfile } = await supabase
    .from('users')
    .select('display_name, invite_code')
    .eq('id', userId)
    .maybeSingle();

  if (!existingProfile?.display_name) {
    const { data: authData } = await supabase.auth.getUser();
    const metaName =
      authData?.user?.user_metadata?.full_name ||
      authData?.user?.user_metadata?.name ||
      null;
    if (metaName) updates.display_name = metaName;
  }

  // Generate an invite_code if the profile doesn't have one yet.
  if (!existingProfile?.invite_code) {
    updates.invite_code = Math.random().toString(36).substring(2, 10).toUpperCase();
  }

  // Upsert into public.users — id comes from auth.users.id, never generated here.
  await supabase
    .from('users')
    .upsert(updates, { onConflict: 'id', ignoreDuplicates: false });

  // Merge guest data if the stored guest ID differs from the auth user ID.
  const guestUserId = localStorage.getItem(USER_ID_KEY);
  if (guestUserId && guestUserId !== userId) {
    await mergeGuestData(guestUserId, userId);
  }

  // Persist auth user ID so useUser() loads the correct profile row.
  localStorage.setItem(USER_ID_KEY, userId);
}

// ─── Sign-out ────────────────────────────────────────────────────────────────

/**
 * Signs the user out of Supabase.
 * Does NOT delete any server-side data.
 * The app falls back to guest mode after this call.
 */
export async function signOut(): Promise<void> {
  await supabase.auth.signOut();
}

// ─── Delete account ───────────────────────────────────────────────────────────

export async function deleteAccount(): Promise<void> {
  const { data: { session } } = await supabase.auth.getSession();
  if (!session) throw new Error('Not authenticated');

  const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
  const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

  const response = await fetch(`${supabaseUrl}/functions/v1/delete-account`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${session.access_token}`,
      'Apikey': supabaseAnonKey,
    },
  });

  if (!response.ok) {
    const data = await response.json().catch(() => ({}));
    throw new Error(data.error || 'Failed to delete account');
  }

  localStorage.removeItem(USER_ID_KEY);
  localStorage.removeItem(POST_AUTH_REDIRECT_KEY);
  await supabase.auth.signOut();
}
