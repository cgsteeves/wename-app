/*
  # Add created_by_user_id to names table

  ## Summary
  Adds ownership tracking for user-created names so that a user's manually
  added names are visible to their partner in the swipe deck.

  ## Changes

  ### Modified Tables
  - `names`
    - New column: `created_by_user_id` (uuid, nullable, FK to users.id)
      - Only populated for rows where user_created = true
      - Null for all catalog names

  ## Security Changes
  - Drop the current open "Anyone can read names" SELECT policy
  - Add a new SELECT policy that allows reading a name row if:
      1. It is a catalog name (user_created = false or null), OR
      2. The current user is the creator (created_by_user_id = auth.uid()), OR
      3. The current user's partner created it (creator is the current user's partner_id)
  - Update the existing INSERT policy to require created_by_user_id = auth.uid()
    so ownership is always stamped at creation time

  ## Notes
  - Anonymous / unauthenticated users can still read catalog names (user_created IS NOT TRUE)
  - User-created names with no owner (created_by_user_id IS NULL) are readable by anyone
    to preserve backward compatibility for any orphaned rows
*/

-- 1. Add the ownership column
ALTER TABLE names
  ADD COLUMN IF NOT EXISTS created_by_user_id uuid REFERENCES users(id) ON DELETE SET NULL;

-- 2. Drop the old open read policy
DROP POLICY IF EXISTS "Anyone can read names" ON names;

-- 3. Add a new, scoped SELECT policy
CREATE POLICY "Users can read catalog and owned or partner names"
  ON names FOR SELECT
  USING (
    -- catalog names are always readable
    (user_created IS NOT TRUE)
    OR
    -- the creator can always read their own names
    (created_by_user_id IS NOT NULL AND created_by_user_id = auth.uid())
    OR
    -- partner can read names created by the current user's partner
    (
      created_by_user_id IS NOT NULL
      AND EXISTS (
        SELECT 1 FROM users u
        WHERE u.id = auth.uid()
          AND u.partner_id = names.created_by_user_id
      )
    )
    OR
    -- backward compat: user_created rows with no owner stay visible
    (user_created IS TRUE AND created_by_user_id IS NULL)
  );

-- 4. Drop old insert policies and add a strict one requiring ownership
DROP POLICY IF EXISTS "Anyone can insert names" ON names;
DROP POLICY IF EXISTS "Users can insert user_created names" ON names;

CREATE POLICY "Authenticated users can insert their own user_created names"
  ON names FOR INSERT
  TO authenticated
  WITH CHECK (
    user_created = true
    AND created_by_user_id = auth.uid()
  );
