/*
  # Add accept_partner_invite RPC function

  ## Summary
  Creates a SECURITY DEFINER RPC function that safely performs the bidirectional
  partner linking when a user accepts an invite. This is needed because anonymous
  (guest) users cannot update another user's row via RLS — only their own.

  The function:
  1. Validates the invite token is pending and not expired
  2. Prevents self-joining
  3. Prevents joining if either party already has a partner
  4. Marks the invite as accepted
  5. Sets partner_id on both users atomically

  ## Security
  - SECURITY DEFINER runs with function owner's privileges (bypasses RLS for the link)
  - All validation checks are still enforced inside the function
  - The function is accessible to anon and authenticated roles
*/

CREATE OR REPLACE FUNCTION accept_partner_invite(p_token text, p_joiner_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_invite partner_invites%ROWTYPE;
  v_inviter_partner uuid;
  v_joiner_partner uuid;
BEGIN
  -- Fetch invite
  SELECT * INTO v_invite
  FROM partner_invites
  WHERE token = p_token
    AND status = 'pending'
    AND expires_at > now();

  IF NOT FOUND THEN
    RETURN jsonb_build_object('success', false, 'error', 'This invite link is invalid or has already been used.');
  END IF;

  -- Prevent self-joining
  IF v_invite.inviter_id = p_joiner_id THEN
    RETURN jsonb_build_object('success', false, 'error', 'You cannot join your own invite.');
  END IF;

  -- Check inviter doesn't already have a partner
  SELECT partner_id INTO v_inviter_partner FROM users WHERE id = v_invite.inviter_id;
  IF v_inviter_partner IS NOT NULL THEN
    RETURN jsonb_build_object('success', false, 'error', 'This invite is no longer available.');
  END IF;

  -- Check joiner doesn't already have a partner
  SELECT partner_id INTO v_joiner_partner FROM users WHERE id = p_joiner_id;
  IF v_joiner_partner IS NOT NULL THEN
    RETURN jsonb_build_object('success', false, 'error', 'You are already connected with a partner.');
  END IF;

  -- Mark invite accepted
  UPDATE partner_invites
  SET status = 'accepted', invitee_id = p_joiner_id
  WHERE id = v_invite.id;

  -- Link both users
  UPDATE users SET partner_id = p_joiner_id WHERE id = v_invite.inviter_id;
  UPDATE users SET partner_id = v_invite.inviter_id WHERE id = p_joiner_id;

  RETURN jsonb_build_object('success', true, 'inviter_id', v_invite.inviter_id);
END;
$$;

GRANT EXECUTE ON FUNCTION accept_partner_invite(text, uuid) TO anon, authenticated;
