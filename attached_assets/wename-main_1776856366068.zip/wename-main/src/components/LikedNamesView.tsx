import { useState, useEffect, useRef, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import { Reorder } from 'framer-motion';
import { GripHorizontal, Share2 } from 'lucide-react';
import { shareNameList } from '../utils/shareImage';

interface LikedName {
  id: string;
  text: string;
  gender: string;
}

interface Swipe {
  id: string;
  ranking: number | null;
  names: LikedName;
}

interface LikedNamesViewProps {
  userId: string;
}

export function LikedNamesView({ userId }: LikedNamesViewProps) {
  const [swipes, setSwipes] = useState<Swipe[]>([]);
  const [loading, setLoading] = useState(true);
  const saveTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    loadLikedNames();
  }, [userId]);

  async function loadLikedNames() {
    try {
      const { data: swipeData, error: swipeError } = await supabase
        .from('swipes')
        .select('id, ranking, name_id')
        .eq('user_id', userId)
        .eq('liked', true)
        .order('ranking', { ascending: true, nullsFirst: false })
        .order('created_at', { ascending: false });

      if (swipeError) throw swipeError;
      if (!swipeData || swipeData.length === 0) {
        setSwipes([]);
        return;
      }

      const nameIds = swipeData.map((s: any) => s.name_id);
      const { data: nameData, error: nameError } = await supabase
        .from('names')
        .select('uuid, name, gender')
        .in('uuid', nameIds);

      if (nameError) throw nameError;

      const nameMap = new Map((nameData || []).map((n: any) => [n.uuid, {
        id: n.uuid,
        text: n.name,
        gender: n.gender,
      }]));

      const validSwipes = swipeData
        .filter((swipe: any) => nameMap.has(swipe.name_id))
        .map((swipe: any) => ({
          id: swipe.id,
          ranking: swipe.ranking,
          names: nameMap.get(swipe.name_id) as LikedName,
        }));

      setSwipes(validSwipes);
    } catch (error) {
      console.error('Error loading liked names:', error);
    } finally {
      setLoading(false);
    }
  }

  const saveOrder = useCallback(async (orderedSwipes: Swipe[]) => {
    try {
      const updates = orderedSwipes.map((swipe, index) => ({
        id: swipe.id,
        ranking: index + 1,
      }));

      for (const update of updates) {
        await supabase
          .from('swipes')
          .update({ ranking: update.ranking })
          .eq('id', update.id);
      }
    } catch (error) {
      console.error('Error updating swipe rankings:', error);
      loadLikedNames();
    }
  }, []);

  function handleReorder(newOrder: Swipe[]) {
    setSwipes(newOrder);

    if (saveTimerRef.current) clearTimeout(saveTimerRef.current);
    saveTimerRef.current = setTimeout(() => {
      saveOrder(newOrder);
    }, 600);
  }

  async function handleShare() {
    const namesForShare = swipes.map((swipe) => ({
      name: swipe.names.text,
      gender: swipe.names.gender as 'boy' | 'girl',
    }));

    await shareNameList(
      namesForShare,
      'My Favorite Baby Names',
      `Check out my favorite baby names: ${namesForShare.map(n => n.name).join(', ')}`
    );
  }

  if (loading) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <div className="text-muted-foreground font-display">Loading your liked names...</div>
      </div>
    );
  }

  return (
    <>
      <div className="flex-shrink-0 px-5 pt-5 pb-3">
        <div className="flex items-baseline justify-between mb-1">
          <h1 className="text-2xl font-bold font-display text-foreground">Your Picks</h1>
          <span className="text-sm text-muted-foreground font-display">{swipes.length} {swipes.length === 1 ? 'name' : 'names'}</span>
        </div>
        <p className="text-sm text-muted-foreground font-display mb-3">
          ★ Star your favorites · drag to reorder
        </p>
        <div className="flex gap-2">
          <button
            className="flex-1 border-2 border-dashed border-[hsl(145,45%,55%)] text-[hsl(145,45%,35%)] font-display font-semibold py-3 px-4 rounded-2xl flex items-center justify-center gap-2 text-sm bg-transparent hover:bg-[hsl(145,45%,35%)]/5 transition-colors active:scale-[0.98]"
          >
            <span className="text-base leading-none">+</span>
            <span>Add name</span>
          </button>
          <button
            onClick={handleShare}
            disabled={swipes.length === 0}
            className="bg-card border border-border text-foreground font-display font-semibold py-3 px-5 rounded-2xl flex items-center gap-2 text-sm hover:bg-card/80 transition-colors active:scale-[0.98] shadow-sm disabled:opacity-40 disabled:cursor-not-allowed"
          >
            <Share2 size={15} />
            <span>Share</span>
          </button>
        </div>
      </div>
      <div className="flex-1 min-h-0 overflow-y-auto px-4 pb-2">
        {swipes.length === 0 ? (
          <p className="text-center text-muted-foreground font-display text-sm mt-12">
            No names yet! Start swiping to add some.
          </p>
        ) : (
          <Reorder.Group axis="y" values={swipes} onReorder={handleReorder} className="space-y-1.5 pt-1">
            {swipes.map((swipe, index) => (
              <Reorder.Item
                key={swipe.id}
                value={swipe}
                className={`rounded-lg px-3 py-2 font-display text-base font-medium shadow-sm flex items-center gap-2.5 cursor-grab active:cursor-grabbing relative overflow-hidden ${
                  swipe.names.gender === 'girl'
                    ? 'text-rose-800 border border-rose-200/60'
                    : 'bg-card border border-border text-foreground'
                }`}
                style={swipe.names.gender === 'girl' ? {
                  background: `
                    radial-gradient(ellipse 120% 80% at 85% 60%, rgba(255,182,193,0.55) 0%, transparent 55%),
                    radial-gradient(ellipse 80% 100% at 10% 30%, rgba(255,160,170,0.3) 0%, transparent 50%),
                    radial-gradient(ellipse 60% 70% at 50% 90%, rgba(255,192,203,0.25) 0%, transparent 50%),
                    linear-gradient(135deg, rgba(255,228,225,0.9) 0%, rgba(255,210,215,0.85) 40%, rgba(255,240,242,0.95) 100%)
                  `,
                  boxShadow: '0 1px 4px rgba(200,100,110,0.12), inset 0 1px 0 rgba(255,255,255,0.6)',
                } : undefined}
              >
                <span className={`text-xs font-bold min-w-[20px] ${swipe.names.gender === 'girl' ? 'text-rose-400' : 'text-muted-foreground'}`}>
                  {index + 1}
                </span>
                <span className="flex-1">{swipe.names.text}</span>
                <GripHorizontal size={18} className={`flex-shrink-0 ${swipe.names.gender === 'girl' ? 'text-rose-300' : 'text-muted-foreground'}`} />
              </Reorder.Item>
            ))}
          </Reorder.Group>
        )}
      </div>
    </>
  );
}
