import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

/**
 * public.users — app profile table.
 * id must always equal auth.users.id.
 * Never generate a separate ID in app code.
 */
export type User = {
  id: string;
  email: string | null;
  display_name: string | null;
  baby_last_name: string | null;
  baby_gender: 'boy' | 'girl' | 'either' | null;
  partner_id: string | null;
  invite_code: string;
  onboarding_complete: boolean | null;
  plan_tier: string | null;
  daily_swipe_count: number;
  daily_like_count: number;
  daily_match_count: number;
  usage_last_reset_at: string | null;
  created_at: string;
  updated_at: string | null;
};

export type Name = {
  id: string;
  text: string;
  gender: 'boy' | 'girl';
  pronunciation: string | null;
  origin: string | null;
  meaning: string | null;
  nickname: string | null;
  rank: number | null;
  created_at: string;
  created_by_user_id?: string | null;
};

export type Swipe = {
  id: string;
  user_id: string;
  name_id: string;
  liked: boolean;
  created_at: string;
};

export type Match = {
  id: string;
  name_id: string;
  user_a_id: string;
  user_b_id: string;
  gender: string;
  created_at: string;
  name?: Name;
};

export type NamePack = {
  slug: string;
  display_name: string;
  category: string;
  is_premium: boolean;
  sort_order: number;
};

export type UserSelectedPack = {
  user_id: string;
  pack_slug: string;
  created_at: string;
};

export const DEFAULT_PACK_SLUG = 'top_2000';

export type PartnerInvite = {
  id: string;
  token: string;
  short_code: string;
  inviter_id: string;
  invitee_id: string | null;
  status: 'pending' | 'accepted' | 'expired';
  created_at: string;
  expires_at: string;
};
