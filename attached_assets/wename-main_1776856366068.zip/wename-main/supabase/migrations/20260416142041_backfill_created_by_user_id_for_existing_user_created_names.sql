/*
  # Retroactive backfill: set created_by_user_id for existing user_created names

  ## Summary
  For any existing names where user_created = true and created_by_user_id is NULL,
  we infer the original creator by finding the user who liked that name with the
  earliest swipe timestamp. This recovers ownership for manually added names that
  existed before the created_by_user_id column was added.

  ## Logic
  - names.uuid matches swipes.name_id (both uuid type)
  - For each user_created name, look up all swipes where liked = true, order by
    created_at ASC, and take the first user_id — that user most likely created it.
  - Only update rows where created_by_user_id is still NULL (safe to run multiple times).
  - Names with zero swipes remain NULL and stay visible to all users per backward-compat
    policy defined in the previous migration.

  ## Notes
  - This is a safe, non-destructive UPDATE — no rows are deleted.
  - Idempotent: running again will not overwrite already-set values.
*/

UPDATE names n
SET created_by_user_id = earliest_swipe.user_id
FROM (
  SELECT DISTINCT ON (s.name_id)
    s.name_id,
    s.user_id
  FROM swipes s
  WHERE s.liked = true
  ORDER BY s.name_id, s.created_at ASC
) AS earliest_swipe
WHERE n.uuid = earliest_swipe.name_id
  AND n.user_created = true
  AND n.created_by_user_id IS NULL;
