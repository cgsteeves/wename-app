# Quick Start Guide

Get your Baby Name Picker app running in 3 steps!

## Step 1: Setup Database

1. Go to [Supabase Dashboard](https://supabase.com/dashboard)
2. Click on your project
3. Click **SQL Editor** in the left sidebar
4. Click **New query**
5. Copy and paste the contents of `database-migration.sql`
6. Click **Run** or press Ctrl+Enter

✅ You should see "Success. No rows returned"

### Step 1b: Load Name Data (Choose One)

**Option A: Small test set (40 names)** - Already included in `database-migration.sql` ✅

**Option B: Full name list (1000+ names)** - Recommended!
1. Open `database-seed-names.sql`
2. Copy the SQL
3. Run in Supabase SQL Editor
4. This adds 1000+ boy and girl names from the CSV files

**Option C: Use the Node.js seed script**
```bash
node scripts/seed-names.js
```
This programmatically loads all 1000+ names from both CSV files.

## Step 2: Run the App

```bash
npm run dev
```

Open http://localhost:3000 in your browser

> **⚠️ Getting "supabaseUrl is required" error?**
> Make sure your `.env` file is in the project root with the correct Supabase credentials.
> After adding/updating `.env`, **restart the dev server** (Ctrl+C then `npm run dev` again).
> See [TROUBLESHOOTING.md](TROUBLESHOOTING.md) for more help.

## Step 3: Test It Out

### As First User:
1. App opens → You're automatically created as a user
2. Go to **Settings** tab at bottom
3. Enter your name (e.g., "Alex")
4. Choose baby gender: Boy, Girl, or Don't know yet
5. Click **Save Changes**
6. Go to **Swipe** tab
7. You'll see a name card - try clicking **Yes** ❤️ or **No** 👎

### Invite Your Partner:
1. Go to **Settings** tab
2. Click **Invite Partner** button
3. Click **Copy Invite Link**
4. Open a different browser (or incognito window) to simulate partner
5. Paste the invite link
6. Enter partner's name (e.g., "Jordan")
7. Click **Connect with Partner**

### Create Matches:
1. In first browser (Alex): Go to **Swipe** and click **Yes** on "Oliver"
2. In second browser (Jordan): Go to **Swipe** and click **Yes** on "Oliver"
3. Both users: Go to **Matches** tab
4. You'll see "Oliver" appears as a match! 🎉

## Testing Checklist

- [ ] User auto-created on first visit
- [ ] Can update name and settings
- [ ] Can swipe through names
- [ ] Boy names show blue, girl names show pink
- [ ] Can copy invite link
- [ ] Second user can accept invite
- [ ] Both users can swipe
- [ ] Matches appear when both like same name
- [ ] Reset swipes works
- [ ] Remove partner works

## Troubleshooting

**Problem**: Names don't show up
- **Solution**: Make sure you ran the database migration SQL

**Problem**: Can't connect with partner
- **Solution**: Make sure both users don't already have partners. Go to Settings → Remove Partner first

**Problem**: Matches don't appear
- **Solution**: Make sure both users are connected as partners (check Settings page)

**Problem**: Getting database errors
- **Solution**: Check your `.env` file has correct Supabase credentials

## What's Next?

- **Add more names**: Run INSERT queries in Supabase SQL Editor (see `database-migration.sql`)
- **Customize colors**: See `CUSTOMIZATION.md` for detailed guide
- **Deploy**: Deploy to Vercel for free hosting
- **Add to phone**: Open on mobile, click Share → Add to Home Screen

## Need Help?

Check these files:
- `README.md` - Full documentation
- `CUSTOMIZATION.md` - How to modify features
- `database-migration.sql` - Database setup and queries
