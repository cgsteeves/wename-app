/**
 * PremiumUpgradeModal.tsx
 *
 * Shown when a free user hits a daily usage limit (swipes, likes, or match reveals).
 * Friendly nudge — not aggressive. Matches app's soft pastel design system.
 *
 * Props:
 *   limitType - which limit was hit, used to personalise the subtitle
 *   onClose   - called when user taps "Come back tomorrow"
 *   onUpgrade - called when user taps "Upgrade to Premium"
 */

import { AnimatePresence, motion } from 'framer-motion';
import { X, Infinity, Sparkles, Package } from 'lucide-react';

type LimitType = 'swipe' | 'like' | 'match' | 'discover' | null;

interface PremiumUpgradeModalProps {
  open: boolean;
  limitType: LimitType;
  onClose: () => void;
  onUpgrade: () => void;
}

const FEATURE_LIST = [
  {
    icon: <Infinity size={16} />,
    text: 'Unlimited daily swipes, likes and matches',
  },
  {
    icon: <Package size={16} />,
    text: 'Access to themed name packs (Classic, Arabic, Spiritual, and more)',
  },
  {
    icon: <Sparkles size={16} />,
    text: 'AI name suggestions based on your likes',
  },
];

function subtitleForLimit(limitType: LimitType): string {
  switch (limitType) {
    case 'swipe':
      return "You've used all 30 of your daily swipes. Upgrade to keep discovering names together.";
    case 'like':
      return "You've liked 8 names today — that's your daily limit. Upgrade to keep liking names together.";
    case 'match':
      return "You've seen 3 new matches today. Upgrade to reveal every match the moment it happens.";
    case 'discover':
      return 'Get smarter name suggestions—our AI learns what you like and recommends names with a similar style and vibe.';
    default:
      return "You've reached your daily limit. Upgrade to keep discovering names together.";
  }
}

export function PremiumUpgradeModal({ open, limitType, onClose, onUpgrade }: PremiumUpgradeModalProps) {
  return (
    <AnimatePresence>
      {open && (
        <div className="fixed inset-0 z-[60] flex items-end sm:items-center justify-center">
          {/* Backdrop — clicking does NOT dismiss (closing must be intentional) */}
          <motion.div
            className="absolute inset-0 bg-black/45 backdrop-blur-sm"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          />

          <motion.div
            className="relative w-full max-w-md mx-auto rounded-t-3xl sm:rounded-3xl overflow-hidden shadow-2xl"
            initial={{ y: '100%', opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: '100%', opacity: 0 }}
            transition={{ type: 'spring', stiffness: 340, damping: 36 }}
            style={{
              background: 'linear-gradient(160deg, rgba(255,251,235,0.99) 0%, rgba(255,245,220,0.98) 60%, rgba(255,237,200,0.99) 100%)',
            }}
          >
            {/* Paper texture */}
            <div
              className="absolute inset-0 opacity-25 pointer-events-none"
              style={{ backgroundImage: 'url(/paper-texture.jpg)', backgroundSize: 'cover' }}
            />
            {/* Radial highlight */}
            <div
              className="absolute inset-0 pointer-events-none"
              style={{ background: 'radial-gradient(ellipse at top, rgba(255,255,255,0.5) 0%, transparent 65%)' }}
            />

            <div className="relative z-10 px-6 pt-5 pb-9">
              {/* Drag handle (mobile) */}
              <div className="w-10 h-1 bg-border rounded-full mx-auto mb-5 sm:hidden" />

              {/* Close button */}
              <button
                onClick={onClose}
                className="absolute top-4 right-4 w-8 h-8 flex items-center justify-center rounded-full bg-card/80 text-muted-foreground hover:text-foreground transition-colors"
              >
                <X size={16} />
              </button>

              {/* Sun icon accent */}
              <div className="flex justify-center mb-4">
                <div
                  className="w-16 h-16 rounded-2xl flex items-center justify-center shadow-sm border border-[hsl(42_80%_75%)]"
                  style={{ background: 'linear-gradient(145deg, hsl(42 90% 88%) 0%, hsl(42 85% 82%) 100%)' }}
                >
                  <img src="/like_sun2.png" alt="" className="w-10 h-10 object-contain" />
                </div>
              </div>

              {/* Title */}
              <h2 className="font-hand text-2xl font-bold text-center mb-2" style={{ color: 'hsl(25 50% 30%)' }}>
                Keep going
              </h2>

              {/* Subtitle */}
              <p className="font-display text-sm text-center text-muted-foreground leading-relaxed mb-6 px-2">
                {subtitleForLimit(limitType)}
              </p>

              {/* Feature list */}
              <div className="flex flex-col gap-2.5 mb-7">
                {FEATURE_LIST.map((feature, i) => (
                  <div
                    key={i}
                    className="flex items-start gap-3 rounded-xl px-4 py-3"
                    style={{
                      background: 'rgba(180,140,60,0.07)',
                      border: '1px solid hsl(42 60% 78%)',
                    }}
                  >
                    <div className="mt-0.5 flex-shrink-0" style={{ color: 'hsl(38 70% 40%)', opacity: 0.75 }}>
                      {feature.icon}
                    </div>
                    <p className="font-display text-sm leading-snug text-foreground/80">
                      {feature.text}
                    </p>
                  </div>
                ))}
              </div>

              {/* CTA */}
              <button
                onClick={onUpgrade}
                className="w-full py-3.5 rounded-xl font-display font-bold text-sm text-white flex items-center justify-center gap-2 active:scale-95 transition-all shadow-md"
                style={{ background: 'linear-gradient(135deg, hsl(38 85% 48%) 0%, hsl(32 80% 44%) 100%)' }}
              >
                <Sparkles size={16} />
                Upgrade to Premium
              </button>

              {/* Secondary action */}
              <button
                onClick={onClose}
                className="w-full mt-3 py-3 rounded-xl font-display font-semibold text-sm text-muted-foreground bg-card/60 border border-border/50 active:scale-95 transition-all"
              >
                Come back tomorrow
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
