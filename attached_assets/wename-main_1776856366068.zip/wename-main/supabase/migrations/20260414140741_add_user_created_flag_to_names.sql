/*
  # Add user_created flag to names table

  ## Summary
  Adds a boolean column to distinguish manually entered names from catalog names.

  ## Changes
  - `names` table: new column `user_created` (boolean, default false)
    - true  → name was manually entered by a user; excluded from the swipe pool
    - false → name comes from the official catalog; appears in the swipe pool as normal

  ## Notes
  - Default is false so all existing catalog names are unaffected
  - No RLS changes needed; existing policies cover this column automatically
*/

ALTER TABLE names
  ADD COLUMN IF NOT EXISTS user_created boolean NOT NULL DEFAULT false;
