import { useState, useEffect } from 'react';
import { Users, GripHorizontal, Share2 } from 'lucide-react';
import { supabase, User, Match, Name } from '../lib/supabase';
import { Reorder } from 'framer-motion';
import { shareNameList } from '../utils/shareImage';

type MatchesViewProps = {
  user: User;
};

type MatchWithName = Match & { name: Name };

export function MatchesView({ user }: MatchesViewProps) {
  const [matches, setMatches] = useState<MatchWithName[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadMatches();

    if (!user.partner_id) return;

    const channel = supabase
      .channel(`matches:${user.id}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'matches',
          filter: `user_a_id=eq.${user.id}`,
        },
        () => { loadMatches(); }
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'matches',
          filter: `user_b_id=eq.${user.id}`,
        },
        () => { loadMatches(); }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user]);

  async function loadMatches() {
    if (!user.partner_id) {
      setLoading(false);
      return;
    }

    try {
      setLoading(true);

      const { data: matchData, error: matchError } = await supabase
        .from('matches')
        .select('*')
        .or(`user_a_id.eq.${user.id},user_b_id.eq.${user.id}`)
        .order('ranking', { ascending: true, nullsFirst: false })
        .order('created_at', { ascending: false });

      if (matchError) throw matchError;
      if (!matchData || matchData.length === 0) {
        setMatches([]);
        return;
      }

      const nameIds = matchData.map((m: any) => m.name_id);
      const { data: nameData, error: nameError } = await supabase
        .from('names')
        .select('uuid, name, gender, pronunciation, origin_raw, meaning, nicknames, us_rank')
        .in('uuid', nameIds);

      if (nameError) throw nameError;

      const nameMap = new Map((nameData || []).map((n: any) => [n.uuid, {
        id: n.uuid,
        text: n.name,
        gender: n.gender,
        pronunciation: n.pronunciation ?? null,
        origin: n.origin_raw ?? null,
        meaning: n.meaning ?? null,
        nickname: n.nicknames ?? null,
        rank: n.us_rank != null && /^\d+$/.test(String(n.us_rank)) ? Number(n.us_rank) : null,
        created_at: null,
      }]));
      const enriched = matchData
        .filter((m: any) => nameMap.has(m.name_id))
        .map((m: any) => ({ ...m, name: nameMap.get(m.name_id) as Name }));

      setMatches(enriched as MatchWithName[]);
    } catch (error) {
      console.error('Error loading matches:', error);
    } finally {
      setLoading(false);
    }
  }

  async function handleReorder(newOrder: MatchWithName[]) {
    setMatches(newOrder);

    try {
      const updates = newOrder.map((match, index) => ({
        id: match.id,
        ranking: index + 1,
      }));

      for (const update of updates) {
        await supabase
          .from('matches')
          .update({ ranking: update.ranking })
          .eq('id', update.id);
      }
    } catch (error) {
      console.error('Error updating match rankings:', error);
      loadMatches();
    }
  }

  async function handleShare() {
    const namesForShare = matches.map((match) => ({
      name: match.name.text,
      gender: match.name.gender as 'boy' | 'girl',
    }));

    await shareNameList(
      namesForShare,
      'Our Matched Baby Names',
      `Check out the baby names we both love: ${namesForShare.map(n => n.name).join(', ')}`
    );
  }

  if (!user.partner_id) {
    return (
      <div className="flex-1 min-h-0 overflow-y-auto p-6">
        <h1 className="text-2xl font-bold font-hand text-grass text-center mb-2">Matches</h1>
        <p className="text-center text-muted-foreground font-display text-sm mb-6 px-4">
          Names that both you and your partner have liked. Rank and share them with family or friends.
        </p>
        <div className="flex flex-col items-center justify-center px-6 text-center mt-12">
          <Users size={64} className="text-muted mb-4" />
          <h2 className="text-xl font-bold font-hand text-grass mb-2">
            No Partner Yet
          </h2>
          <p className="text-muted-foreground font-display">
            Invite your partner to start finding matches together!
          </p>
          <p className="text-sm text-muted-foreground font-display mt-4">
            Go to Settings to share your invite code.
          </p>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <div className="text-muted-foreground font-display">Loading matches...</div>
      </div>
    );
  }

  return (
    <>
      <div className="flex-shrink-0 px-5 pt-5 pb-3">
        <div className="flex items-baseline justify-between mb-1">
          <h1 className="text-2xl font-bold font-display text-foreground">Shared Matches</h1>
          <span className="text-sm text-muted-foreground font-display">{matches.length} {matches.length === 1 ? 'name' : 'names'}</span>
        </div>
        <p className="text-sm text-muted-foreground font-display mb-3">
          ★ Names you both love · drag to reorder
        </p>
        <div className="flex gap-2">
          <div className="flex-1 border-2 border-dashed border-[hsl(145,45%,55%)] rounded-2xl flex items-center justify-center py-3 px-4 opacity-0 pointer-events-none" />
          <button
            onClick={handleShare}
            disabled={matches.length === 0}
            className="bg-card border border-border text-foreground font-display font-semibold py-3 px-5 rounded-2xl flex items-center gap-2 text-sm hover:bg-card/80 transition-colors active:scale-[0.98] shadow-sm disabled:opacity-40 disabled:cursor-not-allowed"
          >
            <Share2 size={15} />
            <span>Share</span>
          </button>
        </div>
      </div>
      <div className="flex-1 min-h-0 overflow-y-auto px-4 pb-2">
        {matches.length === 0 ? (
          <p className="text-center text-muted-foreground font-display text-sm mt-12">
            No matches yet! Keep swiping to find names you both love.
          </p>
        ) : (
          <Reorder.Group axis="y" values={matches} onReorder={handleReorder} className="space-y-1.5 pt-1">
            {matches.map((match, index) => (
              <Reorder.Item
                key={match.id}
                value={match}
                className="bg-card border border-border rounded-lg px-3 py-2 font-display text-foreground text-base font-medium shadow-sm flex items-center gap-2.5 cursor-grab active:cursor-grabbing"
              >
                <span className="text-xs font-bold text-muted-foreground min-w-[20px]">
                  {index + 1}
                </span>
                <span className="flex-1">{match.name.text}</span>
                <GripHorizontal size={18} className="text-muted-foreground flex-shrink-0" />
              </Reorder.Item>
            ))}
          </Reorder.Group>
        )}
      </div>
    </>
  );
}
