/*
  # Update Baby Gender Values

  1. Changes
    - Drop old check constraint
    - Update existing 'unknown' values to 'either'
    - Add new check constraint with 'either' instead of 'unknown'
    - Update default value to 'either'
*/

-- Drop the old check constraint
DO $$
BEGIN
  ALTER TABLE users DROP CONSTRAINT IF EXISTS users_baby_gender_check;
EXCEPTION
  WHEN undefined_object THEN
    NULL;
END $$;

-- Update existing 'unknown' values to 'either'
UPDATE users SET baby_gender = 'either' WHERE baby_gender = 'unknown' OR baby_gender IS NULL;

-- Add new check constraint with 'either'
ALTER TABLE users ADD CONSTRAINT users_baby_gender_check 
  CHECK (baby_gender IN ('boy', 'girl', 'either'));

-- Update default value
ALTER TABLE users ALTER COLUMN baby_gender SET DEFAULT 'either';