/*
  # Add email column to users table

  ## Summary
  Adds an optional `email` column to the public.users table to store the
  authenticated user's email address after magic-link sign-in.

  ## Changes
  - `public.users`: adds `email` (text, nullable) column

  ## Notes
  - The column is nullable to preserve compatibility with existing anonymous guest rows
  - Email is populated during the auth callback upsert after successful magic-link login
  - No RLS changes needed; existing policies already cover this table
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'users' AND column_name = 'email'
  ) THEN
    ALTER TABLE users ADD COLUMN email text;
  END IF;
END $$;
