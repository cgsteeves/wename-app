/*
  # Add deletion_requests table

  ## Summary
  Creates a public-facing account deletion request table for users who submit
  a deletion request via the wename.app/delete-account page without being
  signed in. This satisfies Google Play's requirement that users can request
  deletion from outside the app.

  ## New Tables

  ### public.deletion_requests
  - `id` (uuid, PK) — unique identifier for each request
  - `email` (text, not null) — email address of the person requesting deletion
  - `reason` (text, nullable) — optional free-text reason provided by the user
  - `status` (text, default 'pending') — lifecycle: pending | processed | rejected
  - `created_at` (timestamptz) — when the request was submitted
  - `processed_at` (timestamptz, nullable) — when the request was acted on

  ## Security

  - RLS enabled with no direct client access
  - Inserts are performed exclusively via the submit-deletion-request Edge Function
    using the service role key, so no RLS policy is needed for anon INSERT
  - No SELECT/UPDATE/DELETE policies for clients — only admins via service role can
    query or update this table

  ## Notes

  1. No anon policies are added intentionally — the Edge Function uses the service
     role key which bypasses RLS, keeping this table admin-only for clients.
  2. A unique index on (email, status) where status = 'pending' is added to support
     the rate-limit check in the Edge Function (one pending request per email).
*/

CREATE TABLE IF NOT EXISTS public.deletion_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL,
  reason text,
  status text NOT NULL DEFAULT 'pending',
  created_at timestamptz NOT NULL DEFAULT now(),
  processed_at timestamptz
);

ALTER TABLE public.deletion_requests ENABLE ROW LEVEL SECURITY;

-- Index to support deduplication check: one pending request per email
CREATE INDEX IF NOT EXISTS deletion_requests_email_status_idx
  ON public.deletion_requests (email, status);
