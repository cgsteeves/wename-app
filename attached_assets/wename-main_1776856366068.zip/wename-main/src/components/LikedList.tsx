interface LikedListProps {
  names: string[];
  title: string;
}

export default function LikedList({ names, title }: LikedListProps) {
  return (
    <div className="flex flex-col h-full bg-parchment relative">
      <div className="p-6 flex-1 overflow-y-auto">
        <h1 className="text-2xl font-bold font-hand text-grass text-center mb-4">{title}</h1>
        {names.length === 0 ? (
          <p className="text-center text-muted-foreground font-display text-sm mt-12">
            No names yet! Start swiping to add some. 💛
          </p>
        ) : (
          <div className="space-y-2">
            {names.map((name, i) => (
              <div
                key={`${name}-${i}`}
                className="bg-card border border-border rounded-xl px-4 py-3 font-display text-foreground text-lg font-medium shadow-sm"
              >
                {name}
              </div>
            ))}
          </div>
        )}
      </div>
      <img src="/grass-flower-border.png" alt="" className="w-full h-16 object-cover object-bottom shrink-0" />
    </div>
  );
}
