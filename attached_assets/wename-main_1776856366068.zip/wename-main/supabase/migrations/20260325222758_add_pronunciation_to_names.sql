/*
  # Add pronunciation column to names table

  1. Changes
    - `names` table: adds optional `pronunciation` (text) column to store phonetic pronunciation guides for each name

  2. Notes
    - Column is nullable so existing names without pronunciation data are unaffected
    - No RLS changes needed; existing policies already cover all columns on the names table
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'names' AND column_name = 'pronunciation'
  ) THEN
    ALTER TABLE names ADD COLUMN pronunciation text;
  END IF;
END $$;
