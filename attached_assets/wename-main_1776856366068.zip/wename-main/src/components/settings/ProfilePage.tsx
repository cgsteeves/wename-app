import { useState } from 'react';
import { User } from '../../lib/supabase';
import { SubPageHeader } from './SubPageHeader';

type Gender = 'boy' | 'girl' | 'either';

interface ProfilePageProps {
  user: User;
  onBack: () => void;
  onUpdate: (updates: Partial<User>) => Promise<void>;
  onResetSwipes: () => void;
}

export function ProfilePage({ user, onBack, onUpdate, onResetSwipes }: ProfilePageProps) {
  const [displayName, setDisplayName] = useState(user.display_name || '');
  const [babyLastName, setBabyLastName] = useState(user.baby_last_name || '');
  const [babyGender, setBabyGender] = useState<Gender>(user.baby_gender ?? 'either');
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const hasChanges =
    displayName !== (user.display_name || '') ||
    babyLastName !== (user.baby_last_name || '') ||
    babyGender !== user.baby_gender;

  async function handleSave() {
    setSaving(true);
    await onUpdate({ display_name: displayName, baby_last_name: babyLastName, baby_gender: babyGender });
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  }

  const genderOptions: { value: Gender; label: string; activeClass: string }[] = [
    { value: 'boy', label: 'Boy', activeClass: 'bg-boy text-white' },
    { value: 'girl', label: 'Girl', activeClass: 'bg-girl text-white' },
    { value: 'either', label: 'Either', activeClass: 'bg-either text-white' },
  ];

  return (
    <div className="flex-1 min-h-0 flex flex-col bg-parchment overflow-y-auto">
      <SubPageHeader title="Profile" onBack={onBack} />

      <div className="flex-1 px-4 pb-10 space-y-5 pt-2">
        <div className="bg-card rounded-2xl border border-border/60 shadow-sm px-4 py-4 space-y-4">
          <div className="space-y-1.5">
            <label className="text-xs font-display font-semibold text-muted-foreground uppercase tracking-wider">
              Your Name
            </label>
            <input
              type="text"
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              placeholder="Enter your name"
              className="w-full px-3.5 py-2.5 rounded-xl border border-border bg-background font-display text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring transition"
            />
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-display font-semibold text-muted-foreground uppercase tracking-wider">
              Baby's Last Name
            </label>
            <input
              type="text"
              value={babyLastName}
              onChange={(e) => setBabyLastName(e.target.value)}
              placeholder="Optional"
              className="w-full px-3.5 py-2.5 rounded-xl border border-border bg-background font-display text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring transition"
            />
            <p className="text-xs text-muted-foreground font-display">
              Shown alongside names as you swipe
            </p>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-display font-semibold text-muted-foreground uppercase tracking-wider">
              Baby Gender
            </label>
            <div className="flex gap-2">
              {genderOptions.map((opt) => (
                <button
                  key={opt.value}
                  onClick={() => setBabyGender(opt.value)}
                  className={`flex-1 py-2.5 rounded-xl font-display font-semibold text-sm transition-all active:scale-95 ${
                    babyGender === opt.value
                      ? `${opt.activeClass} shadow-md`
                      : 'bg-background border border-border text-muted-foreground'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        <button
          onClick={handleSave}
          disabled={!hasChanges || saving}
          className={`w-full py-3.5 rounded-2xl font-display font-bold text-sm shadow-md transition-all active:scale-95 ${
            hasChanges && !saving
              ? 'bg-boy text-white hover:opacity-90'
              : 'bg-muted text-muted-foreground cursor-not-allowed'
          }`}
        >
          {saving ? 'Saving...' : saved ? 'Saved!' : 'Save Changes'}
        </button>

        <div className="pt-4 border-t border-border/50">
          <p className="text-xs font-display font-semibold text-muted-foreground uppercase tracking-wider mb-3 px-1">
            Danger Zone
          </p>
          <button
            onClick={onResetSwipes}
            className="w-full py-3 rounded-2xl border border-destructive/30 bg-destructive/5 text-destructive font-display font-semibold text-sm active:scale-95 transition-all"
          >
            Reset All Swipes
          </button>
          <p className="text-xs text-muted-foreground font-display mt-1.5 text-center">
            This will clear all your previous swipe choices
          </p>
        </div>
      </div>
    </div>
  );
}
