/*
  # Add get_partner_created_names RPC

  ## Summary
  Adds a new database function that returns names created by a user's partner
  that the current user has not yet swiped on. These names are surfaced in the
  swipe deck so partners can discover each other's manually added picks.

  ## New Functions
  - `get_partner_created_names(p_partner_id uuid, p_gender text)`
    - Returns all names where created_by_user_id = p_partner_id
    - Excludes names the calling user (auth.uid()) has already swiped on
    - Filters by gender if p_gender is not 'either'
    - Returns the same column shape as get_swipeable_names for easy merging

  ## Security
  - Function runs with SECURITY INVOKER so RLS on names and swipes is respected
  - Callers must be authenticated; the partner_id is passed explicitly and validated
    against the caller's own partner_id inside the function body
*/

CREATE OR REPLACE FUNCTION get_partner_created_names(
  p_partner_id uuid,
  p_gender text DEFAULT 'either'
)
RETURNS TABLE (
  id bigint,
  uuid uuid,
  name text,
  gender text,
  pronunciation text,
  nicknames text,
  meaning text,
  origin_raw text,
  style_raw text,
  feeling_raw text,
  popularity_raw text,
  uk_rank text,
  us_rank text,
  user_created boolean,
  created_by_user_id uuid
)
LANGUAGE plpgsql
SECURITY INVOKER
AS $$
DECLARE
  v_caller_partner_id uuid;
BEGIN
  -- Verify the caller actually has this partner
  SELECT u.partner_id INTO v_caller_partner_id
  FROM users u
  WHERE u.id = auth.uid();

  IF v_caller_partner_id IS DISTINCT FROM p_partner_id THEN
    RETURN;
  END IF;

  RETURN QUERY
  SELECT
    n.id,
    n.uuid,
    n.name,
    n.gender,
    n.pronunciation,
    n.nicknames,
    n.meaning,
    n.origin_raw,
    n.style_raw,
    n.feeling_raw,
    n.popularity_raw,
    n.uk_rank,
    n.us_rank,
    n.user_created,
    n.created_by_user_id
  FROM names n
  WHERE
    n.user_created = true
    AND n.created_by_user_id = p_partner_id
    AND n.is_active = true
    AND (
      p_gender = 'either'
      OR n.gender = p_gender
      OR n.gender = 'either'
    )
    AND NOT EXISTS (
      SELECT 1 FROM swipes s
      WHERE s.name_id = n.uuid
        AND s.user_id = auth.uid()
    );
END;
$$;
