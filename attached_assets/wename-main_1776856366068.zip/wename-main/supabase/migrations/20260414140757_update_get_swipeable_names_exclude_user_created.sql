/*
  # Update get_swipeable_names RPC to exclude user-created names

  ## Summary
  Updates the existing get_swipeable_names function to add a filter that excludes
  names that were manually entered by users (user_created = true).

  ## Changes
  - `get_swipeable_names` function: added `AND n.user_created = false` to the WHERE clause

  ## Notes
  - Catalog names default to user_created = false, so they are unaffected
  - Manually entered names (user_created = true) will never appear in another user's swipe deck
  - All other filtering logic (pack membership, is_active, gender) is unchanged
*/

CREATE OR REPLACE FUNCTION get_swipeable_names(
  pack_slugs text[],
  gender_filter text DEFAULT NULL
)
RETURNS TABLE (
  id uuid,
  text text,
  gender text,
  pronunciation text,
  origin text,
  meaning text,
  nickname text,
  rank integer
)
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
  SELECT DISTINCT ON (n.uuid)
    n.uuid AS id,
    n.name AS text,
    n.gender,
    n.pronunciation,
    n.origin_raw AS origin,
    n.meaning,
    n.nicknames AS nickname,
    CASE
      WHEN n.us_rank ~ '^\d+$' THEN n.us_rank::integer
      ELSE NULL
    END AS rank
  FROM names n
  JOIN name_pack_memberships npm ON npm.name = n.name
  WHERE npm.pack_slug = ANY(pack_slugs)
    AND n.is_active = true
    AND n.user_created = false
    AND (gender_filter IS NULL OR gender_filter = 'either' OR n.gender = gender_filter)
  ORDER BY n.uuid;
$$;
