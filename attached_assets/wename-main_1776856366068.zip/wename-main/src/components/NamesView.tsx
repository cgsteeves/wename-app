import React, { useState, useEffect, useRef, useCallback } from 'react';
import { supabase, User } from '../lib/supabase';
import { AnimatePresence, motion } from 'framer-motion';
import { GripHorizontal, Share2, Sparkles, Trash2, Users, X, CheckCircle2, Heart, Handshake, Star, Info, MapPin, TrendingUp, Tag } from 'lucide-react';
import { shareNameList } from '../utils/shareImage';
import listBg from '../assets/list-bg.jpg';
import boyCardBg from '../assets/boy-card-rolling-hills.jpg';
import NameSuggestions from './NameSuggestions';
import DraggableList from './DraggableList';
import { PremiumUpgradeModal } from './PremiumUpgradeModal';

interface NamesViewProps {
  user: User;
  updateUser: (updates: Partial<User>) => Promise<void>;
  onNavigateToPartner?: () => void;
}

type SubTab = 'liked' | 'matches' | 'suggestions';

interface LikedName {
  id: string;
  text: string;
  gender: string;
  pronunciation?: string | null;
  origin?: string | null;
  meaning?: string | null;
  nickname?: string | null;
  rank?: number | null;
}

interface NameInfoOverlayProps {
  name: LikedName;
  onClose: () => void;
}

interface Swipe {
  id: string;
  ranking: number | null;
  names: LikedName;
  local?: boolean;
}

interface Match {
  id: string;
  ranking: number | null;
  name: LikedName;
  local?: boolean;
}

interface Finalist {
  id: string;
  name_id: string;
  ranking: number | null;
  name: LikedName;
}

export default function NamesView({ user, updateUser, onNavigateToPartner }: NamesViewProps) {
  const [activeSubTab, setActiveSubTab] = useState<SubTab>('liked');
  const [discoverGateOpen, setDiscoverGateOpen] = useState(false);
  const [swipes, setSwipes] = useState<Swipe[]>([]);
  const [matches, setMatches] = useState<Match[]>([]);
  const [finalists, setFinalists] = useState<Finalist[]>([]);
  const [allSwipedNames, setAllSwipedNames] = useState<string[]>([]);
  const [partnerLikedNames, setPartnerLikedNames] = useState<string[]>([]);
  const [loadingLiked, setLoadingLiked] = useState(true);
  const [loadingMatches, setLoadingMatches] = useState(false);
  const [addingName, setAddingName] = useState(false);
  const [newNameText, setNewNameText] = useState('');
  const [newNameGender, setNewNameGender] = useState<'boy' | 'girl'>(
    user.baby_gender === 'girl' ? 'girl' : 'boy'
  );
  const [addError, setAddError] = useState('');
  const [toastMessage, setToastMessage] = useState('');
  const [showToast, setShowToast] = useState(false);
  const [selectedNameInfo, setSelectedNameInfo] = useState<LikedName | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const lastAddedRef = useRef<string | null>(null);
  const fetchGenRef = useRef<number>(0);

  const isBoy = user.baby_gender !== 'girl';
  const isPremium = user.plan_tier === 'premium';

  function handleDiscoverClick() {
    if (isPremium) {
      setActiveSubTab('suggestions');
    } else {
      setDiscoverGateOpen(true);
    }
  }

  useEffect(() => {
    loadLikedNames();
    loadFinalists();
  }, [user.id]);

  useEffect(() => {
    if (activeSubTab === 'matches') {
      loadMatches();
    } else if (activeSubTab === 'suggestions') {
      loadSuggestionContext();
    }
  }, [user.id, user.partner_id, activeSubTab]);

  useEffect(() => {
    if (!user.partner_id || activeSubTab !== 'matches') return;

    const channel = supabase
      .channel(`namesview-matches:${user.id}`)
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'matches', filter: `user_a_id=eq.${user.id}` },
        () => { loadMatches(); }
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'matches', filter: `user_b_id=eq.${user.id}` },
        () => { loadMatches(); }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user.id, user.partner_id, activeSubTab]);

  useEffect(() => {
    if (addingName) {
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  }, [addingName]);

  async function loadLikedNames() {
    const myGen = ++fetchGenRef.current;
    setLoadingLiked(true);
    try {
      const { data: swipeData, error: swipeError } = await supabase
        .from('swipes')
        .select('id, ranking, name_id')
        .eq('user_id', user.id)
        .eq('liked', true)
        .order('ranking', { ascending: true, nullsFirst: false })
        .order('created_at', { ascending: false });

      if (swipeError) throw swipeError;
      if (myGen !== fetchGenRef.current) { setLoadingLiked(false); return; }

      if (!swipeData || swipeData.length === 0) {
        setSwipes((prev) => prev.filter((s) => s.local));
        return;
      }

      const nameIds = swipeData.map((s: any) => s.name_id);
      const { data: nameData, error: nameError } = await supabase
        .from('names')
        .select('uuid, name, gender, pronunciation, origin_raw, meaning, nicknames, us_rank')
        .in('uuid', nameIds);

      if (nameError) throw nameError;

      const nameMap = new Map((nameData || []).map((n: any) => [n.uuid, {
        id: n.uuid,
        text: n.name,
        gender: n.gender,
        pronunciation: n.pronunciation ?? null,
        origin: n.origin_raw ?? null,
        meaning: n.meaning ?? null,
        nickname: n.nicknames ?? null,
        rank: n.us_rank != null && /^\d+$/.test(String(n.us_rank)) ? Number(n.us_rank) : null,
      }]));
      const validSwipes: Swipe[] = swipeData
        .filter((swipe: any) => nameMap.has(swipe.name_id))
        .map((swipe: any) => ({
          id: swipe.id,
          ranking: swipe.ranking,
          names: nameMap.get(swipe.name_id) as LikedName,
          local: false,
        }));

      setSwipes((prev) => {
        const optimistic = prev.filter((s) => s.local);
        const dbKeys = new Set(validSwipes.map((s) => `${s.names.text.toLowerCase()}::${s.names.gender}`));
        const remainingOptimistic = optimistic.filter(
          (s) => !dbKeys.has(`${s.names.text.toLowerCase()}::${s.names.gender}`)
        );
        return [...validSwipes, ...remainingOptimistic];
      });
    } catch (error) {
      console.error('[loadLikedNames] Error loading liked names:', error);
    } finally {
      if (myGen === fetchGenRef.current) setLoadingLiked(false);
    }
  }

  async function loadMatches() {
    if (!user.partner_id) return;
    setLoadingMatches(true);
    try {
      const { data: matchData, error: matchError } = await supabase
        .from('matches')
        .select('*')
        .or(`user_a_id.eq.${user.id},user_b_id.eq.${user.id}`)
        .order('ranking', { ascending: true, nullsFirst: false })
        .order('created_at', { ascending: false });

      if (matchError) throw matchError;
      if (!matchData || matchData.length === 0) { setMatches([]); return; }

      const nameIds = matchData.map((m: any) => m.name_id);
      const { data: nameData, error: nameError } = await supabase
        .from('names')
        .select('uuid, name, gender, pronunciation, origin_raw, meaning, nicknames, us_rank')
        .in('uuid', nameIds);

      if (nameError) throw nameError;

      const nameMap = new Map((nameData || []).map((n: any) => [n.uuid, {
        id: n.uuid,
        text: n.name,
        gender: n.gender,
        pronunciation: n.pronunciation ?? null,
        origin: n.origin_raw ?? null,
        meaning: n.meaning ?? null,
        nickname: n.nicknames ?? null,
        rank: n.us_rank != null && /^\d+$/.test(String(n.us_rank)) ? Number(n.us_rank) : null,
      }]));
      const enriched = matchData
        .filter((m: any) => nameMap.has(m.name_id))
        .map((m: any) => ({ ...m, name: nameMap.get(m.name_id) as LikedName }));

      setMatches(enriched as Match[]);
    } catch (error) {
      console.error('Error loading matches:', error);
    } finally {
      setLoadingMatches(false);
    }
  }

  async function loadFinalists() {
    try {
      const { data: finalistData, error } = await supabase
        .from('finalists')
        .select('id, name_id, ranking')
        .eq('user_id', user.id)
        .order('ranking', { ascending: true, nullsFirst: false })
        .order('created_at', { ascending: false });

      if (error) throw error;
      if (!finalistData || finalistData.length === 0) { setFinalists([]); return; }

      const nameIds = finalistData.map((f: any) => f.name_id);
      const { data: nameData, error: nameError } = await supabase
        .from('names')
        .select('uuid, name, gender, pronunciation, origin_raw, meaning, nicknames, us_rank')
        .in('uuid', nameIds);

      if (nameError) throw nameError;

      const nameMap = new Map((nameData || []).map((n: any) => [n.uuid, {
        id: n.uuid,
        text: n.name,
        gender: n.gender,
        pronunciation: n.pronunciation ?? null,
        origin: n.origin_raw ?? null,
        meaning: n.meaning ?? null,
        nickname: n.nicknames ?? null,
        rank: n.us_rank != null && /^\d+$/.test(String(n.us_rank)) ? Number(n.us_rank) : null,
      }]));
      const enriched: Finalist[] = finalistData
        .filter((f: any) => nameMap.has(f.name_id))
        .map((f: any) => ({ ...f, name: nameMap.get(f.name_id) as LikedName }));

      setFinalists(enriched);
    } catch (error) {
      console.error('Error loading finalists:', error);
    }
  }

  async function loadSuggestionContext() {
    try {
      const { data: allSwipes } = await supabase
        .from('swipes')
        .select('name_id')
        .eq('user_id', user.id);

      if (allSwipes && allSwipes.length > 0) {
        const swipeNameIds = allSwipes.map((s: any) => s.name_id);
        const { data: swipeNames } = await supabase
          .from('names')
          .select('uuid, name')
          .in('uuid', swipeNameIds);
        if (swipeNames) setAllSwipedNames(swipeNames.map((n: any) => n.name));
      }

      if (user.partner_id) {
        const { data: partnerSwipes } = await supabase
          .from('swipes')
          .select('name_id')
          .eq('user_id', user.partner_id)
          .eq('liked', true);

        if (partnerSwipes && partnerSwipes.length > 0) {
          const partnerNameIds = partnerSwipes.map((s: any) => s.name_id);
          const { data: partnerNames } = await supabase
            .from('names')
            .select('uuid, name')
            .in('uuid', partnerNameIds);
          if (partnerNames) setPartnerLikedNames(partnerNames.map((n: any) => n.name));
        }
      }
    } catch (error) {
      console.error('Error loading suggestion context:', error);
    }
  }

  async function handleReorderSwipes(newOrder: Swipe[]) {
    setSwipes(newOrder);
    try {
      for (let i = 0; i < newOrder.length; i++) {
        if (!newOrder[i].local) {
          await supabase.from('swipes').update({ ranking: i + 1 }).eq('id', newOrder[i].id);
        }
      }
    } catch (error) {
      console.error('Error updating swipe rankings:', error);
      loadLikedNames();
    }
  }

  async function handleReorderMatches(newOrder: Match[]) {
    setMatches(newOrder);
    try {
      for (let i = 0; i < newOrder.length; i++) {
        if (!newOrder[i].local) {
          await supabase.from('matches').update({ ranking: i + 1 }).eq('id', newOrder[i].id);
        }
      }
    } catch (error) {
      console.error('Error updating match rankings:', error);
      loadMatches();
    }
  }

  async function handleDeleteSwipe(swipeId: string, local?: boolean) {
    if (!local) {
      try {
        await supabase.from('swipes').update({ liked: false }).eq('id', swipeId);
      } catch (error) {
        console.error('Error deleting swipe:', error);
      }
    }
    setSwipes((prev) => prev.filter((s) => s.id !== swipeId));
  }

  async function handleDeleteMatch(matchId: string, local?: boolean) {
    if (!local) {
      try {
        await supabase.from('matches').delete().eq('id', matchId);
      } catch (error) {
        console.error('Error deleting match:', error);
      }
    }
    setMatches((prev) => prev.filter((m) => m.id !== matchId));
  }

  async function handleAddToFinalists(nameId: string, nameObj: LikedName) {
    const alreadyFinalist = finalists.some((f) => f.name_id === nameId);
    if (alreadyFinalist) {
      showToastNotification(`${nameObj.text} is already a finalist`);
      return;
    }
    try {
      const { data, error } = await supabase
        .from('finalists')
        .insert({ user_id: user.id, name_id: nameId })
        .select('id, name_id, ranking')
        .single();
      if (error) throw error;
      setFinalists((prev) => [...prev, { ...data, name: nameObj }]);
      showToastNotification(`${nameObj.text} added to Finalists!`);
    } catch (error) {
      console.error('Error adding finalist:', error);
    }
  }

  async function handleRemoveFinalist(finalistId: string, nameText: string) {
    try {
      await supabase.from('finalists').delete().eq('id', finalistId);
      setFinalists((prev) => prev.filter((f) => f.id !== finalistId));
      showToastNotification(`${nameText} removed from Finalists`);
    } catch (error) {
      console.error('Error removing finalist:', error);
    }
  }

  async function handleAddName() {
    const trimmed = newNameText.trim();
    if (!trimmed) { setAddError('Please enter a name.'); return; }

    const optimisticId = `local-${Date.now()}-${Math.random()}`;
    const nameRecord: LikedName = { id: optimisticId, text: trimmed, gender: newNameGender };

    if (activeSubTab === 'liked') {
      const alreadyIn = swipes.some(
        (s) => s.names.text.toLowerCase() === trimmed.toLowerCase() && s.names.gender === newNameGender
      );
      if (alreadyIn) { setAddError(`"${trimmed}" is already in your picks as a ${newNameGender} name.`); return; }
      setSwipes((prev) => [...prev, { id: optimisticId, ranking: null, names: nameRecord, local: true }]);
    } else {
      const alreadyIn = matches.some(
        (m) => m.name.text.toLowerCase() === trimmed.toLowerCase() && m.name.gender === newNameGender
      );
      if (alreadyIn) { setAddError(`"${trimmed}" is already in your matches as a ${newNameGender} name.`); return; }
      setMatches((prev) => [...prev, { id: optimisticId, ranking: null, name: nameRecord, local: true }]);
    }

    const tabAtSubmit = activeSubTab;
    setNewNameText('');
    setAddingName(false);
    setAddError('');

    try {
      let { data: nameRow, error: nameError } = await supabase
        .from('names')
        .select('uuid, name, gender')
        .eq('name', trimmed)
        .eq('gender', newNameGender)
        .maybeSingle();

      if (nameError) throw nameError;

      if (!nameRow) {
        const { data: insertedName, error: insertError } = await supabase
          .from('names')
          .insert({ name: trimmed, gender: newNameGender, user_created: true, created_by_user_id: user.id })
          .select('uuid, name, gender')
          .single();
        if (insertError) throw insertError;
        nameRow = insertedName;
      }

      const nameData: LikedName = { id: nameRow.uuid, text: nameRow.name, gender: nameRow.gender };

      if (activeSubTab === 'liked') {
        const { data: swipeData, error: swipeError } = await supabase
          .from('swipes')
          .insert({ user_id: user.id, name_id: nameData.id, liked: true })
          .select('id, ranking')
          .single();
        if (swipeError) throw swipeError;
        setSwipes((prev) =>
          prev.map((s) =>
            s.id === optimisticId
              ? { id: swipeData.id, ranking: swipeData.ranking, names: nameData, local: false }
              : s
          )
        );
        showToastNotification(`${nameData.text} added`);
      } else if (activeSubTab === 'matches' && user.partner_id) {
        const userA = user.id < user.partner_id ? user.id : user.partner_id;
        const userB = user.id < user.partner_id ? user.partner_id : user.id;
        const { data: matchData, error: matchError } = await supabase
          .from('matches')
          .insert({ name_id: nameData.id, user_a_id: userA, user_b_id: userB, gender: newNameGender })
          .select('id, ranking')
          .single();
        if (matchError) throw matchError;
        setMatches((prev) =>
          prev.map((m) =>
            m.id === optimisticId
              ? { id: matchData.id, ranking: matchData.ranking, name: nameData, local: false }
              : m
          )
        );
        showToastNotification(`${nameData.text} added`);
      }
    } catch (error: unknown) {
      console.error('[handleAddName] DB error, rolling back:', error);
      if (tabAtSubmit === 'liked') {
        setSwipes((prev) => prev.filter((s) => s.id !== optimisticId));
      } else {
        setMatches((prev) => prev.filter((m) => m.id !== optimisticId));
      }
      const dbMessage = error && typeof error === 'object' && 'message' in error
        ? (error as { message: string }).message
        : null;
      const isDuplicate = dbMessage && (
        dbMessage.includes('duplicate') || dbMessage.includes('unique') || dbMessage.includes('already exists')
      );
      const friendlyError = isDuplicate
        ? `"${trimmed}" is already in your ${tabAtSubmit === 'liked' ? 'picks' : 'matches'} as a ${newNameGender} name.`
        : `Couldn't save "${trimmed}". Please try again.`;
      setNewNameText(trimmed);
      setAddingName(true);
      setAddError(friendlyError);
    }
  }

  function showToastNotification(message: string) {
    setToastMessage(message);
    setShowToast(true);
    setTimeout(() => setShowToast(false), 3000);
  }

  const handleAddFromSuggestion = useCallback(async (name: string, gender: 'boy' | 'girl') => {
    const optimisticId = `optimistic-${Date.now()}-${Math.random()}`;
    const optimisticSwipe: Swipe = {
      id: optimisticId,
      ranking: null,
      names: { id: optimisticId, text: name, gender },
      local: true,
    };

    lastAddedRef.current = name;
    fetchGenRef.current++;

    setSwipes((prev) => {
      const alreadyIn = prev.some(
        (s) => s.names.text.toLowerCase() === name.toLowerCase() && s.names.gender === gender
      );
      if (alreadyIn) return prev;
      return [...prev, optimisticSwipe];
    });
    setAllSwipedNames((prev) => [...prev, name]);
    showToastNotification(`${name} added to Your Picks!`);

    try {
      let { data: nameRow, error: nameError } = await supabase
        .from('names')
        .select('uuid, name, gender')
        .eq('name', name)
        .eq('gender', gender)
        .maybeSingle();

      if (nameError) throw nameError;

      if (!nameRow) {
        const { data: insertedName, error: insertError } = await supabase
          .from('names')
          .insert({ name, gender })
          .select('uuid, name, gender')
          .single();
        if (insertError) throw insertError;
        nameRow = insertedName;
      }

      const nameData = { id: nameRow.uuid, text: nameRow.name, gender: nameRow.gender };

      const { data: swipeData, error: swipeError } = await supabase
        .from('swipes')
        .insert({ user_id: user.id, name_id: nameData.id, liked: true })
        .select('id, ranking')
        .single();

      if (swipeError) throw swipeError;

      setSwipes((prev) =>
        prev.map((s) =>
          s.id === optimisticId
            ? { id: swipeData.id, ranking: swipeData.ranking, names: nameData!, local: false }
            : s
        )
      );
    } catch (error) {
      console.error('[handleAddFromSuggestion] DB error, rolling back:', error);
      setSwipes((prev) => prev.filter((s) => s.id !== optimisticId));
      setAllSwipedNames((prev) => prev.filter((n) => n !== name));
      lastAddedRef.current = null;
      showToastNotification(`Failed to add ${name}`);
    }
  }, [user.id]);

  function handleCancelAdd() {
    setAddingName(false);
    setNewNameText('');
    setAddError('');
  }

  async function handleShareLiked() {
    const namesForShare = swipes.map((swipe) => ({
      name: swipe.names.text,
      gender: swipe.names.gender as 'boy' | 'girl',
    }));
    await shareNameList(namesForShare, 'My Favorite Baby Names', `Check out my favorite baby names: ${namesForShare.map(n => n.name).join(', ')}`);
  }

  async function handleShareMatches() {
    const namesForShare = matches.map((match) => ({
      name: match.name.text,
      gender: match.name.gender as 'boy' | 'girl',
    }));
    await shareNameList(namesForShare, 'Our Matched Baby Names', `Check out the baby names we both love: ${namesForShare.map(n => n.name).join(', ')}`);
  }

  const showLiked = activeSubTab === 'liked';
  const showMatches = activeSubTab === 'matches';
  const showSuggestions = activeSubTab === 'suggestions';

  const isLoadingContent = (showLiked && loadingLiked && swipes.length === 0) ||
    (showMatches && loadingMatches && matches.length === 0);

  const hasNoPartner = showMatches && !user.partner_id;
  const accentColor = isBoy ? 'text-boy' : 'text-girl-pink';
  const accentBorder = isBoy ? 'border-boy/30 focus:border-boy/60' : 'border-girl-pink/30 focus:border-girl-pink/60';
  const accentBg = isBoy ? 'bg-boy/10 text-boy border-boy/20' : 'bg-girl-pink/10 text-girl-pink border-girl-pink/20';

  function renderSwipeCard(swipe: Swipe, index: number, isDragging: boolean, dragHandleProps?: { onMouseDown: (e: React.MouseEvent) => void; onTouchStart: (e: React.TouchEvent) => void }) {
    const isTop = index < 3;
    return (
      <div
        className={`relative rounded-lg font-display text-foreground text-base font-medium shadow-md flex items-center gap-2.5 overflow-hidden ${isDragging ? 'shadow-xl scale-[1.02]' : ''}`}
        style={swipe.names.gender === 'girl'
          ? { border: '1px solid hsl(345 50% 68%)' }
          : { border: '1px solid hsl(214 50% 62%)' }}
      >
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: swipe.names.gender === 'girl' ? undefined : `url('${boyCardBg}')`,
            backgroundPosition: `center ${(index * 17) % 60}%`,
            background: swipe.names.gender === 'girl'
              ? `radial-gradient(ellipse 120% 80% at 85% 60%, rgba(255,182,193,0.55) 0%, transparent 55%), radial-gradient(ellipse 80% 100% at 10% 30%, rgba(255,160,170,0.3) 0%, transparent 50%), radial-gradient(ellipse 60% 70% at 50% 90%, rgba(255,192,203,0.25) 0%, transparent 50%), linear-gradient(135deg, rgba(255,228,225,0.9) 0%, rgba(255,210,215,0.85) 40%, rgba(255,240,242,0.95) 100%)`
              : undefined,
          }}
        />
        {swipe.names.gender !== 'girl' && (
          <div className="absolute inset-0" style={{ background: 'linear-gradient(90deg, hsl(214 72% 88% / 0.82) 0%, hsl(210 65% 86% / 0.72) 100%)' }} />
        )}
        <div className="relative z-10 flex items-center w-full py-3" style={{ color: swipe.names.gender === 'girl' ? 'hsl(345 55% 38%)' : undefined }}>
          <div
            className="flex items-center justify-center self-stretch px-3 touch-none cursor-grab active:cursor-grabbing select-none"
            style={{ color: swipe.names.gender === 'girl' ? 'hsl(345 50% 55%)' : 'hsl(214 50% 42%)', flexShrink: 0, minWidth: '44px' }}
            {...(dragHandleProps || {})}
          >
            <GripHorizontal size={18} />
          </div>
          <span className="text-xs font-bold min-w-[16px]" style={{ color: swipe.names.gender === 'girl' ? 'hsl(345 55% 48%)' : 'hsl(214 55% 38%)' }}>
            {isTop ? `#${index + 1}` : index + 1}
          </span>
          <span className="flex-1 pl-2">{swipe.names.text}</span>
          <div className="flex items-center gap-1 pr-2">
            <button
              onPointerDown={(e) => e.stopPropagation()}
              onTouchStart={(e) => e.stopPropagation()}
              onClick={(e) => { e.stopPropagation(); setSelectedNameInfo(swipe.names); }}
              className="flex items-center justify-center w-8 h-8 rounded-full text-muted-foreground/60 hover:text-sky-500 hover:bg-sky-500/10 transition-all touch-auto"
            >
              <Info size={16} />
            </button>
            <button
              onPointerDown={(e) => e.stopPropagation()}
              onTouchStart={(e) => e.stopPropagation()}
              onClick={(e) => { e.stopPropagation(); handleDeleteSwipe(swipe.id, swipe.local); }}
              className="flex items-center justify-center w-8 h-8 rounded-full text-muted-foreground/60 hover:text-red-400 hover:bg-red-400/10 transition-all touch-auto"
            >
              <Trash2 size={16} />
            </button>
          </div>
        </div>
      </div>
    );
  }

  function renderMatchCard(match: Match, index: number, isDragging: boolean, dragHandleProps?: { onMouseDown: (e: React.MouseEvent) => void; onTouchStart: (e: React.TouchEvent) => void }) {
    return (
      <div
        className={`relative rounded-lg font-display text-foreground text-base font-medium shadow-md flex items-center gap-2.5 overflow-hidden ${isDragging ? 'shadow-xl scale-[1.02]' : ''}`}
        style={match.name.gender === 'girl'
          ? { border: '1px solid hsl(345 50% 62%)' }
          : { border: '1px solid hsl(214 50% 56%)' }}
      >
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: match.name.gender === 'girl' ? undefined : `url('${boyCardBg}')`,
            backgroundPosition: `center ${(index * 17) % 60}%`,
            background: match.name.gender === 'girl'
              ? `radial-gradient(ellipse 120% 80% at 85% 60%, rgba(255,182,193,0.6) 0%, transparent 55%), radial-gradient(ellipse 80% 100% at 10% 30%, rgba(255,160,170,0.35) 0%, transparent 50%), linear-gradient(135deg, rgba(255,230,220,0.95) 0%, rgba(255,214,210,0.9) 40%, rgba(255,242,238,0.98) 100%)`
              : undefined,
          }}
        />
        {match.name.gender !== 'girl' && (
          <div className="absolute inset-0" style={{ background: 'linear-gradient(90deg, hsl(214 72% 86% / 0.88) 0%, hsl(210 65% 84% / 0.78) 100%)' }} />
        )}
        <div className="relative z-10 flex items-center w-full py-3" style={{ color: match.name.gender === 'girl' ? 'hsl(345 55% 36%)' : undefined }}>
          <div
            className="flex items-center justify-center self-stretch px-3 touch-none cursor-grab active:cursor-grabbing select-none"
            style={{ color: match.name.gender === 'girl' ? 'hsl(345 50% 55%)' : 'hsl(214 50% 42%)', flexShrink: 0, minWidth: '44px' }}
            {...(dragHandleProps || {})}
          >
            <GripHorizontal size={18} />
          </div>
          <span className="text-xs font-bold min-w-[16px]" style={{ color: match.name.gender === 'girl' ? 'hsl(345 55% 48%)' : 'hsl(214 55% 38%)' }}>{index + 1}</span>
          <div className="flex-1 min-w-0 pl-2">
            <span className="block">{match.name.text}</span>
            <span className="text-[10px] font-normal opacity-70">You both liked this</span>
          </div>
          <div className="flex items-center gap-1 pr-2">
            <button
              onPointerDown={(e) => e.stopPropagation()}
              onTouchStart={(e) => e.stopPropagation()}
              onClick={(e) => { e.stopPropagation(); setSelectedNameInfo(match.name); }}
              className="flex items-center justify-center w-8 h-8 rounded-full text-muted-foreground/60 hover:text-sky-500 hover:bg-sky-500/10 transition-all touch-auto"
            >
              <Info size={16} />
            </button>
            <button
              onPointerDown={(e) => e.stopPropagation()}
              onTouchStart={(e) => e.stopPropagation()}
              onClick={(e) => { e.stopPropagation(); handleDeleteMatch(match.id, match.local); }}
              className="flex items-center justify-center w-8 h-8 rounded-full text-muted-foreground/60 hover:text-red-400 hover:bg-red-400/10 transition-all touch-auto"
            >
              <Trash2 size={16} />
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 min-h-0 flex flex-col relative">
      <img
        src={listBg}
        alt=""
        className="absolute inset-0 w-full h-full object-cover pointer-events-none"
        draggable={false}
      />
      <div className="absolute inset-0 bg-white/30 pointer-events-none" />

      {/* Tab bar */}
      <div className="relative z-10 flex-shrink-0 flex gap-2 p-3 border-b border-border/20 bg-white/20 backdrop-blur-[2px]">
        <button
          onClick={() => setActiveSubTab('liked')}
          className={`flex-1 py-2 px-1 rounded-xl font-display font-medium text-xs transition-all flex items-center justify-center gap-1.5 ${
            showLiked
              ? isBoy ? 'bg-boy/10 text-boy border border-boy/20 shadow-sm' : 'bg-girl-pink/10 text-girl-pink border border-girl-pink/20 shadow-sm'
              : 'bg-white/50 text-muted-foreground border border-border/30'
          }`}
        >
          <Heart size={13} />
          <span>Your Picks</span>
        </button>
        <button
          onClick={() => setActiveSubTab('matches')}
          className={`flex-1 py-2 px-1 rounded-xl font-display font-medium text-xs transition-all flex items-center justify-center gap-1.5 ${
            showMatches
              ? isBoy ? 'bg-boy/10 text-boy border border-boy/20 shadow-sm' : 'bg-girl-pink/10 text-girl-pink border border-girl-pink/20 shadow-sm'
              : 'bg-white/50 text-muted-foreground border border-border/30'
          }`}
        >
          <Handshake size={13} />
          <span>Shared Matches</span>
        </button>
        <button
          onClick={handleDiscoverClick}
          className={`flex-1 py-2 px-1 rounded-xl font-display font-medium text-xs transition-all flex flex-col items-center justify-center gap-0.5 ${
            showSuggestions
              ? isBoy ? 'bg-boy/10 text-boy border border-boy/20 shadow-sm' : 'bg-girl-pink/10 text-girl-pink border border-girl-pink/20 shadow-sm'
              : 'bg-white/50 text-muted-foreground border border-border/30'
          }`}
        >
          <div className="flex items-center gap-1">
            <Sparkles size={13} />
            <span>AI Suggestions</span>
          </div>
          {!isPremium && <span className="text-[9px] font-bold tracking-wide uppercase leading-none px-1.5 py-0.5 rounded-md" style={{ background: 'hsl(38 85% 48%)', color: 'white' }}>PRO</span>}
        </button>
      </div>

      {/* Header area */}
      <div className="relative z-10 flex-shrink-0 px-5 pt-4 pb-3">
        {showSuggestions ? (
          <h1 className="text-2xl font-bold font-display text-foreground flex items-center gap-2 mb-1">
            <span>AI Suggestions</span>
            <Sparkles size={22} className={isBoy ? 'text-boy' : 'text-girl-pink'} />
          </h1>
        ) : (
          <>
            <div className="flex items-baseline justify-between mb-1">
              <h1 className="text-2xl font-bold font-display text-foreground">
                {showLiked ? 'Your Picks' : 'Shared Matches'}
              </h1>
              <span className="text-sm text-muted-foreground font-display">
                {showLiked
                  ? `${swipes.length} ${swipes.length === 1 ? 'name' : 'names'}`
                  : `${matches.length} ${matches.length === 1 ? 'name' : 'names'}`}
              </span>
            </div>
            <p className="text-sm text-muted-foreground font-display mb-3">
              Drag to reorder. See more information by tapping <Info size={13} className="inline-block align-middle mb-0.5" />
            </p>

            {/* Add name form (inline) */}
            {addingName ? (
              <div className="mb-3 bg-card/70 border border-border/50 rounded-xl p-3 space-y-2">
                <div className="flex gap-2">
                  <input
                    ref={inputRef}
                    type="text"
                    value={newNameText}
                    onChange={(e) => { setNewNameText(e.target.value); setAddError(''); }}
                    onKeyDown={(e) => { if (e.key === 'Enter') handleAddName(); if (e.key === 'Escape') handleCancelAdd(); }}
                    placeholder="Enter a name..."
                    className={`flex-1 bg-white/60 border rounded-lg px-3 py-1.5 text-sm font-display text-foreground placeholder:text-muted-foreground/50 outline-none transition-colors ${accentBorder}`}
                  />
                  <button onClick={handleCancelAdd} className="flex-shrink-0 p-1.5 text-muted-foreground/60 hover:text-muted-foreground transition-colors">
                    <X size={16} />
                  </button>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => { setNewNameGender('boy'); setAddError(''); }}
                    className={`flex-1 py-1.5 rounded-lg text-xs font-display font-medium border transition-all ${newNameGender === 'boy' ? 'bg-boy/10 text-boy border-boy/20' : 'bg-white/40 text-muted-foreground border-border/30'}`}
                  >
                    Boy
                  </button>
                  <button
                    onClick={() => { setNewNameGender('girl'); setAddError(''); }}
                    className={`flex-1 py-1.5 rounded-lg text-xs font-display font-medium border transition-all ${newNameGender === 'girl' ? 'bg-girl-pink/10 text-girl-pink border-girl-pink/20' : 'bg-white/40 text-muted-foreground border-border/30'}`}
                  >
                    Girl
                  </button>
                </div>
                {addError && (
                  <div className="flex items-start gap-1.5 bg-red-50/80 border border-red-200 rounded-lg px-2.5 py-2">
                    <span className="text-red-400 mt-0.5 flex-shrink-0 text-sm leading-none">!</span>
                    <p className="text-xs text-red-500 font-display leading-snug">{addError}</p>
                  </div>
                )}
                <p className="text-xs font-display text-gray-400 text-center leading-snug">
                  Manually added names in Your Picks will appear as swipable names for your partner
                </p>
                <button onClick={handleAddName} className={`w-full py-1.5 rounded-lg text-xs font-display font-medium border transition-all ${accentBg}`}>
                  Add Name
                </button>
              </div>
            ) : (
              <div className="flex gap-2">
                {showLiked && !hasNoPartner && (
                  <button
                    onClick={() => setAddingName(true)}
                    className="flex-1 border-2 border-dashed border-[hsl(145,45%,55%)] text-[hsl(145,45%,35%)] font-display font-semibold py-3 px-4 rounded-2xl flex items-center justify-center gap-2 text-sm bg-transparent hover:bg-[hsl(145,45%,35%)]/5 transition-colors active:scale-[0.98]"
                  >
                    <span className="text-base leading-none">+</span>
                    <span>Add name</span>
                  </button>
                )}
                {showMatches && !hasNoPartner && (
                  <button
                    onClick={() => setAddingName(true)}
                    className="flex-1 border-2 border-dashed border-[hsl(145,45%,55%)] text-[hsl(145,45%,35%)] font-display font-semibold py-3 px-4 rounded-2xl flex items-center justify-center gap-2 text-sm bg-transparent hover:bg-[hsl(145,45%,35%)]/5 transition-colors active:scale-[0.98]"
                  >
                    <span className="text-base leading-none">+</span>
                    <span>Add name</span>
                  </button>
                )}
                <button
                  onClick={showLiked ? handleShareLiked : handleShareMatches}
                  disabled={showLiked ? swipes.length === 0 : matches.length === 0}
                  className="bg-white/60 border border-border text-foreground font-display font-semibold py-3 px-5 rounded-2xl flex items-center gap-2 text-sm hover:bg-white/80 transition-colors active:scale-[0.98] shadow-sm disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  <Share2 size={15} />
                  <span>Share</span>
                </button>
              </div>
            )}
          </>
        )}
      </div>

      {/* Content */}
      <div className="relative z-10 flex-1 min-h-0 overflow-y-auto px-2 pb-2">
        {showSuggestions ? (
          <NameSuggestions
            user={user}
            likedNames={swipes.map((s) => s.names.text)}
            matchedNames={matches.map((m) => m.name.text)}
            partnerLikedNames={partnerLikedNames}
            excludeNames={allSwipedNames}
            onNameAdded={handleAddFromSuggestion}
          />
        ) : isLoadingContent ? (
          <div className="flex items-center justify-center h-full">
            <div className="text-muted-foreground font-display">Loading...</div>
          </div>
        ) : hasNoPartner ? (
          <div className="flex flex-col items-center justify-center px-6 text-center py-8">
            <Users size={64} className="text-muted mb-4" />
            <h2 className="text-xl font-bold font-hand text-grass mb-2">No Partner Yet</h2>
            <p className="text-muted-foreground font-display mb-6">Invite your partner to start finding shared matches together!</p>
            <button
              onClick={onNavigateToPartner}
              className="flex items-center gap-2 px-6 py-3 rounded-2xl font-display font-semibold text-sm text-white bg-grass hover:bg-grass/90 active:scale-[0.98] transition-all shadow-md"
            >
              <Users size={16} />
              <span>Connect with Partner</span>
            </button>
          </div>
        ) : showLiked ? (
          swipes.length === 0 ? (
            <p className="text-center text-muted-foreground font-display text-sm mt-12">No names yet! Start swiping to add some.</p>
          ) : (
            <DraggableList
              items={swipes}
              onReorder={handleReorderSwipes}
              keyExtractor={(swipe) => swipe.id}
              renderItem={(swipe, index, isDragging, dragHandleProps) =>
                renderSwipeCard(swipe, index, isDragging, dragHandleProps)
              }
            />
          )
        ) : (
          /* Shared Matches tab */
          <div>
            {finalists.length > 0 && (
              <div className="mb-4">
                <div className="space-y-1.5">
                  {finalists.map((finalist) => (
                    <div
                      key={finalist.id}
                      className="relative rounded-lg font-display text-foreground text-base font-medium shadow-md flex items-center gap-2.5 overflow-hidden"
                      style={finalist.name.gender === 'girl'
                        ? { border: '1px solid hsl(345 55% 58%)' }
                        : { border: '1px solid hsl(214 55% 52%)' }}
                    >
                      <div
                        className="absolute inset-0"
                        style={finalist.name.gender === 'girl'
                          ? { background: 'linear-gradient(135deg, rgba(255,210,200,0.98) 0%, rgba(255,190,185,0.92) 100%)' }
                          : { background: 'linear-gradient(135deg, hsl(214 72% 84% / 0.98) 0%, hsl(210 65% 82% / 0.92) 100%)' }}
                      />
                      <div className="relative z-10 flex items-center gap-2.5 w-full px-3 py-2" style={{ color: finalist.name.gender === 'girl' ? 'hsl(345 55% 34%)' : undefined }}>
                        <Star size={13} fill="currentColor" style={{ color: finalist.name.gender === 'girl' ? 'hsl(345 55% 50%)' : 'hsl(214 55% 40%)', flexShrink: 0 }} />
                        <span className="flex-1 font-semibold">{finalist.name.text}</span>
                        <button
                          onClick={() => handleRemoveFinalist(finalist.id, finalist.name.text)}
                          className="flex-shrink-0 p-1 text-muted-foreground/50 hover:text-red-400 transition-colors"
                        >
                          <X size={14} />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {matches.length === 0 ? (
              <div className="flex flex-col items-center justify-center px-6 text-center py-10">
                <Handshake size={48} className="text-muted mb-3" />
                <p className="text-muted-foreground font-display text-sm leading-relaxed">
                  When you and your partner like the same name, it will appear here
                </p>
              </div>
            ) : (
              <DraggableList
                items={matches}
                onReorder={handleReorderMatches}
                keyExtractor={(match) => match.id}
                renderItem={(match, index, isDragging, dragHandleProps) => renderMatchCard(match, index, isDragging, dragHandleProps)}
              />
            )}
          </div>
        )}
      </div>

      <img src="/grass-flower-border.png" alt="" className="relative z-10 flex-shrink-0 w-full" style={{ maxHeight: '60px', objectFit: 'cover', objectPosition: 'top' }} />

      {showToast && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 animate-in fade-in slide-in-from-top-2 duration-300">
          <div className="bg-green-600 text-white px-4 py-3 rounded-lg shadow-lg flex items-center gap-2 font-display">
            <CheckCircle2 size={18} />
            <span className="font-medium">{toastMessage}</span>
          </div>
        </div>
      )}

      <AnimatePresence>
        {selectedNameInfo && (
          <NameInfoOverlay name={selectedNameInfo} onClose={() => setSelectedNameInfo(null)} />
        )}
      </AnimatePresence>

      {/* Discover gate modal — shown when a free user taps Discover tab */}
      <PremiumUpgradeModal
        open={discoverGateOpen}
        limitType="discover"
        onClose={() => {
          setDiscoverGateOpen(false);
          setActiveSubTab('liked');
        }}
        onUpgrade={() => {
          setDiscoverGateOpen(false);
        }}
      />
    </div>
  );
}

function NameInfoOverlay({ name, onClose }: NameInfoOverlayProps) {
  const isBoy = name.gender !== 'girl';
  const accentColor = isBoy ? 'hsl(214 55% 40%)' : 'hsl(345 55% 48%)';
  const accentBg = isBoy
    ? 'linear-gradient(160deg, rgba(219,234,254,0.99) 0%, rgba(191,219,254,0.97) 50%, rgba(255,251,235,0.99) 100%)'
    : 'linear-gradient(160deg, rgba(254,228,232,0.99) 0%, rgba(251,207,215,0.97) 50%, rgba(255,251,235,0.99) 100%)';
  const rowBg = isBoy
    ? 'rgba(100,140,200,0.08)'
    : 'rgba(255,160,170,0.08)';
  const rowBorder = isBoy
    ? '1px solid hsl(214 50% 80%)'
    : '1px solid hsl(345 50% 82%)';

  return (
    <>
      <motion.div
        className="fixed inset-0 z-40 bg-black/40 backdrop-blur-sm"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
      />
      <motion.div
        className="fixed bottom-0 left-0 right-0 z-50 max-w-md mx-auto rounded-t-3xl overflow-hidden shadow-2xl"
        initial={{ y: '100%' }}
        animate={{ y: 0 }}
        exit={{ y: '100%' }}
        transition={{ type: 'spring', stiffness: 350, damping: 35 }}
        drag="y"
        dragConstraints={{ top: 0, bottom: 0 }}
        dragElastic={{ top: 0, bottom: 0.4 }}
        onDragEnd={(_e, info) => { if (info.offset.y > 80) onClose(); }}
        style={{ background: accentBg }}
      >
        <div
          className="absolute inset-0 opacity-20 pointer-events-none"
          style={{ backgroundImage: 'url(/paper-texture.jpg)', backgroundSize: 'cover' }}
        />
        <div
          className="absolute inset-0 pointer-events-none"
          style={{ background: 'radial-gradient(ellipse at top, rgba(255,255,255,0.45) 0%, transparent 65%)' }}
        />

        <div className="relative z-10">
          <div className="flex justify-center pt-3.5 pb-1">
            <div className="w-10 h-1 rounded-full bg-black/20" />
          </div>

          <div className="px-6 pt-2 pb-8">
            <div className="flex justify-end mb-3">
              <button
                onClick={onClose}
                className="w-8 h-8 rounded-full flex items-center justify-center border border-black/10 bg-white/60 active:scale-90 transition-all text-muted-foreground hover:text-foreground"
              >
                <X size={14} />
              </button>
            </div>

            <div className="text-center mb-6">
              <p className="font-hand text-xl italic mb-2" style={{ color: accentColor, opacity: 0.8 }}>
                About this name
              </p>
              <div className="h-[1.5px] mx-auto w-24 mb-4 rounded-full opacity-40" style={{ background: accentColor }} />
              <h2 className="text-5xl font-bold font-display tracking-tight" style={{ color: accentColor }}>
                {name.text}
              </h2>
              {name.pronunciation && (
                <p className="text-sm font-display italic mt-2 tracking-wide" style={{ color: accentColor, opacity: 0.6 }}>
                  [{name.pronunciation}]
                </p>
              )}
            </div>

            <div className="flex flex-col gap-2.5">
              <NameInfoRow
                icon={<MapPin size={15} />}
                label="Origin"
                value={name.origin ?? '—'}
                accentColor={accentColor}
                rowBg={rowBg}
                rowBorder={rowBorder}
              />
              <NameInfoRow
                icon={<Sparkles size={15} />}
                label="Meaning"
                value={name.meaning ?? '—'}
                accentColor={accentColor}
                rowBg={rowBg}
                rowBorder={rowBorder}
              />
              <NameInfoRow
                icon={<Tag size={15} />}
                label="Possible Nickname"
                value={name.nickname ?? '—'}
                accentColor={accentColor}
                rowBg={rowBg}
                rowBorder={rowBorder}
              />
              <NameInfoRow
                icon={<TrendingUp size={15} />}
                label="Popularity"
                value={name.rank != null ? `#${name.rank} most popular` : '—'}
                accentColor={accentColor}
                rowBg={rowBg}
                rowBorder={rowBorder}
              />
            </div>

            <p className="text-center text-xs font-display mt-5" style={{ color: accentColor, opacity: 0.35 }}>
              swipe down to close
            </p>
          </div>
        </div>
      </motion.div>
    </>
  );
}

function NameInfoRow({
  icon, label, value, accentColor, rowBg, rowBorder,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  accentColor: string;
  rowBg: string;
  rowBorder: string;
}) {
  return (
    <div
      className="flex items-start gap-3 rounded-xl px-4 py-3"
      style={{ background: rowBg, border: rowBorder }}
    >
      <div className="mt-0.5 flex-shrink-0" style={{ color: accentColor, opacity: 0.65 }}>
        {icon}
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-[10px] font-display font-semibold uppercase tracking-widest mb-0.5" style={{ color: accentColor, opacity: 0.6 }}>
          {label}
        </p>
        <p className="font-display text-sm leading-snug text-foreground/85">
          {value}
        </p>
      </div>
    </div>
  );
}
