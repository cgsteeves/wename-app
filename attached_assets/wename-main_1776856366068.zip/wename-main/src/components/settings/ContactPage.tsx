import { SubPageHeader } from './SubPageHeader';

interface ContactPageProps {
  onBack: () => void;
}

function PolicyLink({ href, label }: { href: string; label: string }) {
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      className="text-sky-600 underline underline-offset-2 break-all"
    >
      {label}
    </a>
  );
}

export function ContactPage({ onBack }: ContactPageProps) {
  return (
    <div className="flex-1 min-h-0 flex flex-col bg-parchment overflow-y-auto">
      <SubPageHeader title="Support" onBack={onBack} />

      <div className="flex-1 px-4 pb-12 pt-2 space-y-6">
        <div className="bg-card rounded-2xl border border-border/60 shadow-sm px-5 py-5 space-y-1">
          <p className="font-display font-bold text-base text-foreground">WeName</p>
          <p className="text-xs font-display text-muted-foreground">We're here to help</p>
        </div>

        <div className="bg-card rounded-2xl border border-border/60 shadow-sm px-5 py-5 space-y-6 divide-y divide-border/40">

          <div className="space-y-3">
            <h2 className="font-display font-bold text-base text-foreground">Get in Touch</h2>
            <div className="space-y-2 text-sm font-display text-foreground/80 leading-relaxed">
              <p>
                Have a question, a bug to report, or feedback to share? We'd love to hear from you.
                Reach out directly and we'll get back to you as soon as we can.
              </p>
              <div className="bg-muted/60 rounded-xl px-4 py-3 border border-border/40 space-y-1">
                <p className="font-semibold text-foreground">WeName</p>
                <p>Ottawa, Ontario, Canada</p>
                <p>Email: <PolicyLink href="mailto:wenameapp@gmail.com" label="wenameapp@gmail.com" /></p>
                <p>Website: <PolicyLink href="https://wename.app" label="wename.app" /></p>
              </div>
            </div>
          </div>

          <div className="pt-6 space-y-3">
            <h2 className="font-display font-bold text-base text-foreground">What to Include</h2>
            <div className="space-y-2 text-sm font-display text-foreground/80 leading-relaxed">
              <p>To help us respond quickly, please include the following in your message:</p>
              <ul className="list-disc list-inside space-y-1 pl-1">
                <li>A brief description of your question or issue</li>
                <li>The device and browser you are using (e.g., iPhone, Safari)</li>
                <li>Steps to reproduce the problem, if applicable</li>
                <li>Your account email address, if you have one</li>
                <li>Any screenshots that might help illustrate the issue</li>
              </ul>
            </div>
          </div>

          <div className="pt-6 space-y-3">
            <h2 className="font-display font-bold text-base text-foreground">Response Times</h2>
            <div className="space-y-2 text-sm font-display text-foreground/80 leading-relaxed">
              <p>
                WeName is an independently built app. We aim to respond to all support messages within
                2–3 business days. We appreciate your patience and do our best to address every message.
              </p>
            </div>
          </div>

          <div className="pt-6 space-y-3">
            <h2 className="font-display font-bold text-base text-foreground">Privacy & Legal</h2>
            <div className="space-y-2 text-sm font-display text-foreground/80 leading-relaxed">
              <p>
                For questions related to your personal data, account deletion, or legal matters, please
                contact us at the email above and reference the relevant policy.
              </p>
              <p>
                You can also review our full policies at any time:
              </p>
              <ul className="list-disc list-inside space-y-1 pl-1">
                <li>Privacy Policy: <PolicyLink href="https://wename.app/privacy" label="wename.app/privacy" /></li>
                <li>Terms of Service: <PolicyLink href="https://wename.app/terms" label="wename.app/terms" /></li>
              </ul>
            </div>
          </div>

        </div>

        <p className="text-center text-xs text-muted-foreground font-display px-4 pb-2">
          WeName — made with love for growing families
        </p>
      </div>
    </div>
  );
}
