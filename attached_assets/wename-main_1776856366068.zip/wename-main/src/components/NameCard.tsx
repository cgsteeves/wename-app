import { useState, useRef, useImperativeHandle, forwardRef } from "react";
import {
  motion,
  useMotionValue,
  useTransform,
  useAnimate,
  PanInfo,
  AnimatePresence,
  MotionValue,
} from "framer-motion";
import { RotateCcw, Info, X, MapPin, Sparkles, TrendingUp, Heart, Tag } from "lucide-react";
import boyCardBg from "../assets/boy-card-rolling-hills.jpg";

export interface NameCardHandle {
  triggerSwipe: (liked: boolean) => void;
}

interface NameCardProps {
  name: string;
  pronunciation?: string | null;
  origin?: string | null;
  meaning?: string | null;
  nickname?: string | null;
  rank?: number | null;
  gender: "boy" | "girl";
  remaining: number;
  lastName?: string;
  onSwipe: (liked: boolean) => void;
  onUndo?: () => void;
  canUndo?: boolean;
  isNext?: boolean;
  dragProgress?: MotionValue<number>;
  isPartnerPick?: boolean;
}

const SWIPE_THRESHOLD_RATIO = 0.27;
const VELOCITY_THRESHOLD = 600;
const MAX_ROTATION = 18;

const NameCard = forwardRef<NameCardHandle, NameCardProps>(function NameCard(
  {
    name,
    pronunciation,
    origin,
    meaning,
    nickname,
    rank,
    gender,
    remaining,
    lastName,
    onSwipe,
    onUndo,
    canUndo = false,
    isNext = false,
    dragProgress,
    isPartnerPick = false,
  },
  ref
) {
  const [showInfo, setShowInfo] = useState(false);
  const x = useMotionValue(0);
  const isDragging = useRef(false);
  const hasCommitted = useRef(false);
  const [cardRef, animate] = useAnimate();

  const screenWidth = typeof window !== "undefined" ? window.innerWidth : 390;
  const DISTANCE_THRESHOLD = screenWidth * SWIPE_THRESHOLD_RATIO;

  const rotate = useTransform(x, [-screenWidth * 0.6, 0, screenWidth * 0.6], [-MAX_ROTATION, 0, MAX_ROTATION]);
  const cardOpacity = useTransform(x, [-screenWidth * 0.6, -DISTANCE_THRESHOLD * 0.5, 0, DISTANCE_THRESHOLD * 0.5, screenWidth * 0.6], [0.55, 0.9, 1, 0.9, 0.55]);

  const likeOpacity = useTransform(x, [0, DISTANCE_THRESHOLD * 0.5, DISTANCE_THRESHOLD], [0, 0.7, 1]);
  const likeScale = useTransform(x, [0, DISTANCE_THRESHOLD], [0.7, 1.15]);
  const passOpacity = useTransform(x, [-DISTANCE_THRESHOLD, -DISTANCE_THRESHOLD * 0.5, 0], [1, 0.7, 0]);
  const passScale = useTransform(x, [-DISTANCE_THRESHOLD, 0], [1.15, 0.7]);

  const fallbackProgress = useMotionValue(0);
  const resolvedProgress = dragProgress ?? fallbackProgress;
  const nextScaleVal = useTransform(resolvedProgress, [0, 1], [0.95, 1]);
  const nextTranslateYVal = useTransform(resolvedProgress, [0, 1], [14, 0]);

  const isBoy = gender === "boy";
  const bgImage = isBoy ? boyCardBg : "/girl-card-flowers.jpg";
  const label = isBoy ? "Boy Name" : "Girl Name";
  const accentColor = isBoy ? "text-boy" : "text-girl-red";
  const accentBg = isBoy ? "bg-boy" : "bg-girl";

  const triggerHaptic = () => {
    if ("vibrate" in navigator) navigator.vibrate(12);
  };

  const commitSwipe = (liked: boolean, velocityX = 0) => {
    if (hasCommitted.current) return;
    hasCommitted.current = true;

    const direction = liked ? 1 : -1;
    const velocityBonus = Math.min(Math.abs(velocityX) / 1000, 1.8);
    const exitX = direction * (screenWidth * (1.8 + velocityBonus * 0.6));
    const duration = Math.max(0.22, 0.42 - velocityBonus * 0.1);

    triggerHaptic();
    dragProgress?.set(1);

    animate(
      cardRef.current,
      { x: exitX, opacity: 0 },
      { type: "tween", duration, ease: [0.25, 0.46, 0.45, 0.94] }
    );

    setTimeout(() => {
      onSwipe(liked);
    }, duration * 1000 * 0.55);
  };

  const handleDragStart = () => {
    isDragging.current = true;
    hasCommitted.current = false;
  };

  const handleDrag = (_: unknown, info: PanInfo) => {
    const offset = info.offset.x;
    x.set(offset);
    if (dragProgress) {
      const progress = Math.min(Math.abs(offset) / DISTANCE_THRESHOLD, 1);
      dragProgress.set(progress);
    }
  };

  const handleDragEnd = (_: unknown, info: PanInfo) => {
    isDragging.current = false;
    const offset = info.offset.x;
    const velocity = info.velocity.x;

    const pastDistanceThreshold = Math.abs(offset) > DISTANCE_THRESHOLD;
    const pastVelocityThreshold = Math.abs(velocity) > VELOCITY_THRESHOLD;

    if (!pastDistanceThreshold && !pastVelocityThreshold) {
      x.set(0);
      dragProgress?.set(0);
      hasCommitted.current = false;
      return;
    }

    const liked = offset > 0 || (Math.abs(offset) <= 10 && velocity > 0);
    commitSwipe(liked, velocity);
  };

  const triggerSwipe = (liked: boolean) => {
    commitSwipe(liked, 0);
  };

  useImperativeHandle(ref, () => ({ triggerSwipe }));

  const handleOverlayDragEnd = (_: unknown, info: PanInfo) => {
    if (info.offset.y > 80) setShowInfo(false);
  };

  const motionStyle = isNext
    ? { scale: nextScaleVal, y: nextTranslateYVal, transformOrigin: "bottom center", zIndex: 0 }
    : { x, rotate, opacity: cardOpacity, zIndex: 1 };

  return (
    <motion.div
      ref={isNext ? undefined : cardRef}
      className="absolute inset-0"
      style={motionStyle}
      {...(!isNext && {
        initial: { scale: 1, opacity: 1 },
        animate: { scale: 1, opacity: 1 },
      })}
    >
      <div className="relative w-full h-full rounded-2xl overflow-hidden shadow-2xl bg-parchment border-2 border-border/40">
        <img
          src={bgImage}
          alt=""
          className="absolute inset-0 w-full h-full object-cover"
          draggable={false}
        />

        <div
          className="absolute inset-0 pointer-events-none"
          style={{ background: "radial-gradient(ellipse at center, transparent 0%, transparent 60%, rgba(0,0,0,0.15) 100%)" }}
        />
        <div className="absolute inset-0 bg-parchment/5 pointer-events-none mix-blend-overlay" />

        {!isNext && (
          <>
            <motion.div
              className="absolute top-5 right-4 z-20 pointer-events-none"
              style={{ opacity: likeOpacity, scale: likeScale, transformOrigin: "top right" }}
            >
              <motion.img
                src="/like_sun2.png"
                alt=""
                className="w-40 h-40"
                draggable={false}
              />
              <div className="absolute top-7 right-7 flex items-center justify-center">
                <span
                  className="text-white font-display font-black text-lg tracking-widest uppercase"
                  style={{
                    textShadow: "0 1px 4px rgba(0,0,0,0.35)",
                    letterSpacing: "0.18em",
                    transform: "rotate(22deg)",
                  }}
                >
                  LIKE
                </span>
              </div>
            </motion.div>

            <motion.div
              className="absolute top-5 left-4 z-20 pointer-events-none"
              style={{ opacity: passOpacity, scale: passScale, transformOrigin: "top left" }}
            >
              <motion.img
                src="/dislike_sun.png"
                alt=""
                className="w-40 h-40"
                draggable={false}
              />
              <div className="absolute top-7 left-7 flex items-center justify-center">
                <span
                  className="text-white font-display font-black text-lg tracking-widest uppercase"
                  style={{
                    textShadow: "0 1px 4px rgba(0,0,0,0.35)",
                    letterSpacing: "0.18em",
                    transform: "rotate(-22deg)",
                  }}
                >
                  PASS
                </span>
              </div>
            </motion.div>
          </>
        )}

        {!showInfo && !isNext && (
          <motion.div
            className="absolute inset-x-0 top-0 bottom-32 cursor-grab active:cursor-grabbing z-10"
            drag="x"
            dragConstraints={{ left: 0, right: 0 }}
            dragElastic={0.18}
            dragMomentum={false}
            onDragStart={handleDragStart}
            onDrag={handleDrag}
            onDragEnd={handleDragEnd}
            style={{ x, touchAction: "pan-y" }}
          />
        )}

        <div className="relative z-20 flex flex-col h-full pointer-events-none">
          <div className="pt-5 pb-2 px-6 pointer-events-none relative z-20">
            <p className={`font-hand text-3xl italic text-center ${isBoy ? "text-boy" : "text-girl-pink"}`}>
              {label}
            </p>
            <div className={`h-[1.5px] mx-auto w-28 mt-0.5 rounded-full opacity-50 ${accentBg}`} />
            <p className="text-muted-foreground text-sm text-center mt-1 font-display">
              {remaining} names remaining
            </p>
            <div
              className="flex justify-center mt-2 pointer-events-auto relative z-50"
              style={{ visibility: isNext ? "hidden" : "visible" }}
            >
              <button
                onClick={() => setShowInfo(true)}
                className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-display border transition-all active:scale-95 cursor-pointer ${
                  isBoy
                    ? "border-boy/30 text-boy/70 hover:bg-boy/10"
                    : "border-girl/30 text-girl-pink/70 hover:bg-girl/10"
                }`}
                style={{ background: "rgba(255,255,255,0.35)" }}
              >
                <Info size={12} />
                <span>More info</span>
              </button>
            </div>
          </div>

          <div className="flex-1 flex flex-col items-center justify-center -mt-28 pointer-events-none">
            <h1 className={`text-6xl font-bold font-display tracking-tight ${accentColor}`}>
              {name}
            </h1>
            {lastName && (
              <p className={`text-3xl font-display font-semibold mt-2 ${isBoy ? "text-boy/80" : "text-girl-red"}`}>
                {lastName}
              </p>
            )}
            {pronunciation && (
              <p className={`text-base font-display italic mt-1 tracking-wide ${isBoy ? "text-boy/60" : "text-girl-red/60"}`}>
                [{pronunciation}]
              </p>
            )}
            {isPartnerPick && !isNext && (
              <div className={`mt-3 flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-display font-medium border ${
                isBoy
                  ? "bg-boy/10 border-boy/20 text-boy"
                  : "bg-girl/10 border-girl/20 text-girl-red"
              }`}>
                <Heart size={10} fill="currentColor" />
                <span>Partner Added</span>
              </div>
            )}
          </div>

          <div
            className="flex items-center justify-center gap-6 mb-6 px-8 pointer-events-auto"
            style={{ visibility: isNext ? "hidden" : "visible" }}
          >
            <ActionButton onClick={() => triggerSwipe(false)}>
              <span
                className="text-destructive text-3xl font-bold"
                style={{ filter: "drop-shadow(0 1px 2px rgba(0,0,0,0.2))" }}
              >
                ✕
              </span>
            </ActionButton>
            <button
              onClick={() => onUndo?.()}
              disabled={!canUndo}
              className={`w-14 h-14 rounded-full shadow-xl border-2 border-white/60 flex items-center justify-center active:scale-90 transition-all ${
                canUndo ? "hover:shadow-2xl cursor-pointer" : "opacity-40 cursor-not-allowed"
              }`}
              style={{
                boxShadow: canUndo
                  ? "0 6px 20px rgba(0, 0, 0, 0.25), 0 2px 6px rgba(0, 0, 0, 0.15), inset 0 1px 2px rgba(255, 255, 255, 0.8)"
                  : "0 2px 8px rgba(0, 0, 0, 0.15)",
                background: "linear-gradient(145deg, hsl(38 50% 96%) 0%, hsl(38 45% 92%) 100%)",
              }}
            >
              <RotateCcw
                className="text-muted-foreground"
                size={22}
                style={{ filter: "drop-shadow(0 1px 2px rgba(0,0,0,0.2))" }}
              />
            </button>
            <ActionButton onClick={() => triggerSwipe(true)}>
              <Heart
                className="text-rose-500 fill-rose-500"
                size={26}
                style={{ filter: "drop-shadow(0 1px 2px rgba(0,0,0,0.2))" }}
              />
            </ActionButton>
          </div>
        </div>

        <AnimatePresence>
          {showInfo && !isNext && (
            <motion.div
              className="absolute inset-0 z-30 rounded-2xl overflow-hidden cursor-default"
              drag="y"
              dragConstraints={{ top: 0, bottom: 0 }}
              dragElastic={{ top: 0, bottom: 0.4 }}
              onDragEnd={handleOverlayDragEnd}
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{ type: "spring", stiffness: 350, damping: 35 }}
              style={{
                background: isBoy
                  ? "linear-gradient(160deg, rgba(219,234,254,0.99) 0%, rgba(191,219,254,0.97) 50%, rgba(255,251,235,0.99) 100%)"
                  : "linear-gradient(160deg, rgba(254,228,232,0.99) 0%, rgba(251,207,215,0.97) 50%, rgba(255,251,235,0.99) 100%)",
              }}
            >
              <div
                className="absolute inset-0 opacity-20 pointer-events-none"
                style={{ backgroundImage: "url(/paper-texture.jpg)", backgroundSize: "cover" }}
              />
              <div
                className="absolute inset-0 pointer-events-none"
                style={{ background: "radial-gradient(ellipse at top, rgba(255,255,255,0.45) 0%, transparent 65%)" }}
              />

              <div className="relative flex flex-col h-full px-6 pt-4 pb-5">
                <div className="flex justify-between items-center mb-3">
                  <div className="w-10 h-1 rounded-full bg-black/15 mx-auto absolute left-1/2 -translate-x-1/2 top-3" />
                  <div className="flex-1" />
                  <button
                    onClick={() => setShowInfo(false)}
                    className="w-8 h-8 rounded-full flex items-center justify-center border border-black/10 bg-white/60 active:scale-90 transition-all cursor-pointer text-muted-foreground hover:text-foreground"
                  >
                    <X size={14} />
                  </button>
                </div>

                <div className="flex-1 flex flex-col justify-center gap-5">
                  <div className="text-center">
                    <p
                      className={`font-hand text-xl italic mb-2 ${isBoy ? "text-boy" : "text-girl-pink"}`}
                      style={{ opacity: 0.85 }}
                    >
                      About this name
                    </p>
                    <div className={`h-[1.5px] mx-auto w-24 mb-3 rounded-full opacity-40 ${accentBg}`} />
                    <h2 className={`text-5xl font-bold font-display tracking-tight ${accentColor}`}>
                      {name}
                    </h2>
                    {lastName && (
                      <p className={`text-2xl font-display font-semibold mt-1 ${isBoy ? "text-boy/80" : "text-girl-red"}`}>
                        {lastName}
                      </p>
                    )}
                    {pronunciation && (
                      <p className={`text-sm font-display italic mt-1.5 tracking-wide ${isBoy ? "text-boy/60" : "text-girl-red/60"}`}>
                        [{pronunciation}]
                      </p>
                    )}
                  </div>

                  <div className="flex flex-col gap-2">
                    <InfoRow icon={<MapPin size={15} />} label="Origin" value={origin ?? "—"} isBoy={isBoy} />
                    <InfoRow icon={<Sparkles size={15} />} label="Meaning" value={meaning ?? "—"} isBoy={isBoy} />
                    <InfoRow icon={<Tag size={15} />} label="Possible Nickname" value={nickname ?? "—"} isBoy={isBoy} />
                    <InfoRow
                      icon={<TrendingUp size={15} />}
                      label="Popularity"
                      value={rank != null ? `#${rank} most popular` : "—"}
                      isBoy={isBoy}
                    />
                  </div>
                </div>

                <div className="flex items-center justify-center gap-8 mt-4">
                  <button
                    onClick={() => { setShowInfo(false); triggerSwipe(false); }}
                    className="w-16 h-16 rounded-full shadow-xl border-2 border-white/70 flex items-center justify-center active:scale-90 transition-all hover:shadow-2xl cursor-pointer"
                    style={{
                      boxShadow: "0 6px 20px rgba(0, 0, 0, 0.2), 0 2px 6px rgba(0, 0, 0, 0.1), inset 0 1px 2px rgba(255, 255, 255, 0.9)",
                      background: "linear-gradient(145deg, hsl(38 50% 96%) 0%, hsl(38 45% 92%) 100%)",
                    }}
                  >
                    <span
                      className="text-destructive text-3xl font-bold"
                      style={{ filter: "drop-shadow(0 1px 2px rgba(0,0,0,0.2))" }}
                    >
                      ✕
                    </span>
                  </button>
                  <button
                    onClick={() => { setShowInfo(false); triggerSwipe(true); }}
                    className="w-16 h-16 rounded-full shadow-xl border-2 border-white/70 flex items-center justify-center active:scale-90 transition-all hover:shadow-2xl cursor-pointer"
                    style={{
                      boxShadow: "0 6px 20px rgba(0, 0, 0, 0.2), 0 2px 6px rgba(0, 0, 0, 0.1), inset 0 1px 2px rgba(255, 255, 255, 0.9)",
                      background: "linear-gradient(145deg, hsl(38 50% 96%) 0%, hsl(38 45% 92%) 100%)",
                    }}
                  >
                    <Heart
                      className="text-rose-500 fill-rose-500"
                      size={28}
                      style={{ filter: "drop-shadow(0 1px 2px rgba(0,0,0,0.2))" }}
                    />
                  </button>
                </div>

                <p className={`text-center text-xs font-display mt-3 ${isBoy ? "text-boy/35" : "text-girl-pink/35"}`}>
                  swipe down to close
                </p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
});

export default NameCard;

function ActionButton({ onClick, children }: { onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      className="w-16 h-16 rounded-full shadow-xl border-2 border-white/60 flex items-center justify-center active:scale-90 transition-all hover:shadow-2xl cursor-pointer"
      style={{
        boxShadow: "0 6px 20px rgba(0, 0, 0, 0.25), 0 2px 6px rgba(0, 0, 0, 0.15), inset 0 1px 2px rgba(255, 255, 255, 0.8)",
        background: "linear-gradient(145deg, hsl(38 50% 96%) 0%, hsl(38 45% 92%) 100%)",
      }}
    >
      {children}
    </button>
  );
}

function InfoRow({
  icon,
  label,
  value,
  isBoy,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  isBoy: boolean;
}) {
  const rowBg = isBoy ? "rgba(100,140,200,0.08)" : "rgba(255,160,170,0.08)";
  const rowBorder = isBoy ? "1px solid hsl(214 50% 80%)" : "1px solid hsl(345 50% 82%)";
  const accentColor = isBoy ? "hsl(214 55% 40%)" : "hsl(345 55% 48%)";
  return (
    <div
      className="flex items-start gap-3 rounded-xl px-4 py-3"
      style={{ background: rowBg, border: rowBorder }}
    >
      <div className="mt-0.5 flex-shrink-0" style={{ color: accentColor, opacity: 0.65 }}>
        {icon}
      </div>
      <div className="flex-1 min-w-0">
        <p
          className="text-[10px] font-display font-semibold uppercase tracking-widest mb-0.5"
          style={{ color: accentColor, opacity: 0.6 }}
        >
          {label}
        </p>
        <p className="font-display text-sm leading-snug text-foreground/85">{value}</p>
      </div>
    </div>
  );
}
