import { useRef, useState, useCallback, useEffect } from 'react';

interface DragHandleProps {
  onMouseDown: (e: React.MouseEvent) => void;
  onTouchStart: (e: React.TouchEvent) => void;
}

interface DraggableListProps<T> {
  items: T[];
  onReorder: (newItems: T[]) => void;
  renderItem: (item: T, index: number, isDragging: boolean, dragHandleProps: DragHandleProps) => React.ReactNode;
  keyExtractor: (item: T) => string;
}

export default function DraggableList<T>({
  items,
  onReorder,
  renderItem,
  keyExtractor,
}: DraggableListProps<T>) {
  const [draggingIndex, setDraggingIndex] = useState<number | null>(null);
  const [dragOverIndex, setDragOverIndex] = useState<number | null>(null);
  const [ghostY, setGhostY] = useState(0);
  const [ghostHeight, setGhostHeight] = useState(48);

  const containerRef = useRef<HTMLDivElement>(null);
  const itemRefs = useRef<(HTMLDivElement | null)[]>([]);

  const activeRef = useRef<{
    draggingIndex: number;
    dragOverIndex: number;
    startY: number;
    initialRelY: number;
    itemHeight: number;
    scrollInterval: ReturnType<typeof setInterval> | null;
    items: T[];
    onReorder: (newItems: T[]) => void;
  } | null>(null);

  const itemsRef = useRef(items);
  const onReorderRef = useRef(onReorder);
  useEffect(() => { itemsRef.current = items; }, [items]);
  useEffect(() => { onReorderRef.current = onReorder; }, [onReorder]);

  const getItemNaturalCenterY = useCallback((index: number): number => {
    const el = itemRefs.current[index];
    if (!el || !containerRef.current) return 0;
    const containerRect = containerRef.current.getBoundingClientRect();
    const itemRect = el.getBoundingClientRect();
    const currentTransform = el.style.transform;
    const match = currentTransform ? /translateY\((-?[\d.]+)px\)/.exec(currentTransform) : null;
    const transformOffset = match ? parseFloat(match[1]) : 0;
    const naturalTop = itemRect.top - transformOffset;
    return naturalTop - containerRect.top + containerRef.current.scrollTop + itemRect.height / 2;
  }, []);

  const getIndexAtY = useCallback((y: number, count: number): number => {
    let closest = 0;
    let closestDist = Infinity;
    for (let i = 0; i < count; i++) {
      const center = getItemNaturalCenterY(i);
      const dist = Math.abs(y - center);
      if (dist < closestDist) {
        closestDist = dist;
        closest = i;
      }
    }
    return closest;
  }, [getItemNaturalCenterY]);

  const onMove = useCallback((moveEvent: TouchEvent | MouseEvent) => {
    const state = activeRef.current;
    if (!state || !containerRef.current) return;

    const my = 'touches' in moveEvent ? (moveEvent as TouchEvent).touches[0].clientY : (moveEvent as MouseEvent).clientY;
    const dy = my - state.startY;

    const containerRect = containerRef.current.getBoundingClientRect();
    const newGhostY = Math.max(0, Math.min(
      state.initialRelY + dy,
      containerRef.current.scrollHeight - state.itemHeight
    ));
    setGhostY(newGhostY);

    const absoluteY = newGhostY + state.itemHeight / 2;
    const overIdx = getIndexAtY(absoluteY, itemsRef.current.length);
    state.dragOverIndex = overIdx;
    setDragOverIndex(overIdx);

    const viewportY = my - containerRect.top;
    const scrollZone = 60;
    if (state.scrollInterval) {
      clearInterval(state.scrollInterval);
      state.scrollInterval = null;
    }
    if (viewportY < scrollZone) {
      state.scrollInterval = setInterval(() => {
        if (containerRef.current) containerRef.current.scrollTop -= 6;
      }, 16);
    } else if (viewportY > containerRect.height - scrollZone) {
      state.scrollInterval = setInterval(() => {
        if (containerRef.current) containerRef.current.scrollTop += 6;
      }, 16);
    }
  }, [getIndexAtY]);

  const onEnd = useCallback(() => {
    const state = activeRef.current;
    if (!state) return;

    if (state.scrollInterval) {
      clearInterval(state.scrollInterval);
      state.scrollInterval = null;
    }

    const { draggingIndex: from, dragOverIndex: to } = state;
    activeRef.current = null;

    setDraggingIndex(null);
    setDragOverIndex(null);

    if (from !== to) {
      const newItems = [...itemsRef.current];
      const [moved] = newItems.splice(from, 1);
      newItems.splice(to, 0, moved);
      onReorderRef.current(newItems);
    }

    document.removeEventListener('touchmove', onMove);
    document.removeEventListener('touchend', onEnd);
    document.removeEventListener('mousemove', onMove);
    document.removeEventListener('mouseup', onEnd);
  }, [onMove]);

  const onDragHandleDown = useCallback((e: React.TouchEvent | React.MouseEvent, index: number) => {
    e.preventDefault();

    if (activeRef.current) return;

    const el = itemRefs.current[index];
    if (!el || !containerRef.current) return;

    const clientY = 'touches' in e ? e.touches[0].clientY : (e as React.MouseEvent).clientY;
    const containerRect = containerRef.current.getBoundingClientRect();
    const itemRect = el.getBoundingClientRect();
    const relativeY = itemRect.top - containerRect.top + containerRef.current.scrollTop;

    setDraggingIndex(index);
    setDragOverIndex(index);
    setGhostY(relativeY);
    setGhostHeight(itemRect.height);

    activeRef.current = {
      draggingIndex: index,
      dragOverIndex: index,
      startY: clientY,
      initialRelY: relativeY,
      itemHeight: itemRect.height,
      scrollInterval: null,
      items: itemsRef.current,
      onReorder: onReorderRef.current,
    };

    document.addEventListener('touchmove', onMove, { passive: false });
    document.addEventListener('touchend', onEnd);
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onEnd);
  }, [onMove, onEnd]);

  useEffect(() => {
    return () => {
      if (activeRef.current?.scrollInterval) {
        clearInterval(activeRef.current.scrollInterval);
      }
      document.removeEventListener('touchmove', onMove);
      document.removeEventListener('touchend', onEnd);
      document.removeEventListener('mousemove', onMove);
      document.removeEventListener('mouseup', onEnd);
    };
  }, [onMove, onEnd]);

  const getTranslateY = (index: number): number => {
    if (draggingIndex === null || dragOverIndex === null || draggingIndex === dragOverIndex) return 0;
    if (index === draggingIndex) return 0;

    const step = ghostHeight + 6;

    if (draggingIndex < dragOverIndex) {
      if (index > draggingIndex && index <= dragOverIndex) return -step;
    } else {
      if (index >= dragOverIndex && index < draggingIndex) return step;
    }
    return 0;
  };

  return (
    <div ref={containerRef} className="space-y-1.5 pt-2 relative select-none">
      {draggingIndex !== null && (
        <div
          className="absolute left-0 right-0 pointer-events-none z-50 opacity-90"
          style={{ top: ghostY, height: ghostHeight }}
        >
          {renderItem(items[draggingIndex], draggingIndex, true, { onMouseDown: () => {}, onTouchStart: () => {} })}
        </div>
      )}
      {items.map((item, index) => {
        const isBeingDragged = index === draggingIndex;
        const translateY = getTranslateY(index);

        const dragHandleProps: DragHandleProps = {
          onMouseDown: (e) => onDragHandleDown(e, index),
          onTouchStart: (e) => onDragHandleDown(e, index),
        };

        return (
          <div
            key={keyExtractor(item)}
            ref={(el) => { itemRefs.current[index] = el; }}
            className="relative"
            style={{
              visibility: isBeingDragged ? 'hidden' : 'visible',
              transform: translateY !== 0 ? `translateY(${translateY}px)` : undefined,
              transition: draggingIndex !== null ? 'transform 150ms ease' : undefined,
              zIndex: isBeingDragged ? 0 : undefined,
            }}
          >
            {renderItem(item, index, false, dragHandleProps)}
          </div>
        );
      })}
    </div>
  );
}
