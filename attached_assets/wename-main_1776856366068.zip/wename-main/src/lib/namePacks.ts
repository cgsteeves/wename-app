import { supabase, NamePack, Name, DEFAULT_PACK_SLUG } from './supabase';

export async function getCurrentUser() {
  const { data: { user } } = await supabase.auth.getUser();
  return user;
}

export async function getAllPacks(): Promise<NamePack[]> {
  const { data, error } = await supabase
    .from('name_packs')
    .select('*')
    .order('sort_order', { ascending: true });

  if (error) throw error;
  return (data as NamePack[]) ?? [];
}

export async function getUserSelectedPacks(userId: string): Promise<string[]> {
  const { data, error } = await supabase
    .from('user_selected_packs')
    .select('pack_slug')
    .eq('user_id', userId);

  if (error) throw error;

  const slugs = data?.map((row: { pack_slug: string }) => row.pack_slug) ?? [];
  return slugs.length > 0 ? slugs : [DEFAULT_PACK_SLUG];
}

export async function addUserPack(userId: string, packSlug: string): Promise<void> {
  const { error } = await supabase
    .from('user_selected_packs')
    .insert({ user_id: userId, pack_slug: packSlug });

  if (error && error.code !== '23505') throw error;
}

export async function removeUserPack(userId: string, packSlug: string): Promise<void> {
  const { error } = await supabase
    .from('user_selected_packs')
    .delete()
    .eq('user_id', userId)
    .eq('pack_slug', packSlug);

  if (error) throw error;
}

export async function setUserPack(userId: string, packSlug: string): Promise<void> {
  const { error: delError } = await supabase
    .from('user_selected_packs')
    .delete()
    .eq('user_id', userId);

  if (delError) throw delError;

  const { error: insError } = await supabase
    .from('user_selected_packs')
    .insert({ user_id: userId, pack_slug: packSlug });

  if (insError) throw insError;
}

export async function getSwipeableNames(
  userId: string,
  gender?: 'boy' | 'girl' | 'either'
): Promise<Name[]> {
  const selectedPacks = await getUserSelectedPacks(userId);

  const { data, error } = await supabase.rpc('get_swipeable_names', {
    pack_slugs: selectedPacks,
    gender_filter: gender ?? null,
  });

  if (error) throw error;
  if (!data || data.length === 0) return [];

  const clean = (val: any): string | null => {
    if (val == null || val === '\\N' || val === 'Unknown' || String(val).trim() === '') return null;
    return String(val);
  };

  return (data as any[]).map(row => ({
    id: row.id,
    text: row.text,
    gender: row.gender,
    pronunciation: clean(row.pronunciation),
    origin: clean(row.origin),
    meaning: clean(row.meaning),
    nickname: clean(row.nickname),
    rank: row.rank ?? null,
  }));
}

export function isPremiumPack(pack: NamePack): boolean {
  return pack.is_premium === true;
}
