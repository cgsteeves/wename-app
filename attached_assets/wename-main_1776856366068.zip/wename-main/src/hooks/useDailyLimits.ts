/**
 * useDailyLimits.ts
 * ─────────────────────────────────────────────────────────────────────────────
 * Central daily usage-limit system for free users.
 *
 * LIMITS (free tier only):
 *   - 30 swipes/day
 *   - 8 likes/day  (a like is always also a swipe, both counters increment)
 *   - 3 match reveals/day
 *
 * PREMIUM BYPASS:
 *   Users with plan_tier = 'premium' bypass all limits entirely.
 *
 * DAILY RESET:
 *   Before any check, the hook compares today's local calendar date (YYYY-MM-DD)
 *   against the date stored in usage_last_reset_at. If they differ (or if
 *   usage_last_reset_at is null), all counters reset to 0 in the DB and the
 *   local state is also reset.
 *
 * USAGE:
 *   const limits = useDailyLimits(user, updateUser);
 *   const allowed = await limits.checkCanSwipe(liked);  // checks + increments
 *   const matchAllowed = await limits.checkCanRevealMatch();
 *
 * The check functions return true if the action is allowed, false if blocked.
 * When blocked, the caller should show the PremiumUpgradeModal.
 */

import { useRef, useCallback } from 'react';
import { supabase, User } from '../lib/supabase';

export const FREE_LIMITS = {
  swipes: 30,
  likes: 8,
  matches: 3,
} as const;

function todayLocalDate(): string {
  const d = new Date();
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  return `${yyyy}-${mm}-${dd}`;
}

function dateFromTimestamp(ts: string | null): string | null {
  if (!ts) return null;
  return ts.slice(0, 10);
}

export function useDailyLimits(user: User, updateUser: (updates: Partial<User>) => Promise<void>) {
  // In-flight guard: prevent double-counting concurrent calls
  const resetInFlight = useRef(false);

  const isPremium = user.plan_tier === 'premium';

  /**
   * Checks if daily counters need resetting (date has rolled over) and performs
   * the reset in DB + local state if so. Returns the current (post-reset if needed)
   * count values.
   */
  const ensureResetIfNeeded = useCallback(async (): Promise<{
    swipe_count: number;
    like_count: number;
    match_count: number;
  }> => {
    const today = todayLocalDate();
    const lastReset = dateFromTimestamp(user.usage_last_reset_at);

    if (lastReset !== today && !resetInFlight.current) {
      resetInFlight.current = true;
      try {
        const resetUpdates = {
          daily_swipe_count: 0,
          daily_like_count: 0,
          daily_match_count: 0,
          usage_last_reset_at: new Date().toISOString(),
        };
        const { error } = await supabase
          .from('users')
          .update(resetUpdates)
          .eq('id', user.id);

        if (!error) {
          await updateUser(resetUpdates as Partial<User>);
        }
        return { swipe_count: 0, like_count: 0, match_count: 0 };
      } finally {
        resetInFlight.current = false;
      }
    }

    return {
      swipe_count: user.daily_swipe_count ?? 0,
      like_count: user.daily_like_count ?? 0,
      match_count: user.daily_match_count ?? 0,
    };
  }, [user.id, user.usage_last_reset_at, user.daily_swipe_count, user.daily_like_count, user.daily_match_count, updateUser]);

  /**
   * checkCanSwipe(liked)
   *
   * Call BEFORE committing a swipe to the DB.
   * - Premium users: always returns true
   * - Free users:
   *     1. Reset counts if day has rolled over
   *     2. If swipe count >= 30 → return false (block)
   *     3. If liked = true AND like count >= 8 → return false (block)
   *     4. Otherwise: increment swipe count (and like count if liked), return true
   *
   * Returns { allowed: boolean, limitType: 'swipe' | 'like' | null }
   */
  const checkCanSwipe = useCallback(async (liked: boolean): Promise<{ allowed: boolean; limitType: 'swipe' | 'like' | null }> => {
    if (isPremium) return { allowed: true, limitType: null };

    const counts = await ensureResetIfNeeded();

    // Check swipe limit first
    if (counts.swipe_count >= FREE_LIMITS.swipes) {
      return { allowed: false, limitType: 'swipe' };
    }

    // Check like limit if this is a like
    if (liked && counts.like_count >= FREE_LIMITS.likes) {
      return { allowed: false, limitType: 'like' };
    }

    // Increment swipe count (and like count if liked)
    const newSwipeCount = counts.swipe_count + 1;
    const newLikeCount = liked ? counts.like_count + 1 : counts.like_count;

    const updates: Partial<User> = {
      daily_swipe_count: newSwipeCount,
      ...(liked && { daily_like_count: newLikeCount }),
    };

    const { error } = await supabase
      .from('users')
      .update(updates)
      .eq('id', user.id);

    if (!error) {
      await updateUser(updates);
    }

    return { allowed: true, limitType: null };
  }, [isPremium, user.id, ensureResetIfNeeded, updateUser]);

  /**
   * checkCanRevealMatch()
   *
   * Call BEFORE surfacing a new match notification to the user.
   * - Premium users: always returns true
   * - Free users:
   *     1. Reset counts if day has rolled over
   *     2. If match count >= 3 → return false (block)
   *     3. Otherwise: increment match count, return true
   */
  const checkCanRevealMatch = useCallback(async (): Promise<boolean> => {
    if (isPremium) return true;

    const counts = await ensureResetIfNeeded();

    if (counts.match_count >= FREE_LIMITS.matches) {
      return false;
    }

    const newMatchCount = counts.match_count + 1;
    const updates: Partial<User> = { daily_match_count: newMatchCount };

    const { error } = await supabase
      .from('users')
      .update(updates)
      .eq('id', user.id);

    if (!error) {
      await updateUser(updates);
    }

    return true;
  }, [isPremium, user.id, ensureResetIfNeeded, updateUser]);

  return {
    isPremium,
    limits: FREE_LIMITS,
    currentCounts: {
      swipes: user.daily_swipe_count ?? 0,
      likes: user.daily_like_count ?? 0,
      matches: user.daily_match_count ?? 0,
    },
    checkCanSwipe,
    checkCanRevealMatch,
  };
}
