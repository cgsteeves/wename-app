import { useState } from 'react';
import { Trash2, AlertTriangle, CheckCircle2, Mail, ChevronLeft, ExternalLink } from 'lucide-react';
import { SubPageHeader } from './SubPageHeader';
import { useAuth } from '../../context/AuthContext';

interface DeleteAccountPageProps {
  onBack: () => void;
}

function WhatGetsDeleted() {
  return (
    <div className="space-y-3">
      <h2 className="font-display font-bold text-base text-foreground">What gets deleted</h2>
      <ul className="space-y-2">
        {[
          'Your profile and account credentials',
          'All name swipe history (likes and dislikes)',
          'All name matches with your partner',
          'Any custom names you created',
          'Your partner link (your partner\'s account is not affected)',
        ].map((item) => (
          <li key={item} className="flex items-start gap-2.5 text-sm font-display text-foreground/80 leading-relaxed">
            <span className="mt-0.5 w-4 h-4 rounded-full bg-destructive/10 flex items-center justify-center shrink-0">
              <span className="w-1.5 h-1.5 rounded-full bg-destructive block" />
            </span>
            {item}
          </li>
        ))}
      </ul>
      <p className="text-xs font-display text-muted-foreground leading-relaxed pt-1">
        This action is permanent and cannot be undone.
      </p>
    </div>
  );
}

function UnauthenticatedView() {
  const [email, setEmail] = useState('');
  const [reason, setReason] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
  const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const trimmedEmail = email.trim();
    if (!trimmedEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmedEmail)) {
      setError('Please enter a valid email address.');
      return;
    }
    setError('');
    setLoading(true);
    try {
      const res = await fetch(`${supabaseUrl}/functions/v1/submit-deletion-request`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Apikey': supabaseAnonKey,
        },
        body: JSON.stringify({ email: trimmedEmail, reason: reason.trim() || undefined }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        setError(data.error || 'Something went wrong. Please try again.');
        return;
      }
      setSubmitted(true);
    } catch {
      setError('Network error. Please check your connection and try again.');
    } finally {
      setLoading(false);
    }
  }

  if (submitted) {
    return (
      <div className="bg-card rounded-2xl border border-border/60 shadow-sm px-5 py-8 flex flex-col items-center text-center gap-4">
        <div className="w-14 h-14 rounded-full bg-green-50 flex items-center justify-center">
          <CheckCircle2 size={28} className="text-green-600" />
        </div>
        <div className="space-y-1">
          <p className="font-display font-bold text-base text-foreground">Request Received</p>
          <p className="font-display text-sm text-muted-foreground leading-relaxed">
            We'll process your deletion request within 30 days and send a confirmation to{' '}
            <span className="font-semibold text-foreground">{email.trim()}</span>.
          </p>
        </div>
        <p className="text-xs font-display text-muted-foreground">
          Questions? Email us at{' '}
          <a href="mailto:wenameapp@gmail.com" className="text-sky-600 underline underline-offset-2">
            wenameapp@gmail.com
          </a>
        </p>
      </div>
    );
  }

  return (
    <div className="bg-card rounded-2xl border border-border/60 shadow-sm px-5 py-5 space-y-6 divide-y divide-border/40">
      <WhatGetsDeleted />

      <div className="pt-6 space-y-4">
        <div className="space-y-1">
          <h2 className="font-display font-bold text-base text-foreground">Request account deletion</h2>
          <p className="text-sm font-display text-muted-foreground leading-relaxed">
            Enter the email address associated with your WeName account. We'll process your request
            within 30 days and send a confirmation email.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3">
          <div>
            <label className="block font-display text-xs font-semibold text-foreground/70 mb-1.5">
              Account email address
            </label>
            <div className="relative">
              <Mail size={14} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <input
                type="email"
                value={email}
                onChange={(e) => { setEmail(e.target.value); setError(''); }}
                placeholder="you@example.com"
                disabled={loading}
                autoComplete="email"
                className="w-full pl-9 pr-4 py-3 bg-parchment border border-border/70 rounded-xl font-display text-sm text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-2 focus:ring-destructive/20 focus:border-destructive/40 transition-all disabled:opacity-60"
              />
            </div>
          </div>

          <div>
            <label className="block font-display text-xs font-semibold text-foreground/70 mb-1.5">
              Reason for deletion <span className="font-normal text-muted-foreground">(optional)</span>
            </label>
            <textarea
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="Help us understand why you're leaving…"
              disabled={loading}
              rows={3}
              maxLength={1000}
              className="w-full px-4 py-3 bg-parchment border border-border/70 rounded-xl font-display text-sm text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-2 focus:ring-destructive/20 focus:border-destructive/40 transition-all resize-none disabled:opacity-60"
            />
          </div>

          {error && (
            <p className="text-xs text-destructive font-display flex items-start gap-1.5 leading-relaxed">
              <AlertTriangle size={12} className="shrink-0 mt-0.5" />
              {error}
            </p>
          )}

          <button
            type="submit"
            disabled={loading || !email.trim()}
            className="w-full py-3.5 bg-destructive text-white rounded-xl font-display font-bold text-sm flex items-center justify-center gap-2 active:scale-95 transition-all shadow-sm disabled:opacity-50 disabled:cursor-not-allowed disabled:active:scale-100"
          >
            <Trash2 size={15} />
            {loading ? 'Submitting…' : 'Submit Deletion Request'}
          </button>
        </form>
      </div>

      <div className="pt-5">
        <p className="text-xs font-display text-muted-foreground leading-relaxed text-center">
          Already have an account?{' '}
          <a
            href="/"
            className="text-sky-600 underline underline-offset-2"
          >
            Sign in to delete instantly
          </a>
        </p>
      </div>
    </div>
  );
}

function AuthenticatedView({ onDeleted }: { onDeleted: () => void }) {
  const { authUser, deleteAccount } = useAuth();
  const [step, setStep] = useState<'idle' | 'confirm'>('idle');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  async function handleDelete() {
    setLoading(true);
    setError('');
    try {
      await deleteAccount();
      onDeleted();
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Something went wrong. Please try again.');
      setLoading(false);
      setStep('idle');
    }
  }

  return (
    <div className="bg-card rounded-2xl border border-border/60 shadow-sm px-5 py-5 space-y-6 divide-y divide-border/40">
      <div className="space-y-3">
        <div className="flex items-center gap-3 pb-1">
          <div className="w-9 h-9 rounded-full bg-destructive/10 flex items-center justify-center shrink-0">
            <AlertTriangle size={16} className="text-destructive" />
          </div>
          <div>
            <p className="font-display font-bold text-sm text-foreground">Signed in as</p>
            <p className="font-display text-xs text-muted-foreground">{authUser?.email}</p>
          </div>
        </div>
      </div>

      <div className="pt-6">
        <WhatGetsDeleted />
      </div>

      <div className="pt-6 space-y-3">
        {step === 'idle' ? (
          <>
            <button
              onClick={() => setStep('confirm')}
              className="w-full py-3.5 bg-destructive/5 border border-destructive/30 text-destructive rounded-xl font-display font-bold text-sm flex items-center justify-center gap-2 active:scale-95 transition-all"
            >
              <Trash2 size={15} />
              Delete My Account
            </button>
            <p className="text-xs font-display text-muted-foreground text-center leading-relaxed">
              This permanently deletes all your data and cannot be undone.
            </p>
          </>
        ) : (
          <div className="space-y-3">
            <div className="bg-destructive/5 border border-destructive/20 rounded-xl px-4 py-3">
              <p className="font-display font-semibold text-sm text-destructive text-center">
                Are you absolutely sure?
              </p>
              <p className="font-display text-xs text-destructive/80 text-center mt-1 leading-relaxed">
                All your data will be permanently erased. This cannot be undone.
              </p>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => setStep('idle')}
                disabled={loading}
                className="flex-1 py-3 rounded-xl border border-border/60 bg-card font-display font-semibold text-sm text-foreground active:scale-95 transition-all disabled:opacity-50"
              >
                Cancel
              </button>
              <button
                onClick={handleDelete}
                disabled={loading}
                className="flex-1 py-3 rounded-xl bg-destructive text-white font-display font-bold text-sm flex items-center justify-center gap-2 active:scale-95 transition-all disabled:opacity-60"
              >
                <Trash2 size={14} />
                {loading ? 'Deleting…' : 'Yes, Delete'}
              </button>
            </div>
            {error && (
              <p className="text-xs text-destructive font-display text-center leading-relaxed">
                {error}
              </p>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

export function DeleteAccountPage({ onBack }: DeleteAccountPageProps) {
  const { isAuthenticated } = useAuth();
  const [deleted, setDeleted] = useState(false);

  if (deleted) {
    return (
      <div className="flex-1 min-h-0 flex flex-col bg-parchment overflow-y-auto">
        <SubPageHeader title="Delete Account" onBack={onBack} />
        <div className="flex-1 px-4 pb-12 pt-2 flex flex-col items-center justify-center gap-4 text-center">
          <div className="w-16 h-16 rounded-full bg-green-50 flex items-center justify-center">
            <CheckCircle2 size={32} className="text-green-600" />
          </div>
          <div className="space-y-1">
            <p className="font-display font-bold text-lg text-foreground">Account Deleted</p>
            <p className="font-display text-sm text-muted-foreground leading-relaxed">
              Your account and all associated data have been permanently removed.
            </p>
          </div>
          <a
            href="/"
            className="mt-2 inline-flex items-center gap-2 font-display text-sm text-sky-600 underline underline-offset-2"
          >
            Return to WeName
            <ExternalLink size={13} />
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 min-h-0 flex flex-col bg-parchment overflow-y-auto">
      <SubPageHeader title="Delete Account" onBack={onBack} />

      <div className="flex-1 px-4 pb-12 pt-2 space-y-6">
        <div className="bg-card rounded-2xl border border-border/60 shadow-sm px-5 py-5 space-y-1">
          <p className="font-display font-bold text-base text-foreground">Account Deletion</p>
          <p className="text-xs font-display text-muted-foreground">
            Official deletion request page for WeName
          </p>
        </div>

        {isAuthenticated ? (
          <AuthenticatedView onDeleted={() => setDeleted(true)} />
        ) : (
          <UnauthenticatedView />
        )}

        <p className="text-center text-xs text-muted-foreground font-display px-4 pb-2">
          Questions? Contact us at{' '}
          <a href="mailto:wenameapp@gmail.com" className="text-sky-600 underline underline-offset-2">
            wenameapp@gmail.com
          </a>
        </p>
      </div>
    </div>
  );
}

export function DeleteAccountBackButton({ onClick }: { onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="flex items-center gap-1.5 text-grass font-display font-semibold text-sm"
    >
      <ChevronLeft size={18} />
      Back
    </button>
  );
}
