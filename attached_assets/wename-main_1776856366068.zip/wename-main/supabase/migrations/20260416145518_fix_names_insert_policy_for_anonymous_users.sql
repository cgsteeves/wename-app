/*
  # Fix names INSERT policy for anonymous users

  ## Problem
  The app uses a custom users table without Supabase Auth sessions.
  auth.uid() returns NULL for all users, causing the INSERT policy
  that checks `created_by_user_id = auth.uid()` to always fail.

  ## Changes
  - Drop the two conflicting INSERT policies on names
  - Add a single permissive INSERT policy that allows inserting
    user-created names without requiring an auth session,
    since the app manages identity via its own users table
*/

DROP POLICY IF EXISTS "Authenticated users can insert their own user_created names" ON names;
DROP POLICY IF EXISTS "Authenticated users can insert user-created names" ON names;

CREATE POLICY "Anyone can insert user-created names"
  ON names
  FOR INSERT
  WITH CHECK (user_created = true);
