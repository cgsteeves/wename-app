/*
  # Add Partner Linking and Baby Settings

  1. Changes to Tables
    - `users` table
      - Add `display_name` (text) - User's display name
      - Add `user_code` (text, unique) - 8-character shareable code for partner linking
      - Add `partner_id` (uuid, nullable) - References linked partner's user ID
      - Add `baby_last_name` (text, nullable) - Shared baby's last name
      - Add `baby_gender` (text, default 'either') - Gender preference (boy/girl/either)

  2. Functions
    - `generate_user_code()` - Generates unique 8-character code on user creation

  3. Security
    - Update RLS policies to allow users to:
      - Read their partner's basic info (display_name, user_code)
      - Update their own partner_id and baby settings
*/

-- Add new columns to users table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'users' AND column_name = 'display_name'
  ) THEN
    ALTER TABLE users ADD COLUMN display_name text DEFAULT '';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'users' AND column_name = 'user_code'
  ) THEN
    ALTER TABLE users ADD COLUMN user_code text UNIQUE;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'users' AND column_name = 'partner_id'
  ) THEN
    ALTER TABLE users ADD COLUMN partner_id uuid REFERENCES users(id) ON DELETE SET NULL;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'users' AND column_name = 'baby_last_name'
  ) THEN
    ALTER TABLE users ADD COLUMN baby_last_name text DEFAULT '';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'users' AND column_name = 'baby_gender'
  ) THEN
    ALTER TABLE users ADD COLUMN baby_gender text DEFAULT 'either';
  END IF;
END $$;

-- Function to generate unique 8-character code
CREATE OR REPLACE FUNCTION generate_user_code()
RETURNS text
LANGUAGE plpgsql
AS $$
DECLARE
  chars text := 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  result text := '';
  i integer;
BEGIN
  FOR i IN 1..8 LOOP
    result := result || substr(chars, floor(random() * length(chars) + 1)::integer, 1);
  END LOOP;
  RETURN result;
END;
$$;

-- Generate codes for existing users
UPDATE users SET user_code = generate_user_code() WHERE user_code IS NULL;

-- Add RLS policy for users to read their partner's info
DROP POLICY IF EXISTS "Users can view partner info" ON users;
CREATE POLICY "Users can view partner info"
  ON users FOR SELECT
  TO authenticated
  USING (
    id = auth.uid() OR
    id IN (SELECT partner_id FROM users WHERE id = auth.uid())
  );

-- Add RLS policy for anonymous users to read their partner's info
DROP POLICY IF EXISTS "Anonymous users can view partner info" ON users;
CREATE POLICY "Anonymous users can view partner info"
  ON users FOR SELECT
  TO anon
  USING (
    id = (auth.jwt() ->> 'user_id')::uuid OR
    id IN (SELECT partner_id FROM users WHERE id = (auth.jwt() ->> 'user_id')::uuid)
  );

-- Update policy for users to update their own info including partner settings
DROP POLICY IF EXISTS "Users can update own profile" ON users;
CREATE POLICY "Users can update own profile"
  ON users FOR UPDATE
  TO authenticated
  USING (id = auth.uid())
  WITH CHECK (id = auth.uid());

-- Add policy for anonymous users to update their own info
DROP POLICY IF EXISTS "Anonymous users can update own profile" ON users;
CREATE POLICY "Anonymous users can update own profile"
  ON users FOR UPDATE
  TO anon
  USING (id = (auth.jwt() ->> 'user_id')::uuid)
  WITH CHECK (id = (auth.jwt() ->> 'user_id')::uuid);