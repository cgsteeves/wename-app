import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';

dotenv.config();

const supabase = createClient(
  process.env.VITE_SUPABASE_URL,
  process.env.VITE_SUPABASE_ANON_KEY
);

// Boy names data from CSV
const boyNamesCSV = `Liam,1,Irish,Strong-willed warrior and protector,LEE-um
Noah,2,Hebrew,Rest and comfort,NOH-uh
Oliver,3,Latin|French,Associated with the olive tree symbolizing peace,AH-lih-ver
Theodore,4,Greek,Gift of God,THEE-uh-dor
James,5,Hebrew,Supplanter or one who follows,JAYMZ
Henry,6,Germanic,Ruler of the home,HEN-ree
Mateo,7,Spanish|Hebrew,Gift of God,mah-TAY-oh
Elijah,8,Hebrew,My God is Yahweh,ih-LIE-juh
Lucas,9,Latin,Bringer of light,LOO-kas
William,10,Germanic,Resolute protector,WIL-yum`;

// Girl names data from CSV
const girlNamesCSV = `Olivia,1,Latin,Olive tree symbolizing peace,oh-LIV-ee-uh
Emma,2,Germanic,Whole or universal,EM-uh
Amelia,3,Germanic|Latin,Work or industriousness,uh-MEE-lee-uh
Charlotte,4,French|Germanic,Free woman,SHAR-lut
Mia,5,Italian|Scandinavian,Mine or beloved; also a short form of Maria,MEE-uh
Sophia,6,Greek,Wisdom,soh-FEE-uh
Isabella,7,Hebrew|Spanish,God is my oath,iz-uh-BEL-uh
Evelyn,8,English|French,Desired or little bird,EV-uh-lin
Ava,9,Latin|Germanic,Bird or life,AY-vuh
Sofia,10,Greek|Spanish,Wisdom,soh-FEE-uh`;

function parseCSV(csv, gender) {
  return csv.trim().split('\n').map(line => {
    const [name, rank, origin, meaning, pronunciation] = line.split(',');
    return {
      text: name,
      gender,
      rank: parseInt(rank),
      origin,
      meaning,
      pronunciation
    };
  });
}

async function populateNames() {
  console.log('Clearing existing names...');

  const { error: deleteError } = await supabase
    .from('names')
    .delete()
    .neq('id', '00000000-0000-0000-0000-000000000000'); // Delete all

  if (deleteError) {
    console.error('Error deleting names:', deleteError);
    return;
  }

  console.log('Parsing CSV data...');
  const boyNames = parseCSV(boyNamesCSV, 'boy');
  const girlNames = parseCSV(girlNamesCSV, 'girl');

  const allNames = [...boyNames, ...girlNames];

  console.log(`Inserting ${allNames.length} names...`);

  // Insert in batches of 100
  for (let i = 0; i < allNames.length; i += 100) {
    const batch = allNames.slice(i, i + 100);
    const { error } = await supabase
      .from('names')
      .insert(batch);

    if (error) {
      console.error(`Error inserting batch ${i / 100 + 1}:`, error);
    } else {
      console.log(`Inserted batch ${i / 100 + 1} (${batch.length} names)`);
    }
  }

  console.log('Done!');
}

populateNames();
