/*
  # Fix user_selected_packs RLS for anon role

  ## Problem
  The app uses custom user UUIDs stored in localStorage with no Supabase Auth session.
  All requests run as the `anon` role, so auth.uid() is always null.
  The existing policies check auth.uid() = user_id which never matches, blocking all reads/writes.

  ## Changes
  - Drop all existing policies that rely on auth.uid()
  - Recreate SELECT, INSERT, DELETE policies for anon + authenticated roles
    that allow access based on the user_id column directly (no auth session required)
*/

DROP POLICY IF EXISTS "Users can view their own selected packs" ON user_selected_packs;
DROP POLICY IF EXISTS "Users can insert their own selected packs" ON user_selected_packs;
DROP POLICY IF EXISTS "Users can update their own selected packs" ON user_selected_packs;
DROP POLICY IF EXISTS "Users can delete their own selected packs" ON user_selected_packs;

CREATE POLICY "Anon users can read selected packs"
  ON user_selected_packs FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Anon users can insert selected packs"
  ON user_selected_packs FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Anon users can delete selected packs"
  ON user_selected_packs FOR DELETE
  TO anon, authenticated
  USING (true);
