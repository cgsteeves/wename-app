export interface NameForShare {
  name: string;
  gender: 'boy' | 'girl';
  meaning?: string;
}

export async function generateNameListImage(
  names: NameForShare[],
  title: string
): Promise<Blob> {
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d')!;

  const width = 1080;
  const padding = 60;
  const lineHeight = 80;
  const titleHeight = 120;
  const footerHeight = 80;
  const nameStartY = padding + titleHeight;

  const contentHeight = names.length * lineHeight + padding;
  const height = nameStartY + contentHeight + footerHeight;

  canvas.width = width;
  canvas.height = height;

  const gradient = ctx.createLinearGradient(0, 0, 0, height);
  gradient.addColorStop(0, '#FFF8E7');
  gradient.addColorStop(1, '#F5E6D3');
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, width, height);

  ctx.fillStyle = '#8B7355';
  ctx.font = 'bold 64px Georgia, serif';
  ctx.textAlign = 'center';
  ctx.fillText(title, width / 2, padding + 70);

  ctx.textAlign = 'left';
  ctx.font = '48px Georgia, serif';

  names.forEach((nameData, index) => {
    const y = nameStartY + (index * lineHeight) + 50;

    ctx.fillStyle = nameData.gender === 'boy' ? '#4A90E2' : '#E91E63';
    ctx.fillText(`${index + 1}. ${nameData.name}`, padding, y);

    if (nameData.meaning) {
      ctx.fillStyle = '#6B5744';
      ctx.font = 'italic 32px Georgia, serif';
      const meaningY = y + 35;
      const maxWidth = width - (padding * 2) - 100;
      const meaning = nameData.meaning.length > 60
        ? nameData.meaning.substring(0, 60) + '...'
        : nameData.meaning;
      ctx.fillText(meaning, padding + 60, meaningY);
      ctx.font = '48px Georgia, serif';
    }
  });

  ctx.fillStyle = '#A0826D';
  ctx.font = 'italic 28px Georgia, serif';
  ctx.textAlign = 'center';
  ctx.fillText('Created with OurBabyName', width / 2, height - 40);

  return new Promise((resolve) => {
    canvas.toBlob((blob) => {
      resolve(blob!);
    }, 'image/png');
  });
}

export async function shareNameList(
  names: NameForShare[],
  title: string,
  fallbackMessage: string
): Promise<void> {
  if (names.length === 0) {
    alert('No names to share!');
    return;
  }

  try {
    const blob = await generateNameListImage(names, title);
    const file = new File([blob], 'baby-names.png', { type: 'image/png' });

    if (navigator.share && navigator.canShare?.({ files: [file] })) {
      await navigator.share({
        title: title,
        text: fallbackMessage,
        files: [file],
      });
    } else if (navigator.share) {
      await navigator.share({
        title: title,
        text: fallbackMessage,
      });
    } else {
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'baby-names.png';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }
  } catch (error) {
    if ((error as Error).name !== 'AbortError') {
      console.error('Error sharing:', error);
      alert('Unable to share. Please try again.');
    }
  }
}
