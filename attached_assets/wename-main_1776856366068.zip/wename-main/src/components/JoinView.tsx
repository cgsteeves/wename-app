import { useEffect, useState, useRef } from 'react';
import { Heart, AlertCircle, CheckCircle2, Loader } from 'lucide-react';
import { supabase, PartnerInvite } from '../lib/supabase';
import { getInviteByToken, acceptInvite } from '../services/inviteService';

const USER_ID_KEY = 'baby_picker_user_id';

interface JoinViewProps {
  token: string;
}

type State =
  | { phase: 'loading' }
  | { phase: 'invalid'; message: string }
  | { phase: 'confirm'; invite: PartnerInvite; inviterName: string }
  | { phase: 'joining'; inviterName: string }
  | { phase: 'success'; inviterName: string }
  | { phase: 'error'; message: string };

function generateInviteCode(): string {
  return Math.random().toString(36).substring(2, 10).toUpperCase();
}

export function JoinView({ token }: JoinViewProps) {
  const [state, setState] = useState<State>({ phase: 'loading' });
  const inviteRef = useRef<PartnerInvite | null>(null);
  const inviterNameRef = useRef<string>('Your partner');

  useEffect(() => {
    validateToken();
  }, [token]);

  async function validateToken() {
    setState({ phase: 'loading' });

    const invite = await getInviteByToken(token);
    if (!invite) {
      setState({ phase: 'invalid', message: 'This invite link is invalid or has already been used.' });
      return;
    }

    inviteRef.current = invite;

    const { data: inviterData } = await supabase
      .from('users')
      .select('display_name')
      .eq('id', invite.inviter_id)
      .maybeSingle();

    const name = inviterData?.display_name || 'Your partner';
    inviterNameRef.current = name;
    setState({ phase: 'confirm', invite, inviterName: name });
  }

  async function handleJoin() {
    const invite = inviteRef.current;
    const inviterName = inviterNameRef.current;
    if (!invite) return;

    setState({ phase: 'joining', inviterName });

    let userId = localStorage.getItem(USER_ID_KEY);

    if (!userId) {
      const { data, error } = await supabase
        .from('users')
        .insert({ invite_code: generateInviteCode() })
        .select()
        .single();

      console.log('[JoinView] user create result:', { data, error });

      if (error || !data) {
        setState({ phase: 'error', message: `Failed to set up your account: ${error?.message ?? 'unknown error'}` });
        return;
      }
      userId = data.id;
      localStorage.setItem(USER_ID_KEY, userId);
    }

    console.log('[JoinView] calling acceptInvite with token:', invite.token, 'joiner:', userId);
    const result = await acceptInvite(invite, userId);
    console.log('[JoinView] acceptInvite result:', result);

    if (!result.success) {
      setState({ phase: 'error', message: result.error ?? 'Something went wrong.' });
      return;
    }

    setState({ phase: 'success', inviterName });
  }

  function goHome() {
    window.location.href = '/';
  }

  return (
    <div className="min-h-screen bg-parchment flex items-center justify-center px-4">
      <div className="w-full max-w-sm">

        {state.phase === 'loading' && (
          <div className="text-center space-y-4">
            <Loader size={36} className="text-rose-400 mx-auto animate-spin" />
            <p className="font-display text-sm text-muted-foreground">Checking your invite...</p>
          </div>
        )}

        {state.phase === 'invalid' && (
          <div className="bg-card rounded-3xl border border-border/60 shadow-sm px-6 py-8 text-center space-y-4">
            <div className="w-16 h-16 rounded-2xl bg-destructive/10 border border-destructive/20 flex items-center justify-center mx-auto">
              <AlertCircle size={28} className="text-destructive" />
            </div>
            <div>
              <h2 className="font-hand text-2xl text-foreground font-bold mb-2">Link not valid</h2>
              <p className="font-display text-sm text-muted-foreground leading-relaxed">{state.message}</p>
            </div>
            <button
              onClick={goHome}
              className="w-full py-3.5 bg-boy text-white rounded-xl font-display font-bold text-sm active:scale-95 transition-all shadow-md"
            >
              Go to app
            </button>
          </div>
        )}

        {state.phase === 'confirm' && (
          <div className="bg-card rounded-3xl border border-border/60 shadow-sm px-6 py-8 text-center space-y-5">
            <div className="w-16 h-16 rounded-full bg-rose-100 flex items-center justify-center mx-auto">
              <Heart size={28} className="text-rose-500 fill-rose-500" />
            </div>
            <div>
              <h2 className="font-hand text-2xl text-grass font-bold mb-2">You're invited!</h2>
              <p className="font-display text-sm text-muted-foreground leading-relaxed">
                <span className="font-semibold text-foreground">{state.inviterName}</span> wants to find baby names together with you.
              </p>
            </div>
            <button
              onClick={handleJoin}
              className="w-full py-3.5 bg-rose-500 text-white rounded-xl font-display font-bold text-sm flex items-center justify-center gap-2 active:scale-95 transition-all shadow-md hover:bg-rose-600"
            >
              <Heart size={15} className="fill-white" />
              Join and connect
            </button>
            <button
              onClick={goHome}
              className="w-full py-3 text-muted-foreground font-display text-sm active:opacity-70 transition-opacity"
            >
              Maybe later
            </button>
          </div>
        )}

        {state.phase === 'joining' && (
          <div className="text-center space-y-4">
            <Loader size={36} className="text-rose-400 mx-auto animate-spin" />
            <p className="font-display text-sm text-muted-foreground">Connecting you...</p>
          </div>
        )}

        {state.phase === 'success' && (
          <div className="bg-card rounded-3xl border border-border/60 shadow-sm px-6 py-8 text-center space-y-5">
            <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mx-auto">
              <CheckCircle2 size={28} className="text-grass" />
            </div>
            <div>
              <h2 className="font-hand text-2xl text-grass font-bold mb-2">You're connected!</h2>
              <p className="font-display text-sm text-muted-foreground leading-relaxed">
                You and <span className="font-semibold text-foreground">{state.inviterName}</span> are now linked. Start swiping to find names you both love.
              </p>
            </div>
            <button
              onClick={goHome}
              className="w-full py-3.5 bg-grass text-white rounded-xl font-display font-bold text-sm active:scale-95 transition-all shadow-md"
            >
              Start swiping
            </button>
          </div>
        )}

        {state.phase === 'error' && (
          <div className="bg-card rounded-3xl border border-border/60 shadow-sm px-6 py-8 text-center space-y-4">
            <div className="w-16 h-16 rounded-2xl bg-destructive/10 border border-destructive/20 flex items-center justify-center mx-auto">
              <AlertCircle size={28} className="text-destructive" />
            </div>
            <div>
              <h2 className="font-hand text-2xl text-foreground font-bold mb-2">Something went wrong</h2>
              <p className="font-display text-sm text-muted-foreground leading-relaxed">{state.message}</p>
            </div>
            <div className="space-y-2">
              <button
                onClick={validateToken}
                className="w-full py-3.5 bg-rose-500 text-white rounded-xl font-display font-bold text-sm active:scale-95 transition-all shadow-md"
              >
                Try again
              </button>
              <button
                onClick={goHome}
                className="w-full py-3 text-muted-foreground font-display text-sm active:opacity-70 transition-opacity"
              >
                Go to app
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
