import { useState } from 'react';
import { Mail, FileText, Lock, Info } from 'lucide-react';
import { SubPageHeader } from './SubPageHeader';
import { PrivacyPolicyPage } from './PrivacyPolicyPage';
import { TermsOfServicePage } from './TermsOfServicePage';
import { ContactPage } from './ContactPage';

interface SupportPageProps {
  onBack: () => void;
}

interface LinkRowProps {
  icon: React.ReactNode;
  label: string;
  onClick: () => void;
}

function LinkRow({ icon, label, onClick }: LinkRowProps) {
  return (
    <button
      onClick={onClick}
      className="w-full flex items-center gap-3 py-3.5 text-left active:opacity-70 transition-opacity"
    >
      <div className="text-muted-foreground shrink-0">{icon}</div>
      <span className="flex-1 font-display font-semibold text-sm text-foreground">{label}</span>
      <span className="text-muted-foreground text-xs">›</span>
    </button>
  );
}

export function SupportPage({ onBack }: SupportPageProps) {
  const [showContact, setShowContact] = useState(false);
  const [showPrivacyPolicy, setShowPrivacyPolicy] = useState(false);
  const [showTerms, setShowTerms] = useState(false);
  const appVersion = '1.0.0';

  if (showContact) {
    return <ContactPage onBack={() => setShowContact(false)} />;
  }

  if (showPrivacyPolicy) {
    return <PrivacyPolicyPage onBack={() => setShowPrivacyPolicy(false)} />;
  }

  if (showTerms) {
    return <TermsOfServicePage onBack={() => setShowTerms(false)} />;
  }

  return (
    <div className="flex-1 min-h-0 flex flex-col bg-parchment overflow-y-auto relative">
      <SubPageHeader title="Support & Legal" onBack={onBack} />

      <div className="flex-1 px-4 pb-10 pt-2 space-y-4">
        <div className="bg-card rounded-2xl border border-border/60 shadow-sm px-4 divide-y divide-border/50">
          <LinkRow
            icon={<Mail size={16} />}
            label="Contact Support"
            onClick={() => setShowContact(true)}
          />
        </div>

        <p className="text-xs font-display font-semibold text-muted-foreground uppercase tracking-wider px-1">
          Legal
        </p>

        <div className="bg-card rounded-2xl border border-border/60 shadow-sm px-4 divide-y divide-border/50">
          <LinkRow
            icon={<Lock size={16} />}
            label="Privacy Policy"
            onClick={() => setShowPrivacyPolicy(true)}
          />
          <LinkRow
            icon={<FileText size={16} />}
            label="Terms of Service"
            onClick={() => setShowTerms(true)}
          />
        </div>

        <div className="bg-card rounded-2xl border border-border/60 shadow-sm px-4 py-4 flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-muted flex items-center justify-center shrink-0">
            <Info size={16} className="text-muted-foreground" />
          </div>
          <div>
            <p className="font-display font-semibold text-sm text-foreground">App Version</p>
            <p className="text-xs text-muted-foreground font-display">{appVersion}</p>
          </div>
        </div>

        <p className="text-center text-xs text-muted-foreground font-display px-4 pt-2">
          WeName — made with love for growing families
        </p>
      </div>
    </div>
  );
}
