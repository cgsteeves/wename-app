import { useState, useEffect } from 'react';
import { supabase, User } from '../lib/supabase';
import { SettingsHub, SettingsSubPage } from './settings/SettingsHub';
import { ProfilePage } from './settings/ProfilePage';
import { PartnerPage } from './settings/PartnerPage';
import { PremiumPage } from './settings/PremiumPage';
import { AccountPage } from './settings/AccountPage';
import { SupportPage } from './settings/SupportPage';
import { NamePacksPage } from './settings/NamePacksPage';

interface SettingsPageProps {
  user: User;
  onUpdate: (updates: Partial<User>) => void;
  onRemovePartner: () => void;
  onClose: () => void;
  initialPage?: SettingsSubPage | null;
}

export default function SettingsPage({ user, onUpdate, onRemovePartner, initialPage }: SettingsPageProps) {
  const [activePage, setActivePage] = useState<SettingsSubPage | null>(initialPage ?? null);
  const [partnerName, setPartnerName] = useState<string | null>(null);

  useEffect(() => {
    if (!user.partner_id) { setPartnerName(null); return; }
    supabase
      .from('users')
      .select('display_name')
      .eq('id', user.partner_id)
      .maybeSingle()
      .then(({ data }) => setPartnerName(data?.display_name || 'Partner'));
  }, [user.partner_id]);

  async function handleUpdate(updates: Partial<User>) {
    await onUpdate(updates);
  }

  async function handleResetSwipes() {
    if (!confirm('Are you sure you want to reset all your swipes? This cannot be undone.')) return;
    try {
      await supabase.from('swipes').delete().eq('user_id', user.id).eq('liked', false);
      localStorage.removeItem(`swipe_session_v2_${user.id}`);
      alert('Swipes reset successfully!');
      window.location.reload();
    } catch (error) {
      console.error('Error resetting swipes:', error);
      alert('Failed to reset swipes');
    }
  }

  if (activePage === 'profile') {
    return (
      <ProfilePage
        user={user}
        onBack={() => setActivePage(null)}
        onUpdate={handleUpdate}
        onResetSwipes={handleResetSwipes}
      />
    );
  }

  if (activePage === 'partner') {
    return (
      <PartnerPage
        user={user}
        onBack={() => setActivePage(null)}
        onUpdate={handleUpdate}
        onRemovePartner={onRemovePartner}
      />
    );
  }

  if (activePage === 'premium') {
    return <PremiumPage user={user} onBack={() => setActivePage(null)} />;
  }

  if (activePage === 'account') {
    return <AccountPage onBack={() => setActivePage(null)} />;
  }

  if (activePage === 'support') {
    return <SupportPage onBack={() => setActivePage(null)} />;
  }

  if (activePage === 'namepacks') {
    return (
      <NamePacksPage
        user={user}
        onBack={() => setActivePage(null)}
        onNavigateToPremium={() => setActivePage('premium')}
      />
    );
  }

  return (
    <SettingsHub
      user={user}
      partnerName={partnerName}
      onNavigate={setActivePage}
    />
  );
}
