/*
  # Add daily usage tracking columns to users table

  ## Summary
  Adds four columns to the public.users table to support per-user daily usage limits
  for the free tier. This implements Option A (simple column-based tracking).

  ## New Columns on public.users
  - `daily_swipe_count` (integer, default 0) — number of swipes performed today
  - `daily_like_count` (integer, default 0) — number of likes performed today (subset of swipes)
  - `daily_match_count` (integer, default 0) — number of new match reveals surfaced today
  - `usage_last_reset_at` (timestamptz, nullable) — timestamp of the last daily reset; NULL means never reset

  ## How Daily Reset Works
  Before any tracked action, the app checks whether the current calendar date (in the
  user's local timezone, falling back to UTC) differs from the date in `usage_last_reset_at`.
  If different, all three counters reset to 0 and `usage_last_reset_at` is set to now().

  ## Premium Bypass
  Users with plan_tier = 'premium' skip all limit checks entirely. Only free users
  (plan_tier = 'free' or NULL) are subject to limits.

  ## Security
  Existing RLS policies on public.users already restrict reads/writes to the owning
  authenticated user, so no new policies are needed.
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' AND table_name = 'users' AND column_name = 'daily_swipe_count'
  ) THEN
    ALTER TABLE public.users ADD COLUMN daily_swipe_count integer NOT NULL DEFAULT 0;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' AND table_name = 'users' AND column_name = 'daily_like_count'
  ) THEN
    ALTER TABLE public.users ADD COLUMN daily_like_count integer NOT NULL DEFAULT 0;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' AND table_name = 'users' AND column_name = 'daily_match_count'
  ) THEN
    ALTER TABLE public.users ADD COLUMN daily_match_count integer NOT NULL DEFAULT 0;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' AND table_name = 'users' AND column_name = 'usage_last_reset_at'
  ) THEN
    ALTER TABLE public.users ADD COLUMN usage_last_reset_at timestamptz;
  END IF;
END $$;
