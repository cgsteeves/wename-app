/*
  # Add ranking columns for custom name ordering

  1. Changes
    - Add `ranking` column to `swipes` table
      - Type: integer
      - Nullable: true (to allow null for unranked items)
      - Default: null
    - Add `ranking` column to `matches` table
      - Type: integer
      - Nullable: true
      - Default: null
    - Add indexes on ranking for better query performance
  
  2. Purpose
    - Allows users to manually order their matched and liked names
    - Ranking 1 is the top/favorite, higher numbers are lower priority
    - Null rankings will appear after ranked items
*/

DO $$
BEGIN
  -- Add ranking to swipes table
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'swipes' AND column_name = 'ranking'
  ) THEN
    ALTER TABLE swipes ADD COLUMN ranking integer;
    CREATE INDEX IF NOT EXISTS idx_swipes_ranking ON swipes(user_id, ranking);
  END IF;

  -- Add ranking to matches table
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'matches' AND column_name = 'ranking'
  ) THEN
    ALTER TABLE matches ADD COLUMN ranking integer;
    CREATE INDEX IF NOT EXISTS idx_matches_ranking ON matches(ranking);
  END IF;
END $$;