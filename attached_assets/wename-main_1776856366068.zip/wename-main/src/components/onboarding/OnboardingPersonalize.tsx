import { useState } from 'react';
import { motion } from 'framer-motion';

type Gender = 'boy' | 'girl' | 'either';

interface OnboardingPersonalizeProps {
  onNext: (gender: Gender, lastName: string) => void;
  onSkip: () => void;
}

const genderOptions: { value: Gender; label: string; icon: string; activeClass: string }[] = [
  { value: 'boy', label: 'Boy', icon: '👦', activeClass: 'bg-boy text-white shadow-md' },
  { value: 'girl', label: 'Girl', icon: '👧', activeClass: 'bg-girl text-white shadow-md' },
  { value: 'either', label: 'Either', icon: '✨', activeClass: 'bg-either text-white shadow-md' },
];

function StepDots({ current }: { current: number }) {
  return (
    <div className="flex justify-center gap-2 pt-14">
      {[0, 1, 2].map((i) => (
        <div
          key={i}
          className={`rounded-full transition-all duration-300 ${
            i === current ? 'w-6 h-2 bg-primary' : 'w-2 h-2 bg-border'
          }`}
        />
      ))}
    </div>
  );
}

export { StepDots };

export default function OnboardingPersonalize({ onNext, onSkip }: OnboardingPersonalizeProps) {
  const [gender, setGender] = useState<Gender>('either');
  const [lastName, setLastName] = useState('');

  return (
    <div className="relative h-dvh max-w-md mx-auto flex flex-col overflow-hidden">
      <img
        src="/onboarding-personalize-bg.jpg"
        alt=""
        className="absolute inset-0 w-full h-full object-cover"
        draggable={false}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-black/5 via-transparent to-black/15" />

      <div className="relative z-10 flex flex-col h-full px-8">
        <StepDots current={1} />

        <div className="flex-1 min-h-[6%]" />

        <motion.div
          className="flex flex-col"
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: 'easeOut' }}
        >
          <h1 className="text-2xl font-bold font-display text-foreground text-center leading-snug mb-8">
            Tell us a bit about yourself<br />and your little one
          </h1>

          <div className="bg-white/65 backdrop-blur-md rounded-3xl p-6 shadow-xl border border-white/60">
            <div className="mb-6">
              <p className="font-hand text-sm text-muted-foreground mb-3 text-center italic">
                Baby gender preference
              </p>
              <div className="flex gap-2">
                {genderOptions.map((opt) => (
                  <button
                    key={opt.value}
                    onClick={() => setGender(opt.value)}
                    className={`flex-1 py-3 rounded-2xl font-display font-semibold text-sm transition-all duration-200 active:scale-[0.97] ${
                      gender === opt.value
                        ? opt.activeClass
                        : 'bg-white/80 border border-border/60 text-muted-foreground'
                    }`}
                  >
                    <span className="mr-1">{opt.icon}</span>
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <p className="font-hand text-sm text-muted-foreground mb-3 text-center italic">
                Baby's last name (optional)
              </p>
              <input
                type="text"
                placeholder="Enter or skip for now"
                value={lastName}
                onChange={(e) => setLastName(e.target.value)}
                className="w-full px-4 py-3.5 rounded-2xl border border-border/50 bg-white/80 font-display text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary text-center"
              />
            </div>
          </div>
        </motion.div>

        <div className="flex-1 min-h-[8%]" />

        <motion.div
          className="flex flex-col gap-3 pb-14"
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2, ease: 'easeOut' }}
        >
          <button
            onClick={() => onNext(gender, lastName)}
            className="w-full py-4 rounded-2xl bg-primary text-primary-foreground font-display font-semibold text-base shadow-lg active:scale-[0.98] transition-transform"
          >
            Next
          </button>
          <button
            onClick={onSkip}
            className="w-full py-3 rounded-2xl text-foreground/60 font-display text-sm active:scale-[0.98] transition-transform"
          >
            Skip
          </button>
        </motion.div>
      </div>
    </div>
  );
}
