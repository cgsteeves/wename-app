/**
 * AuthModal.tsx
 * ─────────────────────────────────────────────────────────────────────────────
 * The sign-in / sign-up sheet.
 *
 * OPENED ONLY when the user taps an explicit "Sign in / Sign up" button.
 * This component never auto-opens.
 *
 * Auth flows supported:
 *   1. Continue with Apple  → signInWithApple() → /auth/callback
 *   2. Continue with Google → signInWithGoogle() → /auth/callback
 *   3. Continue with Email  → signInWithEmailMagicLink() → check-email screen
 *
 * All Supabase calls are delegated to authService.ts.
 * This component only handles UI state.
 */

import { useState } from 'react';
import { X, Mail, AlertCircle, ArrowLeft, CheckCircle2, Sparkles } from 'lucide-react';
import {
  signInWithGoogle,
  signInWithEmailMagicLink,
} from '../../services/authService';

interface AuthModalProps {
  onClose: () => void;
  preHeader?: string;
  title?: string;
  body?: string;
}

type Mode = 'choose' | 'email' | 'email-sent' | 'error';

function isValidEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());
}

export function AuthModal({ onClose, preHeader, title, body }: AuthModalProps) {
  const [mode, setMode] = useState<Mode>('choose');
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [loadingProvider, setLoadingProvider] = useState<'apple' | 'google' | null>(null);
  const [errorMsg, setErrorMsg] = useState('');

  function clearError() {
    if (errorMsg) setErrorMsg('');
  }

  function goBack() {
    setMode('choose');
    setEmail('');
    setErrorMsg('');
  }

  async function handleGoogle() {
    setLoadingProvider('google');
    try {
      await signInWithGoogle();
      // Page will redirect — no further UI needed here
    } catch {
      setErrorMsg('Google sign-in failed. Please try again.');
      setMode('error');
    } finally {
      setLoadingProvider(null);
    }
  }

  async function handleEmailSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!isValidEmail(email)) {
      setErrorMsg('Please enter a valid email address.');
      return;
    }
    clearError();
    setLoading(true);
    try {
      await signInWithEmailMagicLink(email);
      setMode('email-sent');
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Something went wrong. Please try again.';
      setErrorMsg(msg);
      setMode('error');
    } finally {
      setLoading(false);
    }
  }

  const anyLoading = loading || loadingProvider !== null;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center">
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={anyLoading ? undefined : onClose} />

      <div className="relative w-full max-w-md mx-auto bg-parchment rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden">
        <div
          className="absolute inset-0 opacity-30"
          style={{ backgroundImage: 'url(/paper-texture.jpg)', backgroundSize: 'cover' }}
        />

        <div className="relative z-10 px-6 pt-5 pb-10">
          {/* Drag handle (mobile only) */}
          <div className="w-10 h-1 bg-border rounded-full mx-auto mb-5 sm:hidden" />

          {/* Close button */}
          {!anyLoading && (
            <button
              onClick={onClose}
              className="absolute top-4 right-4 w-8 h-8 flex items-center justify-center rounded-full bg-card/80 text-muted-foreground hover:text-foreground transition-colors"
            >
              <X size={16} />
            </button>
          )}

          {/* Back button */}
          {mode === 'email' && !anyLoading && (
            <button
              onClick={goBack}
              className="absolute top-4 left-4 w-8 h-8 flex items-center justify-center rounded-full bg-card/80 text-muted-foreground hover:text-foreground transition-colors"
            >
              <ArrowLeft size={16} />
            </button>
          )}

          {mode === 'choose' && (
            <ChooseMode
              onGoogle={handleGoogle}
              onEmail={() => setMode('email')}
              loadingProvider={loadingProvider}
              preHeader={preHeader}
              title={title}
              body={body}
            />
          )}

          {mode === 'email' && (
            <EmailForm
              email={email}
              loading={loading}
              errorMsg={errorMsg}
              onEmailChange={(v) => { setEmail(v); clearError(); }}
              onSubmit={handleEmailSubmit}
            />
          )}

          {mode === 'email-sent' && (
            <EmailSent email={email} onClose={onClose} />
          )}

          {mode === 'error' && (
            <ErrorState
              errorMsg={errorMsg}
              onRetry={() => { setMode('choose'); setErrorMsg(''); }}
            />
          )}
        </div>
      </div>
    </div>
  );
}

// ─── Choose mode ─────────────────────────────────────────────────────────────

function ChooseMode({
  onGoogle,
  onEmail,
  loadingProvider,
  preHeader,
  title,
  body,
}: {
  onGoogle: () => void;
  onEmail: () => void;
  loadingProvider: 'apple' | 'google' | null;
  preHeader?: string;
  title?: string;
  body?: string;
}) {
  return (
    <>
      <div className="text-center mb-7 pt-2">
        <div className="w-14 h-14 rounded-2xl bg-card border border-border/60 shadow-sm flex items-center justify-center mx-auto mb-4">
          <Sparkles size={24} className="text-boy" />
        </div>
        {preHeader && (
          <p className="font-display text-xs text-muted-foreground uppercase tracking-wider mb-1.5">
            {preHeader}
          </p>
        )}
        <h2 className="font-hand text-2xl text-grass font-bold mb-2">
          {title ?? 'Create your free account'}
        </h2>
        <p className="font-display text-sm text-muted-foreground leading-relaxed">
          {body ?? 'Sign in to save your progress and sync your names across devices.'}
        </p>
      </div>

      <div className="space-y-3">
        {/* Google */}
        <button
          onClick={onGoogle}
          disabled={loadingProvider !== null}
          className="w-full py-3.5 bg-card border border-border/60 text-foreground rounded-xl font-display font-bold text-sm flex items-center justify-center gap-2.5 active:scale-95 transition-all disabled:opacity-60 disabled:active:scale-100"
        >
          {loadingProvider === 'google' ? (
            <span className="animate-pulse">Connecting to Google…</span>
          ) : (
            <>
              <GoogleIcon />
              Continue with Google
            </>
          )}
        </button>

        {/* Divider */}
        <div className="flex items-center gap-3 py-1">
          <div className="flex-1 h-px bg-border/60" />
          <span className="font-display text-xs text-muted-foreground">or</span>
          <div className="flex-1 h-px bg-border/60" />
        </div>

        {/* Email magic link */}
        <button
          onClick={onEmail}
          disabled={loadingProvider !== null}
          className="w-full py-3.5 bg-card border border-border/60 text-foreground rounded-xl font-display font-semibold text-sm flex items-center justify-center gap-2 active:scale-95 transition-all disabled:opacity-60 disabled:active:scale-100"
        >
          <Mail size={15} className="text-muted-foreground" />
          Continue with Email
        </button>
      </div>

      <p className="text-center text-xs text-muted-foreground font-display mt-5 leading-relaxed">
        By continuing you agree to our terms and privacy policy.
      </p>
    </>
  );
}

// ─── Email magic-link form ────────────────────────────────────────────────────

function EmailForm({
  email,
  loading,
  errorMsg,
  onEmailChange,
  onSubmit,
}: {
  email: string;
  loading: boolean;
  errorMsg: string;
  onEmailChange: (v: string) => void;
  onSubmit: (e: React.FormEvent) => void;
}) {
  return (
    <>
      <div className="text-center mb-6 pt-2">
        <div className="w-14 h-14 rounded-2xl bg-card border border-border/60 shadow-sm flex items-center justify-center mx-auto mb-4">
          <Mail size={22} className="text-boy" />
        </div>
        <h2 className="font-hand text-2xl text-grass font-bold mb-1">Sign in with email</h2>
        <p className="font-display text-sm text-muted-foreground leading-relaxed">
          Enter your email and we'll send you a magic sign-in link. No password needed.
        </p>
      </div>

      <form onSubmit={onSubmit} className="space-y-3">
        <div className="space-y-1.5">
          <label className="font-display text-xs font-semibold text-muted-foreground uppercase tracking-wider">
            Email address
          </label>
          <div className="relative">
            <Mail size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input
              type="email"
              value={email}
              onChange={(e) => onEmailChange(e.target.value)}
              placeholder="hello@example.com"
              className="w-full pl-10 pr-4 py-3.5 bg-card border border-border/70 rounded-xl font-display text-sm text-foreground placeholder:text-muted-foreground/60 focus:outline-none focus:ring-2 focus:ring-boy/30 focus:border-boy/50 transition-all"
              autoComplete="email"
              autoFocus
              disabled={loading}
            />
          </div>
        </div>

        {errorMsg && (
          <p className="text-xs text-destructive font-display flex items-center gap-1.5">
            <AlertCircle size={12} />
            {errorMsg}
          </p>
        )}

        <button
          type="submit"
          disabled={loading || !email}
          className="w-full py-3.5 bg-boy text-white rounded-xl font-display font-bold text-sm flex items-center justify-center gap-2 active:scale-95 transition-all shadow-md disabled:opacity-50 disabled:cursor-not-allowed disabled:active:scale-100"
        >
          {loading ? (
            <span className="animate-pulse">Sending sign-in link…</span>
          ) : (
            <>
              <Mail size={15} />
              Email me a sign-in link
            </>
          )}
        </button>
      </form>
    </>
  );
}

// ─── Email sent confirmation ──────────────────────────────────────────────────

function EmailSent({ email, onClose }: { email: string; onClose: () => void }) {
  return (
    <div className="text-center py-2">
      <div className="w-16 h-16 rounded-2xl bg-card border border-border/60 shadow-sm flex items-center justify-center mx-auto mb-5">
        <CheckCircle2 size={28} className="text-grass" />
      </div>
      <h2 className="font-hand text-2xl text-grass font-bold mb-2">Check your inbox</h2>
      <p className="font-display text-sm text-muted-foreground leading-relaxed mb-2">
        We sent a magic sign-in link to
      </p>
      <p className="font-display text-sm font-bold text-foreground mb-4">{email}</p>
      <p className="font-display text-xs text-muted-foreground leading-relaxed">
        Tap the link in the email to sign in. The link expires after 1 hour.
      </p>
      <button
        onClick={onClose}
        className="mt-6 w-full py-3 bg-card border border-border/60 rounded-xl font-display font-semibold text-sm text-foreground active:scale-95 transition-all"
      >
        Got it
      </button>
    </div>
  );
}

// ─── Error state ──────────────────────────────────────────────────────────────

function ErrorState({ errorMsg, onRetry }: { errorMsg: string; onRetry: () => void }) {
  return (
    <div className="text-center py-4">
      <div className="w-16 h-16 rounded-2xl bg-destructive/10 border border-destructive/20 flex items-center justify-center mx-auto mb-5">
        <AlertCircle size={28} className="text-destructive" />
      </div>
      <h2 className="font-hand text-2xl text-foreground font-bold mb-2">Something went wrong</h2>
      <p className="font-display text-sm text-muted-foreground leading-relaxed mb-6">
        {errorMsg || "We couldn't complete that. Please try again."}
      </p>
      <button
        onClick={onRetry}
        className="w-full py-3.5 bg-boy text-white rounded-xl font-display font-bold text-sm active:scale-95 transition-all shadow-md"
      >
        Try again
      </button>
    </div>
  );
}

// ─── Provider icons ───────────────────────────────────────────────────────────

function GoogleIcon() {
  return (
    <svg width="17" height="17" viewBox="0 0 24 24">
      <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
      <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
      <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
      <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
    </svg>
  );
}
