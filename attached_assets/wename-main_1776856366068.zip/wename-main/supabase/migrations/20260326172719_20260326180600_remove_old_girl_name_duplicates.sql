/*
  # Remove Old Girl Name Duplicates

  This migration removes old girl name entries that were incorrectly positioned.
  We keep only the enriched entries with complete origin, meaning, and pronunciation.

  ## Changes
  1. For each duplicate rank, keep only the entry with the longest meaning field
     (enriched entries have detailed meanings vs old simple ones)
*/

-- Delete older/incomplete entries for duplicate ranks
-- Keep the entry with the longest meaning (enriched data has longer descriptions)
DELETE FROM names 
WHERE id IN (
  SELECT id FROM (
    SELECT 
      id,
      ROW_NUMBER() OVER (PARTITION BY gender, rank ORDER BY LENGTH(COALESCE(meaning, '')) DESC, id) as rn
    FROM names
    WHERE gender = 'girl'
  ) ranked
  WHERE rn > 1
);