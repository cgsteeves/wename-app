/*
  # Allow authenticated users to insert user-created names

  1. Changes
    - Adds an INSERT policy on the `names` table so authenticated users can add
      custom names (user_created = true) when they manually add a name to their list.

  2. Security
    - Only authenticated users can insert
    - The inserted row must have user_created = true to prevent polluting the
      curated name catalogue with arbitrary entries
*/

CREATE POLICY "Authenticated users can insert user-created names"
  ON names
  FOR INSERT
  TO authenticated
  WITH CHECK (user_created = true);
