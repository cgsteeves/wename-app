import { ChevronLeft } from 'lucide-react';

interface SubPageHeaderProps {
  title: string;
  onBack: () => void;
  rightAction?: React.ReactNode;
}

export function SubPageHeader({ title, onBack, rightAction }: SubPageHeaderProps) {
  return (
    <div className="flex items-center justify-between px-4 pt-5 pb-3 shrink-0">
      <button
        onClick={onBack}
        className="flex items-center gap-1 text-grass font-display font-semibold text-sm active:opacity-70 transition-opacity"
      >
        <ChevronLeft size={18} />
        <span>Settings</span>
      </button>
      <h1 className="text-base font-display font-bold text-foreground">{title}</h1>
      <div className="w-16 flex justify-end">
        {rightAction ?? null}
      </div>
    </div>
  );
}
