import { supabase } from '../lib/supabase';

/**
 * Merges guest (anonymous) user data into the authenticated user account.
 *
 * Called after successful magic-link sign-in when we detect a pre-existing
 * guest session (baby_picker_user_id in localStorage differs from auth user id).
 *
 * What gets merged:
 * - Swipes: re-attributed to the authenticated user id
 * - Matches: re-attributed to the authenticated user id (user_a_id or user_b_id)
 * - Profile settings: partner link, display name, baby gender, etc.
 *
 * If there is a conflict (authenticated user already has data), guest data is
 * preserved where possible and duplicates are skipped.
 */
export async function mergeGuestData(
  guestUserId: string,
  authUserId: string
): Promise<void> {
  try {
    await mergeSwipes(guestUserId, authUserId);
    await mergeMatches(guestUserId, authUserId);
    await mergeProfileSettings(guestUserId, authUserId);
  } catch (err) {
    console.error('[mergeGuestData] Error during merge:', err);
  }
}

async function mergeSwipes(guestUserId: string, authUserId: string) {
  const { data: guestSwipes } = await supabase
    .from('swipes')
    .select('name_id, liked')
    .eq('user_id', guestUserId);

  if (!guestSwipes || guestSwipes.length === 0) return;

  const { data: authSwipes } = await supabase
    .from('swipes')
    .select('name_id')
    .eq('user_id', authUserId);

  const alreadySwiped = new Set((authSwipes || []).map((s) => s.name_id));

  const toInsert = guestSwipes
    .filter((s) => !alreadySwiped.has(s.name_id))
    .map((s) => ({ user_id: authUserId, name_id: s.name_id, liked: s.liked }));

  if (toInsert.length > 0) {
    await supabase.from('swipes').insert(toInsert);
  }
}

async function mergeMatches(guestUserId: string, authUserId: string) {
  await supabase
    .from('matches')
    .update({ user_a_id: authUserId })
    .eq('user_a_id', guestUserId);

  await supabase
    .from('matches')
    .update({ user_b_id: authUserId })
    .eq('user_b_id', guestUserId);
}

async function mergeProfileSettings(guestUserId: string, authUserId: string) {
  const { data: guestProfile } = await supabase
    .from('users')
    .select('display_name, baby_last_name, baby_gender, partner_id, invite_code, onboarding_complete, plan_tier')
    .eq('id', guestUserId)
    .maybeSingle();

  if (!guestProfile) return;

  const { data: authProfile } = await supabase
    .from('users')
    .select('display_name, baby_last_name, baby_gender, partner_id, invite_code, onboarding_complete, plan_tier')
    .eq('id', authUserId)
    .maybeSingle();

  const updates: Record<string, unknown> = {};

  if (!authProfile?.display_name && guestProfile.display_name) {
    updates.display_name = guestProfile.display_name;
  }
  if (!authProfile?.baby_last_name && guestProfile.baby_last_name) {
    updates.baby_last_name = guestProfile.baby_last_name;
  }
  if (guestProfile.baby_gender && guestProfile.baby_gender !== 'either') {
    updates.baby_gender = guestProfile.baby_gender;
  }
  if (!authProfile?.partner_id && guestProfile.partner_id) {
    updates.partner_id = guestProfile.partner_id;
  }
  if (!authProfile?.invite_code && guestProfile.invite_code) {
    updates.invite_code = guestProfile.invite_code;
  }
  if (!authProfile?.onboarding_complete && guestProfile.onboarding_complete) {
    updates.onboarding_complete = guestProfile.onboarding_complete;
  }
  if (!authProfile?.plan_tier && guestProfile.plan_tier) {
    updates.plan_tier = guestProfile.plan_tier;
  }

  if (Object.keys(updates).length > 0) {
    await supabase.from('users').update(updates).eq('id', authUserId);
  }
}
