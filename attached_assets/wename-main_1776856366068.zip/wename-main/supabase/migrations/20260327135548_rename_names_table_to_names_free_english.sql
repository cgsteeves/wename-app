/*
  # Rename names table to Names-Free-English

  This migration renames the existing `names` table to `Names-Free-English`.

  ## Changes
  - Renames table `names` to `Names-Free-English`
  - Renames the unique constraint to match the new table name
  - Updates the RLS policies to reference the new table name
*/

ALTER TABLE IF EXISTS names RENAME TO "Names-Free-English";

ALTER TABLE IF EXISTS "Names-Free-English"
  RENAME CONSTRAINT names_text_gender_unique TO "Names-Free-English_text_gender_unique";
