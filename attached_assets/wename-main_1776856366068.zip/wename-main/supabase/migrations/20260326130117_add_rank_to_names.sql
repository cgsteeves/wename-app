/*
  # Add rank column to names table

  1. Changes
    - Add `rank` column (integer, nullable) to the `names` table
    - This column will store the popularity ranking for each name
    - Lower rank number = more popular (rank 1 is most popular)

  2. Notes
    - Column is nullable so existing names without rank data are unaffected
    - No RLS changes needed as existing policies cover this column
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'names' AND column_name = 'rank'
  ) THEN
    ALTER TABLE names ADD COLUMN rank integer;
  END IF;
END $$;
