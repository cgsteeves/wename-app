import { Star, Check, Sparkles } from 'lucide-react';
import { SubPageHeader } from './SubPageHeader';
import { User } from '../../lib/supabase';

interface PremiumPageProps {
  onBack: () => void;
  user: User;
}

const benefits = [
  'Access to 10,000+ more names',
  'AI name suggestions tailored to you',
  'Unlimited daily swipes and likes',
  'More name filtering — trendy, celeb, traditional, religious, and more',
  'Recommendations based on your current children\'s names',
];

export function PremiumPage({ onBack, user }: PremiumPageProps) {
  const isPremium = user.plan_tier === 'premium';

  return (
    <div className="flex-1 min-h-0 flex flex-col bg-parchment overflow-y-auto">
      <SubPageHeader title="Premium" onBack={onBack} />

      <div className="flex-1 px-4 pb-10 pt-2 space-y-5">
        <div className="bg-card rounded-2xl border border-amber-200/80 shadow-sm px-4 py-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-100 flex items-center justify-center shrink-0">
            <Star size={20} className="text-amber-500 fill-amber-400" />
          </div>
          <div>
            <p className="font-display font-bold text-foreground text-sm">Current Plan</p>
            <p className="text-xs text-muted-foreground font-display mt-0.5">
              {isPremium ? 'Premium — all features unlocked' : 'Free — basic features'}
            </p>
          </div>
        </div>

        <div className="bg-gradient-to-br from-amber-50 to-orange-50 rounded-2xl border border-amber-200/60 shadow-sm px-4 py-5 space-y-4">
          <div className="flex items-center gap-2">
            <Sparkles size={18} className="text-amber-500" />
            <p className="font-display font-bold text-foreground">Premium Benefits</p>
          </div>
          <div className="space-y-3">
            {benefits.map((benefit) => (
              <div key={benefit} className="flex items-start gap-2.5">
                <div className="w-5 h-5 rounded-full bg-amber-100 flex items-center justify-center shrink-0 mt-0.5">
                  <Check size={11} className="text-amber-600" strokeWidth={3} />
                </div>
                <p className="text-sm font-display text-foreground/80">{benefit}</p>
              </div>
            ))}
          </div>
        </div>

        {isPremium ? (
          <div className="w-full py-4 bg-amber-50 border border-amber-200 rounded-2xl flex items-center justify-center gap-2">
            <Star size={16} className="text-amber-500 fill-amber-400" />
            <p className="font-display font-bold text-amber-800 text-sm">You are on Premium</p>
          </div>
        ) : (
          <>
            <button className="w-full py-4 bg-gradient-to-r from-amber-400 to-orange-400 text-white rounded-2xl font-display font-bold text-base shadow-lg active:scale-95 transition-all">
              Upgrade to Premium
            </button>

            <button className="w-full py-3 bg-card border border-border/60 text-muted-foreground rounded-2xl font-display font-medium text-sm active:scale-95 transition-all">
              Restore Purchase
            </button>

            <p className="text-center text-xs text-muted-foreground font-display px-4">
              Purchases are processed securely. Subscriptions renew automatically unless cancelled.
            </p>
          </>
        )}
      </div>
    </div>
  );
}
