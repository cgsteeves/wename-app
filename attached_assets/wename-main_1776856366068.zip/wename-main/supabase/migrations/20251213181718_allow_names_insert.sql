/*
  # Allow Insert Access to Names Table

  1. Changes
    - Add INSERT policy for names table to allow anyone to insert names
    
  2. Security
    - This is safe because names are public reference data
*/

-- Drop existing policy if it exists
DROP POLICY IF EXISTS "Anyone can insert names" ON names;

-- Create policy to allow inserts
CREATE POLICY "Anyone can insert names"
  ON names FOR INSERT
  WITH CHECK (true);