-- Baby Name Picker - Database Migration
-- Run this SQL in your Supabase SQL Editor (https://supabase.com/dashboard/project/_/sql)

-- ======================
-- CREATE TABLES
-- ======================

-- Users table: stores each person using the app
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  display_name text DEFAULT '',
  baby_last_name text DEFAULT '',
  baby_gender text DEFAULT 'unknown' CHECK (baby_gender IN ('boy', 'girl', 'unknown')),
  partner_id uuid REFERENCES users(id) ON DELETE SET NULL,
  invite_code text UNIQUE NOT NULL,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_users_invite_code ON users(invite_code);

-- Names table: catalog of baby names
CREATE TABLE IF NOT EXISTS names (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  text text NOT NULL,
  gender text NOT NULL CHECK (gender IN ('boy', 'girl')),
  created_at timestamptz DEFAULT now()
);

-- Swipes table: tracks each user's like/dislike decisions
CREATE TABLE IF NOT EXISTS swipes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name_id uuid NOT NULL REFERENCES names(id) ON DELETE CASCADE,
  liked boolean NOT NULL DEFAULT false,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, name_id)
);

CREATE INDEX IF NOT EXISTS idx_swipes_user_id ON swipes(user_id);
CREATE INDEX IF NOT EXISTS idx_swipes_name_id ON swipes(name_id);

-- Matches table: stores names that both partners liked
CREATE TABLE IF NOT EXISTS matches (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name_id uuid NOT NULL REFERENCES names(id) ON DELETE CASCADE,
  user_a_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  user_b_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  gender text NOT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE(name_id, user_a_id, user_b_id)
);

CREATE INDEX IF NOT EXISTS idx_matches_user_a ON matches(user_a_id);
CREATE INDEX IF NOT EXISTS idx_matches_user_b ON matches(user_b_id);

-- ======================
-- SEED DATA
-- ======================

-- Insert 20 boy names
INSERT INTO names (text, gender) VALUES
  ('Oliver', 'boy'),
  ('Noah', 'boy'),
  ('Liam', 'boy'),
  ('Elijah', 'boy'),
  ('James', 'boy'),
  ('Lucas', 'boy'),
  ('Mason', 'boy'),
  ('Ethan', 'boy'),
  ('Alexander', 'boy'),
  ('Henry', 'boy'),
  ('Sebastian', 'boy'),
  ('Benjamin', 'boy'),
  ('Theodore', 'boy'),
  ('Owen', 'boy'),
  ('Jackson', 'boy'),
  ('Leo', 'boy'),
  ('Charlie', 'boy'),
  ('Max', 'boy'),
  ('Jack', 'boy'),
  ('William', 'boy')
ON CONFLICT DO NOTHING;

-- Insert 20 girl names
INSERT INTO names (text, gender) VALUES
  ('Emma', 'girl'),
  ('Olivia', 'girl'),
  ('Ava', 'girl'),
  ('Sophia', 'girl'),
  ('Isabella', 'girl'),
  ('Charlotte', 'girl'),
  ('Amelia', 'girl'),
  ('Mia', 'girl'),
  ('Harper', 'girl'),
  ('Evelyn', 'girl'),
  ('Luna', 'girl'),
  ('Ella', 'girl'),
  ('Grace', 'girl'),
  ('Lily', 'girl'),
  ('Scarlett', 'girl'),
  ('Chloe', 'girl'),
  ('Zoe', 'girl'),
  ('Nora', 'girl'),
  ('Hazel', 'girl'),
  ('Aurora', 'girl')
ON CONFLICT DO NOTHING;

-- ======================
-- HELPFUL QUERIES
-- ======================

-- See all names
-- SELECT * FROM names ORDER BY gender, text;

-- Add more names
-- INSERT INTO names (text, gender) VALUES ('NewName', 'boy');

-- Delete a name
-- DELETE FROM names WHERE text = 'NameToDelete';

-- See all users
-- SELECT id, display_name, baby_gender, invite_code FROM users;

-- See all matches
-- SELECT m.*, n.text as name_text FROM matches m JOIN names n ON m.name_id = n.id;
