import { motion } from 'framer-motion';
import { ArrowRight, ArrowLeft, Heart, Settings, ListPlus } from 'lucide-react';
import { StepDots } from './OnboardingPersonalize';

interface OnboardingTutorialProps {
  onStart: () => void;
}

const tutorialSteps = [
  {
    icon: <ArrowRight className="w-5 h-5" />,
    text: 'Swipe right to like',
    iconBg: 'bg-grass/15',
    iconColor: 'text-grass',
  },
  {
    icon: <ArrowLeft className="w-5 h-5" />,
    text: 'Swipe left to pass',
    iconBg: 'bg-heart/15',
    iconColor: 'text-heart',
  },
  {
    icon: <Heart className="w-5 h-5" />,
    text: "If your partner likes the same name, it becomes a match",
    iconBg: 'bg-girl/15',
    iconColor: 'text-girl',
  },
  {
    icon: <ListPlus className="w-5 h-5" />,
    text: 'Add names manually and share rankings with friends and family',
    iconBg: 'bg-sun/15',
    iconColor: 'text-sun',
  },
  {
    icon: <Settings className="w-5 h-5" />,
    text: 'Connect with your partner, update preferences, and upgrade to premium in settings',
    iconBg: 'bg-muted',
    iconColor: 'text-muted-foreground',
  },
];

export default function OnboardingTutorial({ onStart }: OnboardingTutorialProps) {
  return (
    <div className="relative h-dvh max-w-md mx-auto flex flex-col overflow-hidden">
      <img
        src="/onboarding-tutorial-bg.jpg"
        alt=""
        className="absolute inset-0 w-full h-full object-cover"
        draggable={false}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-black/5 via-transparent to-black/15" />

      <div className="relative z-10 flex flex-col h-full px-8">
        <StepDots current={2} />

        <div className="flex-1 min-h-[4%]" />

        <motion.div
          className="flex flex-col items-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <h1 className="text-2xl font-bold font-display text-foreground text-center mb-6">
            How it works
          </h1>

          <div className="flex flex-col gap-3 w-full">
            {tutorialSteps.map((step, i) => (
              <motion.div
                key={i}
                className="flex items-center gap-4 p-4 rounded-2xl bg-white/65 backdrop-blur-md border border-white/60 shadow-md"
                initial={{ opacity: 0, x: -18 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.4, delay: 0.1 + 0.08 * i, ease: 'easeOut' }}
              >
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${step.iconBg}`}>
                  <span className={step.iconColor}>{step.icon}</span>
                </div>
                <p className="font-display text-sm text-foreground leading-relaxed">
                  {step.text}
                </p>
              </motion.div>
            ))}
          </div>
        </motion.div>

        <div className="flex-1 min-h-[8%]" />

        <motion.div
          className="pb-14"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.5 }}
        >
          <button
            onClick={onStart}
            className="w-full py-4 rounded-2xl bg-primary text-primary-foreground font-display font-semibold text-base shadow-lg active:scale-[0.98] transition-transform"
          >
            Start Swiping ✨
          </button>
        </motion.div>
      </div>
    </div>
  );
}
