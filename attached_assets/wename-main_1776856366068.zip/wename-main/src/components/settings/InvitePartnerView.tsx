import { useState, useEffect } from 'react';
import { Copy, Check, Share2, Link2, AlertCircle, Loader } from 'lucide-react';
import { PartnerInvite } from '../../lib/supabase';
import { createInvite, getInviteUrl } from '../../services/inviteService';
import { SubPageHeader } from './SubPageHeader';

interface InvitePartnerViewProps {
  userId: string;
  onBack: () => void;
}

export function InvitePartnerView({ userId, onBack }: InvitePartnerViewProps) {
  const [invite, setInvite] = useState<PartnerInvite | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [copiedLink, setCopiedLink] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);

  useEffect(() => {
    generate();
  }, [userId]);

  async function generate() {
    setLoading(true);
    setError('');
    try {
      const inv = await createInvite(userId);
      setInvite(inv);
    } catch {
      setError('Failed to create invite. Please try again.');
    } finally {
      setLoading(false);
    }
  }

  function inviteUrl() {
    return invite ? getInviteUrl(invite.token) : '';
  }

  async function handleShareLink() {
    if (!invite) return;
    const url = inviteUrl();
    const text = `Join me on OurBabyName to find names we both love! Tap the link to connect instantly:`;
    if (navigator.share) {
      try {
        await navigator.share({ title: 'OurBabyName — Baby Name Picker', text, url });
        return;
      } catch {
        // fall through to copy
      }
    }
    copyLink();
  }

  async function copyLink() {
    if (!invite) return;
    await navigator.clipboard.writeText(inviteUrl());
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  }

  async function copyCode() {
    if (!invite) return;
    await navigator.clipboard.writeText(invite.short_code);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2500);
  }

  return (
    <div className="flex-1 min-h-0 flex flex-col bg-parchment overflow-y-auto">
      <SubPageHeader title="Invite Partner" onBack={onBack} />

      <div className="flex-1 px-4 pb-10 pt-2 space-y-4">

        {/* Hero */}
        <div className="bg-gradient-to-br from-rose-50 to-amber-50 border border-rose-100 rounded-2xl px-5 py-6 text-center space-y-2">
          <h2 className="font-display font-bold text-lg text-foreground">Invite your partner</h2>
          <p className="font-display text-sm text-muted-foreground leading-relaxed">
            Share this link so your partner can join your baby name list instantly.
          </p>
        </div>

        {loading && (
          <div className="flex items-center justify-center py-10">
            <Loader size={28} className="text-rose-400 animate-spin" />
          </div>
        )}

        {error && !loading && (
          <div className="bg-destructive/10 border border-destructive/20 rounded-2xl px-4 py-4 flex items-start gap-3">
            <AlertCircle size={16} className="text-destructive mt-0.5 shrink-0" />
            <div>
              <p className="font-display text-sm text-destructive">{error}</p>
              <button
                onClick={generate}
                className="font-display text-xs font-semibold text-destructive underline mt-1"
              >
                Try again
              </button>
            </div>
          </div>
        )}

        {invite && !loading && (
          <>
            {/* Primary: Share Link */}
            <div className="bg-card rounded-2xl border border-border/60 shadow-sm px-4 py-5 space-y-3">
              <p className="font-display text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                Invite link
              </p>

              {/* URL display */}
              <div className="bg-background rounded-xl border border-border px-3.5 py-3 flex items-center gap-2">
                <Link2 size={14} className="text-muted-foreground shrink-0" />
                <span className="flex-1 font-display text-xs text-muted-foreground truncate">
                  {inviteUrl()}
                </span>
                <button
                  onClick={copyLink}
                  className="shrink-0 text-muted-foreground hover:text-foreground transition-colors active:scale-90 ml-1"
                  title="Copy link"
                >
                  {copiedLink
                    ? <Check size={16} className="text-grass" />
                    : <Copy size={16} />}
                </button>
              </div>

              {/* Primary CTA */}
              <button
                onClick={handleShareLink}
                className="w-full py-3.5 bg-rose-500 hover:bg-rose-600 text-white rounded-xl font-display font-bold text-sm flex items-center justify-center gap-2 active:scale-95 transition-all shadow-md"
              >
                <Share2 size={16} />
                Share Invite Link
              </button>
            </div>

            {/* Secondary: Short Code */}
            <div className="bg-card rounded-2xl border border-border/60 shadow-sm px-4 py-5 space-y-3">
              <div>
                <p className="font-display text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-0.5">
                  Or use this code instead
                </p>
                <p className="font-display text-xs text-muted-foreground">
                  Your partner can enter this code manually in the app.
                </p>
              </div>

              <div className="flex items-center gap-3 bg-background rounded-xl border border-border px-4 py-3.5">
                <span className="flex-1 font-mono font-bold text-foreground tracking-[0.3em] text-xl text-center">
                  {invite.short_code}
                </span>
                <button
                  onClick={copyCode}
                  className="text-muted-foreground hover:text-foreground transition-colors active:scale-90 shrink-0"
                  title="Copy code"
                >
                  {copiedCode
                    ? <Check size={18} className="text-grass" />
                    : <Copy size={18} />}
                </button>
              </div>

              <button
                onClick={copyCode}
                className="w-full py-3 bg-background border border-border/70 rounded-xl font-display font-semibold text-sm text-foreground flex items-center justify-center gap-2 active:scale-95 transition-all"
              >
                {copiedCode ? <Check size={15} className="text-grass" /> : <Copy size={15} />}
                {copiedCode ? 'Code copied!' : 'Copy Code'}
              </button>
            </div>

            <p className="text-xs text-muted-foreground font-display text-center px-4">
              This link and code expire in 7 days. Generate a new one anytime.
            </p>
          </>
        )}
      </div>
    </div>
  );
}
