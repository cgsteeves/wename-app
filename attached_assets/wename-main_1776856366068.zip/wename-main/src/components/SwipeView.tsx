import { useState, useEffect, useCallback, useRef } from 'react';
import { useMotionValue } from 'framer-motion';
import { Heart } from 'lucide-react';
import { supabase, User, Name } from '../lib/supabase';
import { getSwipeableNames } from '../lib/namePacks';
import NameCard, { NameCardHandle } from './NameCard';
import { useDailyLimits } from '../hooks/useDailyLimits';
import { PremiumUpgradeModal } from './PremiumUpgradeModal';
import { FirstLikePartnerModal } from './FirstLikePartnerModal';

async function getPartnerCreatedNames(partnerId: string, gender: string): Promise<Name[]> {
  const { data, error } = await supabase.rpc('get_partner_created_names', {
    p_partner_id: partnerId,
    p_gender: gender,
  });

  if (error || !data) return [];

  const clean = (val: any): string | null => {
    if (val == null || val === '\\N' || val === 'Unknown' || String(val).trim() === '') return null;
    return String(val);
  };

  return (data as any[]).map(row => ({
    id: row.uuid,
    text: row.name,
    gender: row.gender,
    pronunciation: clean(row.pronunciation),
    origin: clean(row.origin_raw),
    meaning: clean(row.meaning),
    nickname: clean(row.nicknames),
    rank: row.us_rank != null && /^\d+$/.test(String(row.us_rank)) ? Number(row.us_rank) : null,
    created_at: '',
    created_by_user_id: row.created_by_user_id ?? null,
  }));
}

type LimitType = 'swipe' | 'like' | 'match' | null;

type SwipeViewProps = {
  user: User;
  updateUser: (updates: Partial<User>) => Promise<void>;
  onNavigateToPartner?: () => void;
};

type SwipeHistoryItem = {
  nameId: string;
  liked: boolean;
};

const FIRST_LIKE_KEY = (userId: string) => `first_like_partner_shown_${userId}`;

export function SwipeView({ user, updateUser, onNavigateToPartner }: SwipeViewProps) {
  const [names, setNames] = useState<Name[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [isAnimating, setIsAnimating] = useState(false);
  const [matchedName, setMatchedName] = useState<Name | null>(null);
  const [swipeHistory, setSwipeHistory] = useState<SwipeHistoryItem[]>([]);
  const [upgradeModalOpen, setUpgradeModalOpen] = useState(false);
  const [upgradeModalLimitType, setUpgradeModalLimitType] = useState<LimitType>(null);
  const [showPartnerModal, setShowPartnerModal] = useState(false);
  const [showPartnerAuthModal, setShowPartnerAuthModal] = useState(false);
  const [partnerPickIds, setPartnerPickIds] = useState<Set<string>>(new Set());
  const dragProgress = useMotionValue(0);
  const currentCardRef = useRef<NameCardHandle>(null);

  const limits = useDailyLimits(user, updateUser);

  const loadNames = useCallback(async (includeAlreadySwiped = false) => {
    try {
      setLoading(true);
      setLoadError(null);

      const { data: swipes, error: swipesError } = await supabase
        .from('swipes')
        .select('name_id')
        .eq('user_id', user.id);

      if (swipesError) throw new Error('Failed to load your swipe history');

      const swipedIds = new Set((swipes ?? []).map((s: { name_id: string }) => s.name_id));

      const gender = user.baby_gender === 'either' ? 'either' : user.baby_gender;
      const [allNames, partnerNames] = await Promise.all([
        getSwipeableNames(user.id, gender as 'boy' | 'girl' | 'either'),
        user.partner_id
          ? getPartnerCreatedNames(user.partner_id, gender ?? 'either')
          : Promise.resolve([] as Name[]),
      ]);

      if (allNames.length === 0 && partnerNames.length === 0) {
        throw new Error('No names available in the selected packs');
      }

      const newPartnerPickIds = new Set(partnerNames.map(n => n.id));
      setPartnerPickIds(newPartnerPickIds);

      let filteredCatalog = includeAlreadySwiped
        ? allNames
        : allNames.filter(n => !swipedIds.has(n.id));

      if (filteredCatalog.length === 0 && !includeAlreadySwiped) {
        filteredCatalog = allNames;
      }

      const combined = [...filteredCatalog, ...partnerNames];

      let shuffled: Name[];

      if (user.baby_gender === 'either') {
        const boyNames = combined.filter(n => n.gender === 'boy').sort(() => Math.random() - 0.5);
        const girlNames = combined.filter(n => n.gender === 'girl').sort(() => Math.random() - 0.5);
        shuffled = [];
        const maxLength = Math.max(boyNames.length, girlNames.length);
        for (let i = 0; i < maxLength; i++) {
          if (i < boyNames.length) shuffled.push(boyNames[i]);
          if (i < girlNames.length) shuffled.push(girlNames[i]);
        }
      } else {
        shuffled = [...combined].sort(() => Math.random() - 0.5);
      }

      setNames(shuffled);
      setCurrentIndex(0);
    } catch (error) {
      console.error('Error loading names:', error);
      setLoadError(error instanceof Error ? error.message : 'Failed to load names');
    } finally {
      setLoading(false);
    }
  }, [user.id, user.baby_gender, user.partner_id]);

  useEffect(() => {
    loadNames();
  }, [user.id]);

  useEffect(() => {
    setNames([]);
    setCurrentIndex(0);
    setSwipeHistory([]);
    loadNames();
  }, [user.baby_gender, loadNames]);

  /**
   * handleSwipe — the main swipe handler.
   *
   * LIMIT ENFORCEMENT:
   *   1. checkCanSwipe(liked) is called BEFORE any DB write.
   *   2. If blocked, the upgrade modal is shown and the swipe is NOT recorded.
   *   3. If allowed, counts are incremented inside checkCanSwipe and the swipe proceeds.
   */
  async function handleSwipe(liked: boolean) {
    const currentName = names[currentIndex];
    if (!currentName || isAnimating) return;

    // --- Limit check ---
    const { allowed, limitType } = await limits.checkCanSwipe(liked);
    if (!allowed) {
      setUpgradeModalLimitType(limitType as LimitType);
      setUpgradeModalOpen(true);
      return;
    }

    setIsAnimating(true);
    setSwipeHistory(prev => [...prev, { nameId: currentName.id, liked }]);

    if (currentIndex < names.length - 1) {
      setCurrentIndex(currentIndex + 1);
    } else {
      setNames([]);
    }
    dragProgress.set(0);
    setIsAnimating(false);

    try {
      const { error: swipeError } = await supabase
        .from('swipes')
        .upsert(
          { user_id: user.id, name_id: currentName.id, liked },
          { onConflict: 'user_id,name_id' }
        );

      if (swipeError) console.error('Error saving swipe:', swipeError);

      if (liked && user.partner_id) {
        await checkForMatch(currentName);
      }

      if (liked && !localStorage.getItem(FIRST_LIKE_KEY(user.id))) {
        localStorage.setItem(FIRST_LIKE_KEY(user.id), '1');
        setShowPartnerModal(true);
      }
    } catch (error) {
      console.error('Error recording swipe:', error);
    }
  }

  async function handleUndo() {
    if (swipeHistory.length === 0 || isAnimating || currentIndex === 0) return;

    setIsAnimating(true);

    try {
      const lastSwipe = swipeHistory[swipeHistory.length - 1];

      await supabase
        .from('swipes')
        .delete()
        .eq('user_id', user.id)
        .eq('name_id', lastSwipe.nameId);

      if (lastSwipe.liked && user.partner_id) {
        const prevName = names[currentIndex - 1];
        if (prevName) {
          const [userA, userB] = [user.id, user.partner_id].sort();
          await supabase
            .from('matches')
            .delete()
            .eq('name_id', prevName.id)
            .eq('user_a_id', userA)
            .eq('user_b_id', userB);
        }
      }

      setSwipeHistory(swipeHistory.slice(0, -1));
      setCurrentIndex(currentIndex - 1);
      setIsAnimating(false);
    } catch (error) {
      console.error('Error undoing swipe:', error);
      alert('Failed to undo swipe. Please try again.');
      setIsAnimating(false);
    }
  }

  /**
   * checkForMatch — checks if this like creates a mutual match.
   *
   * MATCH REVEAL LIMIT:
   *   checkCanRevealMatch() is called before setting matchedName.
   *   If blocked (>= 3 matches today, free user), the match is saved to the DB
   *   silently but NOT surfaced to the user right now. The upgrade modal is shown.
   */
  async function checkForMatch(name: Name) {
    if (!user.partner_id) return;

    try {
      const { data: partnerSwipe } = await supabase
        .from('swipes')
        .select('*')
        .eq('user_id', user.partner_id)
        .eq('name_id', name.id)
        .eq('liked', true)
        .maybeSingle();

      if (partnerSwipe) {
        const [userA, userB] = [user.id, user.partner_id].sort();

        // Save match to DB regardless of limit
        await supabase
          .from('matches')
          .insert({ name_id: name.id, user_a_id: userA, user_b_id: userB, gender: name.gender });

        // Only surface the match notification if within daily limit
        const canReveal = await limits.checkCanRevealMatch();
        if (canReveal) {
          setMatchedName(name);
        } else {
          setUpgradeModalLimitType('match');
          setUpgradeModalOpen(true);
        }
      }
    } catch (error) {
      console.error('Error checking for match:', error);
    }
  }

  useEffect(() => {
    if (matchedName) {
      const timer = setTimeout(() => setMatchedName(null), 4000);
      return () => clearTimeout(timer);
    }
  }, [matchedName]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full bg-parchment">
        <div className="text-muted-foreground font-display">Loading names...</div>
      </div>
    );
  }

  if (loadError) {
    return (
      <div className="flex flex-col items-center justify-center h-full px-6 text-center bg-parchment">
        <div className="text-4xl mb-4">⚠️</div>
        <h2 className="text-2xl font-bold font-hand text-grass mb-2">Oops!</h2>
        <p className="text-muted-foreground font-display mb-6">{loadError}</p>
        <button
          onClick={() => loadNames()}
          className="px-6 py-3 bg-boy text-primary-foreground rounded-lg font-display font-medium hover:opacity-90 transition-opacity"
        >
          Try Again
        </button>
      </div>
    );
  }

  if (names.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-full px-6 text-center bg-parchment">
        <div className="text-4xl mb-4">🎉</div>
        <h2 className="text-2xl font-bold font-hand text-grass mb-2">All done!</h2>
        <p className="text-muted-foreground font-display mb-6">
          You've swiped through all available names.
        </p>
        <button
          onClick={() => loadNames(true)}
          className="px-6 py-3 bg-boy text-primary-foreground rounded-lg font-display font-medium hover:opacity-90 transition-opacity"
        >
          Start Over
        </button>
      </div>
    );
  }

  const currentName = names[currentIndex];
  const nextName = names[currentIndex + 1] || null;
  const remainingCount = Math.max(0, names.length - currentIndex - 1);

  return (
    <div className="flex-1 min-h-0 flex flex-col bg-parchment">
      <div className="flex-1 relative px-5 pb-2 overflow-hidden">
        {nextName && (
          <NameCard
            key={`next-${nextName.id}`}
            name={nextName.text}
            pronunciation={nextName.pronunciation}
            origin={nextName.origin}
            meaning={nextName.meaning}
            nickname={nextName.nickname}
            rank={nextName.rank}
            gender={nextName.gender as 'boy' | 'girl'}
            remaining={Math.max(0, remainingCount - 1)}
            lastName={user.baby_last_name || undefined}
            onSwipe={() => {}}
            isNext={true}
            dragProgress={dragProgress}
            isPartnerPick={partnerPickIds.has(nextName.id)}
          />
        )}
        {currentName && (
          <NameCard
            key={currentName.id}
            ref={currentCardRef}
            name={currentName.text}
            pronunciation={currentName.pronunciation}
            origin={currentName.origin}
            meaning={currentName.meaning}
            nickname={currentName.nickname}
            rank={currentName.rank}
            gender={currentName.gender as 'boy' | 'girl'}
            remaining={remainingCount}
            lastName={user.baby_last_name || undefined}
            onSwipe={handleSwipe}
            onUndo={handleUndo}
            canUndo={swipeHistory.length > 0 && currentIndex > 0}
            dragProgress={dragProgress}
            isPartnerPick={partnerPickIds.has(currentName.id)}
          />
        )}
      </div>

      {/* Match celebration modal */}
      {matchedName && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm animate-fade-in">
          <div className="bg-parchment rounded-3xl shadow-2xl p-8 max-w-md mx-4 text-center transform animate-scale-in border border-border">
            <div className="text-6xl mb-4 animate-bounce">
              <Heart className="inline-block text-heart" fill="currentColor" size={64} />
            </div>
            <h2 className="text-4xl font-bold font-hand text-grass mb-2">It's a Match!</h2>
            <p className="text-muted-foreground font-display mb-6">You both love the name</p>
            <div className={`text-5xl font-bold font-display mb-2 ${matchedName.gender === 'boy' ? 'text-boy' : 'text-girl-red'}`}>
              {matchedName.text}
            </div>
            {user.baby_last_name && (
              <div className="text-2xl text-foreground font-display font-medium mb-6">
                {user.baby_last_name}
              </div>
            )}
            <button
              onClick={() => setMatchedName(null)}
              className="px-6 py-3 bg-boy text-primary-foreground rounded-full font-display font-medium hover:opacity-90 transition-opacity transform hover:scale-105"
            >
              Keep Swiping
            </button>
          </div>
        </div>
      )}

      {/* Premium upgrade modal — shown when any daily limit is reached */}
      <PremiumUpgradeModal
        open={upgradeModalOpen}
        limitType={upgradeModalLimitType}
        onClose={() => setUpgradeModalOpen(false)}
        onUpgrade={() => {
          setUpgradeModalOpen(false);
        }}
      />

      {/* First-like partner prompt — shown once after the user's very first like */}
      <FirstLikePartnerModal
        open={showPartnerModal}
        onClose={() => setShowPartnerModal(false)}
        onInvitePartner={() => onNavigateToPartner?.()}
        hasPartner={!!user.partner_id}
        showAuthModal={showPartnerAuthModal}
        onShowAuthModal={() => setShowPartnerAuthModal(true)}
        onHideAuthModal={() => setShowPartnerAuthModal(false)}
      />
    </div>
  );
}
