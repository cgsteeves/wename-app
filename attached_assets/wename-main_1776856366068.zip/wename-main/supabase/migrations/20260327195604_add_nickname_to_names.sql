/*
  # Add nickname column to Names-Free-English table

  1. Changes
    - Adds a `nickname` column (text, nullable) to the "Names-Free-English" table
    - Stores a possible nickname or short form for each name (e.g., "Will" for "William")

  2. Notes
    - Nullable so all existing rows are unaffected
    - No RLS changes needed; inherits existing policies
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'Names-Free-English' AND column_name = 'nickname'
  ) THEN
    ALTER TABLE "Names-Free-English" ADD COLUMN nickname text DEFAULT NULL;
  END IF;
END $$;
