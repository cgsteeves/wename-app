/*
  # Add Finalists Table

  1. New Tables
    - `finalists`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `name_id` (uuid, references Names-Free-English)
      - `ranking` (integer, optional sort order)
      - `created_at` (timestamptz)

  2. Purpose
    - Stores names that a user has promoted to their shortlist of finalists.
    - Names can be promoted from either Your Picks or Shared Matches.

  3. Security
    - RLS enabled
    - Users can only read, insert, update, and delete their own finalists
*/

CREATE TABLE IF NOT EXISTS finalists (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name_id uuid NOT NULL,
  ranking integer,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, name_id)
);

ALTER TABLE finalists ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own finalists"
  ON finalists FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own finalists"
  ON finalists FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own finalists"
  ON finalists FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own finalists"
  ON finalists FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);
