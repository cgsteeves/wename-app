/*
  # Migrate names table to replace Names-Free-English

  ## Summary
  The `Names-Free-English` table was previously the source of truth for name data
  and was referenced by swipes, matches, and finalists via UUID foreign keys.
  The `names` table contains the full enriched dataset (41k+ names).

  This migration:
  1. Adds a UUID primary key column (`uuid`) to the `names` table
  2. Copies existing UUIDs from `Names-Free-English` into `names` where text+gender match
  3. Generates new UUIDs for any `names` rows not in `Names-Free-English`
  4. Drops old FK constraints on swipes, matches, and finalists that reference Names-Free-English
  5. Adds new FK constraints pointing to names.uuid
  6. Updates swipes/matches/finalists name_id values to use names.uuid
  7. Drops the Names-Free-English table

  ## New columns on names
  - `uuid` (uuid, unique, not null) — stable identifier for app references

  ## Security
  - No RLS changes needed; names table is read-only for app users
*/

-- Step 1: Add uuid column to names table
ALTER TABLE names ADD COLUMN IF NOT EXISTS uuid uuid DEFAULT gen_random_uuid();

-- Step 2: Copy UUIDs from Names-Free-English into matching names rows
UPDATE names n
SET uuid = nfe.id
FROM "Names-Free-English" nfe
WHERE nfe.text = n.name
  AND nfe.gender = n.gender;

-- Step 3: Ensure all names rows have a uuid (any that weren't in Names-Free-English already get one from the DEFAULT)
-- Make uuid NOT NULL and UNIQUE after populating
ALTER TABLE names ALTER COLUMN uuid SET NOT NULL;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'names_uuid_key'
  ) THEN
    ALTER TABLE names ADD CONSTRAINT names_uuid_key UNIQUE (uuid);
  END IF;
END $$;

-- Step 4: Migrate swipes.name_id to point to names.uuid
-- First drop the old FK constraint
ALTER TABLE swipes DROP CONSTRAINT IF EXISTS swipes_name_id_fkey;

-- Update swipes.name_id from Names-Free-English UUIDs to names.uuid
-- Since we copied the exact same UUIDs, existing swipe name_ids already match names.uuid
-- Just need to add the new FK
ALTER TABLE swipes
  ADD CONSTRAINT swipes_name_id_fkey
  FOREIGN KEY (name_id) REFERENCES names(uuid) ON DELETE CASCADE;

-- Step 5: Migrate matches.name_id
ALTER TABLE matches DROP CONSTRAINT IF EXISTS matches_name_id_fkey;

ALTER TABLE matches
  ADD CONSTRAINT matches_name_id_fkey
  FOREIGN KEY (name_id) REFERENCES names(uuid) ON DELETE CASCADE;

-- Step 6: Migrate finalists.name_id if it has a FK to Names-Free-English
ALTER TABLE finalists DROP CONSTRAINT IF EXISTS finalists_name_id_fkey;

-- Check if finalists.name_id references Names-Free-English and add new constraint
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'finalists' AND column_name = 'name_id' AND table_schema = 'public'
  ) THEN
    ALTER TABLE finalists
      ADD CONSTRAINT finalists_name_id_fkey
      FOREIGN KEY (name_id) REFERENCES names(uuid) ON DELETE CASCADE;
  END IF;
END $$;
