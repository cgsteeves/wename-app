import { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import OnboardingWelcome from './OnboardingWelcome';
import OnboardingPersonalize from './OnboardingPersonalize';
import OnboardingTutorial from './OnboardingTutorial';

type Gender = 'boy' | 'girl' | 'either';
type Step = 'welcome' | 'personalize' | 'tutorial';

interface OnboardingFlowProps {
  onComplete: (gender: Gender) => void;
}

export default function OnboardingFlow({ onComplete }: OnboardingFlowProps) {
  const [step, setStep] = useState<Step>('welcome');
  const [selectedGender, setSelectedGender] = useState<Gender>('either');
  const [direction, setDirection] = useState(1);

  const navigate = (next: Step) => {
    setDirection(1);
    setStep(next);
  };

  const handleGetStarted = () => navigate('personalize');

  const handleEnterCode = (code: string) => {
    console.log('Partner code entered:', code);
    navigate('personalize');
  };

  const handlePersonalizeNext = (gender: Gender, _lastName: string) => {
    setSelectedGender(gender);
    navigate('tutorial');
  };

  const handleSkip = () => navigate('tutorial');

  const handleStart = () => onComplete(selectedGender);

  const variants = {
    initial: { opacity: 0, x: direction * 40 },
    animate: { opacity: 1, x: 0 },
    exit: { opacity: 0, x: direction * -40 },
  };

  return (
    <AnimatePresence mode="wait" initial={false}>
      <motion.div
        key={step}
        variants={variants}
        initial="initial"
        animate="animate"
        exit="exit"
        transition={{ duration: 0.35, ease: 'easeInOut' }}
        className="h-dvh"
      >
        {step === 'welcome' && (
          <OnboardingWelcome onGetStarted={handleGetStarted} onEnterCode={handleEnterCode} />
        )}
        {step === 'personalize' && (
          <OnboardingPersonalize onNext={handlePersonalizeNext} onSkip={handleSkip} />
        )}
        {step === 'tutorial' && (
          <OnboardingTutorial onStart={handleStart} />
        )}
      </motion.div>
    </AnimatePresence>
  );
}
