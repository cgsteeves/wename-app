import { SubPageHeader } from './SubPageHeader';

interface TermsOfServicePageProps {
  onBack: () => void;
}

interface SectionProps {
  number: string;
  title: string;
  children: React.ReactNode;
}

function Section({ number, title, children }: SectionProps) {
  return (
    <div className="space-y-3">
      <div className="flex items-baseline gap-2">
        <span className="text-xs font-display font-bold text-muted-foreground uppercase tracking-wider">{number}</span>
        <h2 className="font-display font-bold text-base text-foreground">{title}</h2>
      </div>
      <div className="space-y-2 text-sm font-display text-foreground/80 leading-relaxed">
        {children}
      </div>
    </div>
  );
}

function SubSection({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1">
      <p className="font-display font-bold text-sm text-foreground">{title}</p>
      <div className="space-y-1 text-sm font-display text-foreground/80 leading-relaxed">
        {children}
      </div>
    </div>
  );
}

function PolicyLink({ href, label }: { href: string; label: string }) {
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      className="text-sky-600 underline underline-offset-2 break-all"
    >
      {label}
    </a>
  );
}

export function TermsOfServicePage({ onBack }: TermsOfServicePageProps) {
  return (
    <div className="flex-1 min-h-0 flex flex-col bg-parchment overflow-y-auto">
      <SubPageHeader title="Terms of Service" onBack={onBack} />

      <div className="flex-1 px-4 pb-12 pt-2 space-y-6">
        <div className="bg-card rounded-2xl border border-border/60 shadow-sm px-5 py-5 space-y-1">
          <p className="font-display font-bold text-base text-foreground">WeName</p>
          <p className="text-xs font-display text-muted-foreground">Last Updated: April 15, 2026</p>
        </div>

        <div className="bg-card rounded-2xl border border-border/60 shadow-sm px-5 py-5 space-y-6 divide-y divide-border/40">

          <Section number="1" title="Acceptance of Terms">
            <p>
              By downloading, installing, or using the WeName application ("App," "Service") operated by
              Christopher Steeves ("we," "our," or "us"), you agree to be bound by these Terms of Service
              ("Terms"). If you do not agree to these Terms, do not use the App.
            </p>
            <p>
              These Terms constitute a legally binding agreement between you and WeName. We may update
              these Terms from time to time. Continued use of the App after changes are posted constitutes
              your acceptance of the revised Terms.
            </p>
          </Section>

          <div className="pt-6">
            <Section number="2" title="Description of Service">
              <p>
                WeName is a collaborative baby name discovery application that allows users to swipe
                through curated baby name lists, save favourites, and discover names that both partners
                like. The App is available at wename.app and as a mobile web application.
              </p>
              <SubSection title="Free Tier">
                <p>
                  Free accounts may swipe on a limited number of names per day and access core features
                  of the App. Daily limits reset every 24 hours.
                </p>
              </SubSection>
              <SubSection title="Premium Tier">
                <p>
                  Premium accounts receive unlimited daily swipes and access to additional name packs and
                  features. Premium access is subject to any applicable fees disclosed at the time of
                  purchase.
                </p>
              </SubSection>
              <SubSection title="Guest Usage">
                <p>
                  You may explore certain features of the App without creating an account. Guest users
                  may have limited access to features, and their data may not be saved across sessions.
                  We recommend creating an account to preserve your swipe history and access all features.
                </p>
              </SubSection>
            </Section>
          </div>

          <div className="pt-6">
            <Section number="3" title="Subscription Billing">
              <p>
                If you purchase a premium subscription, billing will be handled through the platform on
                which you downloaded the App (e.g., Apple App Store or Google Play Store). All payments
                are processed by the applicable platform provider and are subject to their respective
                terms and policies.
              </p>
              <p>
                All payments are non-refundable except as required by applicable law or the policies of
                the platform provider through which you made your purchase. Please review the refund
                policy of the applicable platform provider for more information.
              </p>
              <p>
                Subscriptions may auto-renew unless cancelled prior to the renewal date in accordance
                with the platform provider's cancellation policy. We do not process cancellations
                directly — cancellations must be managed through your App Store or Google Play account
                settings.
              </p>
            </Section>
          </div>

          <div className="pt-6">
            <Section number="4" title="Account Registration">
              <p>
                You may use certain features of the App as a guest without creating an account. To access
                partner-linking, match history, and other personalized features, you must create an
                account by providing a valid email address.
              </p>
              <ul className="list-disc list-inside space-y-1 pl-1">
                <li>You must be at least 13 years of age to create an account.</li>
                <li>You are responsible for maintaining the confidentiality of your account credentials.</li>
                <li>You agree to provide accurate and current information when creating your account.</li>
                <li>You are responsible for all activity that occurs under your account.</li>
                <li>You must notify us immediately at wenameapp@gmail.com if you suspect unauthorized use of your account.</li>
              </ul>
            </Section>
          </div>

          <div className="pt-6">
            <Section number="5" title="Partner Linking">
              <p>
                WeName allows you to link your account with a partner to discover names you both like.
                By linking with a partner:
              </p>
              <ul className="list-disc list-inside space-y-1 pl-1">
                <li>You consent to sharing your liked names and matched names with your linked partner.</li>
                <li>Your partner will be able to see the names you have liked and any names you have matched on together.</li>
                <li>You may unlink from your partner at any time through the Partner section of Settings.</li>
                <li>Unlinking does not delete your individual swipe history or liked names.</li>
              </ul>
              <p>
                You are solely responsible for the partner you choose to link with. WeName is not
                responsible for any disputes arising between you and your partner. WeName does not
                guarantee that you and your partner will reach agreement on any names or that the Service
                will produce outcomes that meet your expectations.
              </p>
            </Section>
          </div>

          <div className="pt-6">
            <Section number="6" title="Acceptable Use">
              <p>You agree not to use the App to:</p>
              <ul className="list-disc list-inside space-y-1 pl-1">
                <li>Violate any applicable local, provincial, national, or international law or regulation.</li>
                <li>Attempt to gain unauthorized access to any portion of the App or its related systems.</li>
                <li>Reverse engineer, decompile, disassemble, or otherwise attempt to derive the source code of the App.</li>
                <li>Use automated scripts, bots, or other means to scrape or interact with the App in ways not intended by normal use.</li>
                <li>Transmit any viruses, malware, or other harmful code.</li>
                <li>Impersonate any person or entity, or falsely represent your affiliation with any person or entity.</li>
                <li>Use the App for any commercial purpose without our prior written consent.</li>
              </ul>
              <p>
                We reserve the right to suspend or terminate your account at our sole discretion if we
                determine you have violated these Terms or engaged in conduct harmful to the App or other
                users.
              </p>
              <p>
                We reserve the right to enforce usage limits and prevent abuse of the Service, including
                excessive or automated usage that places an unreasonable burden on our infrastructure or
                degrades the experience of other users.
              </p>
            </Section>
          </div>

          <div className="pt-6">
            <Section number="7" title="Service Changes">
              <p>
                We reserve the right to modify, suspend, or discontinue any part of the Service at any
                time without notice. This includes the addition, modification, or removal of features,
                name packs, or other content. We shall not be liable to you or any third party for any
                modification, suspension, or discontinuation of the Service or any part thereof.
              </p>
            </Section>
          </div>

          <div className="pt-6">
            <Section number="8" title="User-Generated Content">
              <p>
                The App may allow you to submit custom baby names ("User Content"). By submitting User
                Content, you grant WeName a non-exclusive, royalty-free, worldwide licence to use,
                display, and process that content solely for the purpose of operating the App and
                providing the Service to you.
              </p>
              <p>
                You represent and warrant that any User Content you submit does not violate the rights of
                any third party, including intellectual property rights, privacy rights, or any applicable
                law.
              </p>
            </Section>
          </div>

          <div className="pt-6">
            <Section number="9" title="Intellectual Property">
              <p>
                All content, features, and functionality of the App — including but not limited to the
                name database, AI suggestions, design, graphics, logos, and source code — are the
                exclusive property of WeName and its licensors and are protected by applicable copyright,
                trademark, and other intellectual property laws.
              </p>
              <p>
                These Terms do not grant you any right, title, or interest in the App or its content
                beyond the limited licence to use the Service for its intended personal, non-commercial
                purpose.
              </p>
            </Section>
          </div>

          <div className="pt-6">
            <Section number="10" title="Privacy">
              <p>
                Your use of the App is also governed by our Privacy Policy, which is incorporated into
                these Terms by reference. Please review our Privacy Policy at{' '}
                <PolicyLink href="https://wename.app/privacy" label="wename.app/privacy" /> to
                understand our practices regarding the collection, use, and disclosure of your personal
                information.
              </p>
            </Section>
          </div>

          <div className="pt-6">
            <Section number="11" title="Third-Party Services">
              <p>
                The App integrates with third-party services including Supabase (database and
                authentication), SendGrid (email delivery), and OpenAI (AI name suggestions). Your use
                of these features is also subject to the respective terms and privacy policies of those
                third parties. We are not responsible for the availability, accuracy, or practices of
                any third-party services.
              </p>
            </Section>
          </div>

          <div className="pt-6">
            <Section number="12" title="Disclaimer of Warranties">
              <p>
                The App is provided on an "as is" and "as available" basis without warranties of any
                kind, either express or implied, including but not limited to implied warranties of
                merchantability, fitness for a particular purpose, or non-infringement.
              </p>
              <p>
                We do not warrant that the App will be uninterrupted, error-free, or free of viruses or
                other harmful components. We do not warrant the accuracy, completeness, or usefulness of
                any information provided through the App, including name meanings, origins, or
                pronunciations. WeName does not guarantee that you and your partner will reach agreement
                on any names or that the Service will produce outcomes that meet your expectations.
              </p>
            </Section>
          </div>

          <div className="pt-6">
            <Section number="13" title="Limitation of Liability">
              <p>
                To the fullest extent permitted by applicable law, WeName and its owner shall not be
                liable for any indirect, incidental, special, consequential, or punitive damages,
                including but not limited to loss of data, loss of profits, or loss of goodwill, arising
                out of or in connection with your use of or inability to use the App.
              </p>
              <p>
                In no event shall our total liability to you for any claims arising under these Terms
                exceed the greater of (a) the amount you have paid to us in the twelve months preceding
                the claim, or (b) CAD $10.
              </p>
            </Section>
          </div>

          <div className="pt-6">
            <Section number="14" title="Indemnification">
              <p>
                You agree to indemnify, defend, and hold harmless WeName and its owner from and against
                any claims, liabilities, damages, losses, and expenses (including reasonable legal fees)
                arising out of or in any way connected with your access to or use of the App, your
                violation of these Terms, or your violation of any rights of another person or entity.
              </p>
            </Section>
          </div>

          <div className="pt-6">
            <Section number="15" title="Termination">
              <p>
                You may stop using the App and delete your account at any time through the Account
                section of Settings. Upon account deletion, your personal data will be permanently
                removed from our systems as described in our Privacy Policy. Please note that some
                limited technical data may persist temporarily in backups or logs as described in our
                Privacy Policy.
              </p>
              <p>
                We reserve the right to suspend or terminate your access to the App at any time, with
                or without notice, for any reason including if we reasonably believe you have violated
                these Terms. Upon termination, your right to use the App will immediately cease.
              </p>
            </Section>
          </div>

          <div className="pt-6">
            <Section number="16" title="Governing Law and Dispute Resolution">
              <p>
                These Terms are governed by and construed in accordance with the laws of the Province of
                Ontario and the federal laws of Canada applicable therein, without regard to conflict of
                law principles.
              </p>
              <p>
                Any dispute arising out of or relating to these Terms or your use of the App shall first
                be attempted to be resolved through good-faith negotiation. If the dispute cannot be
                resolved informally, it shall be submitted to the courts of competent jurisdiction in
                Ottawa, Ontario, Canada, and you consent to the exclusive jurisdiction of those courts.
              </p>
            </Section>
          </div>

          <div className="pt-6">
            <Section number="17" title="Changes to These Terms">
              <p>
                We may revise these Terms at any time. When we make material changes, we will update the
                "Last Updated" date above and may provide notice through the App. Your continued use of
                the App following the posting of revised Terms constitutes your acceptance of the changes.
              </p>
              <p>
                We encourage you to review these Terms periodically to stay informed of any updates.
              </p>
            </Section>
          </div>

          <div className="pt-6">
            <Section number="18" title="Entire Agreement">
              <p>
                These Terms constitute the entire agreement between you and WeName regarding the use of
                the Service and supersede all prior and contemporaneous agreements, representations, and
                understandings between you and WeName relating to the subject matter herein.
              </p>
            </Section>
          </div>

          <div className="pt-6">
            <Section number="19" title="Contact Us">
              <p>
                If you have any questions, concerns, or feedback regarding these Terms, please contact us:
              </p>
              <div className="bg-muted/60 rounded-xl px-4 py-3 border border-border/40 space-y-1">
                <p className="font-semibold text-foreground">Christopher Steeves (WeName)</p>
                <p>Ottawa, Ontario, Canada</p>
                <p>Email: <PolicyLink href="mailto:wenameapp@gmail.com" label="wenameapp@gmail.com" /></p>
                <p>Website: <PolicyLink href="https://wename.app" label="wename.app" /></p>
              </div>
            </Section>
          </div>

        </div>

        <p className="text-center text-xs text-muted-foreground font-display px-4 pb-2">
          WeName — made with love for growing families
        </p>
      </div>
    </div>
  );
}
