import { useState, useEffect } from 'react';
import { Check, Lock, Package } from 'lucide-react';
import { SubPageHeader } from './SubPageHeader';
import { User, NamePack, DEFAULT_PACK_SLUG } from '../../lib/supabase';
import {
  getAllPacks,
  getUserSelectedPacks,
  setUserPack,
  isPremiumPack,
} from '../../lib/namePacks';

interface NamePacksPageProps {
  user: User;
  onBack: () => void;
  onNavigateToPremium: () => void;
}

type PacksByCategory = Record<string, NamePack[]>;

const CATEGORY_LABELS: Record<string, string> = {
  featured: 'Default',
  origin: 'Origins',
  style: 'Styles',
  feeling: 'Feeling',
};

const CATEGORY_DESCRIPTIONS: Record<string, string> = {
  featured: 'The complete starter collection',
  origin: 'Names from cultures around the world',
  style: 'Curated by naming personality',
  feeling: 'Names that evoke a mood or quality',
};

const CATEGORY_COLORS: Record<string, {
  bg: string;
  border: string;
  badge: string;
  badgeText: string;
  dot: string;
}> = {
  featured: {
    bg: 'bg-amber-50',
    border: 'border-amber-200',
    badge: 'bg-amber-100',
    badgeText: 'text-amber-700',
    dot: 'bg-amber-400',
  },
  origin: {
    bg: 'bg-sky-50',
    border: 'border-sky-200',
    badge: 'bg-sky-100',
    badgeText: 'text-sky-700',
    dot: 'bg-sky-400',
  },
  style: {
    bg: 'bg-rose-50',
    border: 'border-rose-200',
    badge: 'bg-rose-100',
    badgeText: 'text-rose-700',
    dot: 'bg-rose-400',
  },
  feeling: {
    bg: 'bg-emerald-50',
    border: 'border-emerald-200',
    badge: 'bg-emerald-100',
    badgeText: 'text-emerald-700',
    dot: 'bg-emerald-400',
  },
};

const FALLBACK_COLORS = {
  bg: 'bg-slate-50',
  border: 'border-slate-200',
  badge: 'bg-slate-100',
  badgeText: 'text-slate-700',
  dot: 'bg-slate-400',
};

const CATEGORY_ORDER = ['featured', 'origin', 'style', 'feeling'];

function isUserPremium(user: User): boolean {
  return user.plan_tier === 'premium';
}

export function NamePacksPage({ user, onBack, onNavigateToPremium }: NamePacksPageProps) {
  const [allPacks, setAllPacks] = useState<NamePack[]>([]);
  const [selectedSlugs, setSelectedSlugs] = useState<Set<string>>(new Set([DEFAULT_PACK_SLUG]));
  const [loading, setLoading] = useState(true);
  const [toggling, setToggling] = useState<string | null>(null);

  useEffect(() => {
    async function load() {
      try {
        const [packs, slugs] = await Promise.all([
          getAllPacks(),
          getUserSelectedPacks(user.id),
        ]);
        setAllPacks(packs);
        setSelectedSlugs(new Set(slugs));
      } catch (err) {
        console.error('Failed to load name packs:', err);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, [user.id]);

  async function handleToggle(pack: NamePack) {
    if (isPremiumPack(pack) && !isUserPremium(user)) {
      onNavigateToPremium();
      return;
    }

    if (selectedSlugs.has(pack.slug)) return;

    setToggling(pack.slug);

    try {
      await setUserPack(user.id, pack.slug);
      setSelectedSlugs(new Set([pack.slug]));
    } catch (err) {
      console.error('Failed to select pack:', err);
    } finally {
      setToggling(null);
    }
  }

  const packsByCategory: PacksByCategory = {};
  for (const pack of allPacks) {
    if (!packsByCategory[pack.category]) {
      packsByCategory[pack.category] = [];
    }
    packsByCategory[pack.category].push(pack);
  }

  const categoryOrder = CATEGORY_ORDER.filter(c => packsByCategory[c]);
  const remainingCategories = Object.keys(packsByCategory).filter(c => !CATEGORY_ORDER.includes(c));
  const orderedCategories = [...categoryOrder, ...remainingCategories];

  return (
    <div className="flex-1 min-h-0 flex flex-col bg-parchment overflow-hidden">
      <SubPageHeader title="Name Packs" onBack={onBack} />

      <div className="flex-1 overflow-y-auto px-4 pb-8 space-y-6">
        <div className="pt-1 pb-2">
          <p className="text-sm text-muted-foreground font-display text-center leading-relaxed">
            Choose name packs to customize which names appear in your swipe deck.
          </p>
        </div>

        {loading ? (
          <div className="space-y-4">
            {[1, 2, 3].map(i => (
              <div key={i} className="rounded-2xl border border-border/30 bg-card/40 overflow-hidden animate-pulse">
                <div className="h-12 bg-black/5" />
                <div className="h-12 bg-black/5 border-t border-black/5" />
              </div>
            ))}
          </div>
        ) : (
          orderedCategories.map(category => {
            const packs = packsByCategory[category];
            const colors = CATEGORY_COLORS[category] ?? FALLBACK_COLORS;
            const label = CATEGORY_LABELS[category] ?? category;
            const description = CATEGORY_DESCRIPTIONS[category];

            return (
              <div key={category} className="space-y-2.5">
                <div className="flex items-center gap-2 px-1">
                  <div className={`w-2 h-2 rounded-full ${colors.dot}`} />
                  <p className="text-xs font-display font-semibold text-muted-foreground uppercase tracking-wider">
                    {label}
                  </p>
                  {description && (
                    <p className="text-xs font-display text-muted-foreground">— {description}</p>
                  )}
                </div>

                <div className={`rounded-2xl border ${colors.border} ${colors.bg} overflow-hidden`}>
                  {packs.map((pack, idx) => {
                    const isSelected = selectedSlugs.has(pack.slug);
                    const isDefault = pack.slug === DEFAULT_PACK_SLUG;
                    const isPremium = isPremiumPack(pack);
                    const userHasPremium = isUserPremium(user);
                    const isLast = idx === packs.length - 1;
                    const isLoading = toggling === pack.slug;

                    return (
                      <button
                        key={pack.slug}
                        onClick={() => handleToggle(pack)}
                        disabled={isLoading}
                        className={`w-full flex items-center gap-3 px-4 py-3.5 transition-all active:scale-[0.99] ${
                          !isLast ? 'border-b border-black/5' : ''
                        } ${isSelected ? 'bg-white/60' : 'hover:bg-white/40'} cursor-pointer`}
                      >
                        <div
                          className={`w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 transition-all ${
                            isSelected
                              ? 'border-grass bg-grass'
                              : 'border-black/20 bg-white/50'
                          }`}
                        >
                          {isSelected && <Check size={11} className="text-white" strokeWidth={3} />}
                        </div>

                        <span
                          className={`flex-1 text-left font-display text-sm font-medium ${
                            isSelected ? 'text-foreground' : 'text-foreground/80'
                          }`}
                        >
                          {pack.display_name}
                        </span>

                        {isPremium && !userHasPremium && !isSelected && (
                          <div className="flex items-center gap-1 text-amber-600">
                            <Lock size={12} />
                            <span className="text-xs font-display font-semibold">Premium</span>
                          </div>
                        )}

                        {isSelected && (
                          <span
                            className={`text-xs font-display font-semibold px-2 py-0.5 rounded-full ${colors.badge} ${colors.badgeText}`}
                          >
                            Active
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
            );
          })
        )}

        <div className="mt-2 rounded-2xl border border-border/40 bg-card/60 px-4 py-3.5 flex items-start gap-3">
          <div className="w-8 h-8 rounded-xl bg-grass/10 flex items-center justify-center shrink-0 mt-0.5">
            <Package size={15} className="text-grass" />
          </div>
          <div>
            <p className="text-sm font-display font-semibold text-foreground">More packs coming soon</p>
            <p className="text-xs text-muted-foreground font-display mt-0.5 leading-relaxed">
              We're constantly adding new curated collections. Check back for cultural, themed, and seasonal packs.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
