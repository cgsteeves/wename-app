import { useState } from 'react';
import { SubPageHeader } from './SubPageHeader';

interface PreferencesPageProps {
  onBack: () => void;
}

interface ToggleRowProps {
  label: string;
  description: string;
  checked: boolean;
  onChange: (v: boolean) => void;
  disabled?: boolean;
}

function ToggleRow({ label, description, checked, onChange, disabled = false }: ToggleRowProps) {
  return (
    <div className={`flex items-center justify-between gap-3 py-3.5 ${disabled ? 'opacity-50' : ''}`}>
      <div className="flex-1 min-w-0">
        <p className="font-display font-semibold text-sm text-foreground">{label}</p>
        <p className="text-xs text-muted-foreground font-display mt-0.5">{description}</p>
      </div>
      <button
        role="switch"
        aria-checked={checked}
        disabled={disabled}
        onClick={() => !disabled && onChange(!checked)}
        className={`relative w-11 h-6 rounded-full transition-colors shrink-0 ${
          checked ? 'bg-grass' : 'bg-muted'
        } ${disabled ? 'cursor-not-allowed' : 'cursor-pointer active:scale-95'}`}
      >
        <span
          className={`absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full shadow-sm transition-transform ${
            checked ? 'translate-x-5' : 'translate-x-0'
          }`}
        />
      </button>
    </div>
  );
}

export function PreferencesPage({ onBack }: PreferencesPageProps) {
  const [showOnlyNew, setShowOnlyNew] = useState(false);
  const [excludeDisliked, setExcludeDisliked] = useState(true);
  const [showRanking, setShowRanking] = useState(true);
  const [showPronunciation, setShowPronunciation] = useState(true);

  return (
    <div className="flex-1 min-h-0 flex flex-col bg-parchment overflow-y-auto">
      <SubPageHeader title="Preferences" onBack={onBack} />

      <div className="flex-1 px-4 pb-10 pt-2 space-y-4">
        <div className="bg-card rounded-2xl border border-border/60 shadow-sm px-4 divide-y divide-border/50">
          <ToggleRow
            label="Exclude Disliked Names"
            description="Skip names you've already swiped left on"
            checked={excludeDisliked}
            onChange={setExcludeDisliked}
          />
          <ToggleRow
            label="Show Only New Names"
            description="Only show names you haven't swiped yet"
            checked={showOnlyNew}
            onChange={setShowOnlyNew}
          />
        </div>

        <p className="text-xs font-display font-semibold text-muted-foreground uppercase tracking-wider px-1">
          Card Display
        </p>

        <div className="bg-card rounded-2xl border border-border/60 shadow-sm px-4 divide-y divide-border/50">
          <ToggleRow
            label="Show Popularity Ranking"
            description="Display the name's popularity rank on the card"
            checked={showRanking}
            onChange={setShowRanking}
          />
          <ToggleRow
            label="Show Pronunciation"
            description="Display phonetic pronunciation guide"
            checked={showPronunciation}
            onChange={setShowPronunciation}
          />
        </div>

        <p className="text-xs font-display font-semibold text-muted-foreground uppercase tracking-wider px-1 pt-1">
          Coming Soon
        </p>

        <div className="bg-card rounded-2xl border border-border/60 shadow-sm px-4 divide-y divide-border/50">
          <ToggleRow
            label="Filter by Origin"
            description="Only show names from specific origins"
            checked={false}
            onChange={() => {}}
            disabled
          />
          <ToggleRow
            label="Filter by Length"
            description="Short, medium, or long names only"
            checked={false}
            onChange={() => {}}
            disabled
          />
          <ToggleRow
            label="Filter by Starting Letter"
            description="Focus on names that start with a specific letter"
            checked={false}
            onChange={() => {}}
            disabled
          />
        </div>

        <p className="text-xs text-muted-foreground font-display text-center px-4">
          Advanced filters are available with Premium
        </p>
      </div>
    </div>
  );
}
