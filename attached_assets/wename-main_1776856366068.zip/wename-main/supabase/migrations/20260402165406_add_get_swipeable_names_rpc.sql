/*
  # Add get_swipeable_names RPC function

  ## Summary
  Adds a PostgreSQL function callable via Supabase RPC that returns swipeable names
  for a given set of pack slugs and optional gender filter.

  This replaces the two-step client approach (fetch membership texts, then .in() query)
  with a single server-side join, avoiding URL length limits on large packs.

  ## New Function
  - `get_swipeable_names(pack_slugs text[], gender_filter text)` — returns name rows
    joined from names + name_pack_memberships, deduplicated by uuid.
*/

CREATE OR REPLACE FUNCTION get_swipeable_names(
  pack_slugs text[],
  gender_filter text DEFAULT NULL
)
RETURNS TABLE (
  id uuid,
  text text,
  gender text,
  pronunciation text,
  origin text,
  meaning text,
  nickname text,
  rank integer
)
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
  SELECT DISTINCT ON (n.uuid)
    n.uuid AS id,
    n.name AS text,
    n.gender,
    n.pronunciation,
    n.origin_raw AS origin,
    n.meaning,
    n.nicknames AS nickname,
    CASE
      WHEN n.us_rank ~ '^\d+$' THEN n.us_rank::integer
      ELSE NULL
    END AS rank
  FROM names n
  JOIN name_pack_memberships npm ON npm.name = n.name
  WHERE npm.pack_slug = ANY(pack_slugs)
    AND n.is_active = true
    AND (gender_filter IS NULL OR gender_filter = 'either' OR n.gender = gender_filter)
  ORDER BY n.uuid;
$$;
