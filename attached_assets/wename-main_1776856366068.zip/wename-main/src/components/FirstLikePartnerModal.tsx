import { useEffect, useRef } from 'react';
import { Heart } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { AuthModal } from './auth/AuthModal';
import { setPostAuthRedirect } from '../services/authService';

type Props = {
  open: boolean;
  onClose: () => void;
  onInvitePartner: () => void;
  hasPartner: boolean;
  showAuthModal: boolean;
  onShowAuthModal: () => void;
  onHideAuthModal: () => void;
};

export function FirstLikePartnerModal({
  open,
  onClose,
  onInvitePartner,
  hasPartner,
  showAuthModal,
  onShowAuthModal,
  onHideAuthModal,
}: Props) {
  const { isAuthenticated } = useAuth();
  const pendingInviteRef = useRef(false);

  useEffect(() => {
    if (isAuthenticated && pendingInviteRef.current) {
      pendingInviteRef.current = false;
      onHideAuthModal();
      onClose();
      onInvitePartner();
    }
  }, [isAuthenticated]);

  function handleInvite() {
    if (isAuthenticated) {
      onClose();
      onInvitePartner();
    } else {
      setPostAuthRedirect('partner');
      pendingInviteRef.current = true;
      onShowAuthModal();
    }
  }

  return (
    <>
      {showAuthModal && (
        <AuthModal
          onClose={() => {
            pendingInviteRef.current = false;
            onHideAuthModal();
          }}
          preHeader="You're one step away from matching together"
          title="Invite your partner & start matching"
          body="Create your account to share your link and instantly see your matches together."
        />
      )}

      {open && !showAuthModal && (
        <div
          className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/40 backdrop-blur-sm"
          onClick={onClose}
        >
          <div
            className="bg-[#fdf6ef] rounded-3xl shadow-2xl p-8 w-full max-w-sm mx-4 mb-4 sm:mb-0 text-center"
            onClick={e => e.stopPropagation()}
          >
            <div className="w-16 h-16 rounded-full bg-white flex items-center justify-center mx-auto mb-5 shadow-sm">
              <Heart size={28} className="text-girl-red" fill="currentColor" />
            </div>

            <h2 className="font-hand text-2xl font-bold text-foreground mb-3">
              Find names together
            </h2>
            <p className="font-display text-sm text-muted-foreground leading-relaxed mb-6">
              Invite your partner to swipe on names and discover the ones you both love.
            </p>

            {hasPartner ? (
              <button
                onClick={onClose}
                className="w-full py-4 bg-[#c0392b] text-white rounded-2xl font-display font-bold text-sm flex items-center justify-center gap-2 active:scale-95 transition-all shadow-md"
              >
                <Heart size={16} fill="currentColor" />
                Keep Swiping
              </button>
            ) : (
              <button
                onClick={handleInvite}
                className="w-full py-4 bg-[#c0392b] text-white rounded-2xl font-display font-bold text-sm flex items-center justify-center gap-2 active:scale-95 transition-all shadow-md"
              >
                <Heart size={16} fill="currentColor" />
                Invite Partner
              </button>
            )}

            <button
              onClick={onClose}
              className="mt-3 w-full py-2.5 font-display text-sm text-muted-foreground active:opacity-70 transition-opacity"
            >
              Maybe later
            </button>
          </div>
        </div>
      )}
    </>
  );
}
