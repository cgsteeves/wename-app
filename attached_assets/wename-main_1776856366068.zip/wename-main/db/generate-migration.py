#!/usr/bin/env python3
"""
Generate SQL migration file from enriched name CSVs
"""

boy_names = """Liam,1,Irish,Strong-willed warrior and protector,LEE-um
Noah,2,Hebrew,Rest and comfort,NOH-uh
Oliver,3,Latin|French,Associated with the olive tree symbolizing peace,AH-lih-ver
Theodore,4,Greek,Gift of God,THEE-uh-dor
James,5,Hebrew,Supplanter or one who follows,JAYMZ
Henry,6,Germanic,Ruler of the home,HEN-ree
Mateo,7,Spanish|Hebrew,Gift of God,mah-TAY-oh
Elijah,8,Hebrew,My God is Yahweh,ih-LIE-juh
Lucas,9,Latin,Bringer of light,LOO-kas
William,10,Germanic,Resolute protector,WIL-yum"""

# Read the actual data provided by the user - this is a subset showing the format
# In production, you'd read from the actual CSV files

def escape_sql(text):
    """Escape single quotes for SQL"""
    if text is None:
        return 'NULL'
    return "'" + text.replace("'", "''") + "'"

def generate_insert(name, gender, rank, origin, meaning, pronunciation):
    """Generate a single INSERT statement"""
    return f"({escape_sql(name)}, {escape_sql(gender)}, {rank}, {escape_sql(origin)}, {escape_sql(meaning)}, {escape_sql(pronunciation)})"

print("Script ready - actual migration will be created via SQL")
