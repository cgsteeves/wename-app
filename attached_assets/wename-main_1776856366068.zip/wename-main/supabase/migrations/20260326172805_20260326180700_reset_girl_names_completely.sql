/*
  # Reset Girl Names Completely

  This migration removes ALL girl names and will allow clean re-insertion
  of only the enriched CSV data.

  ## Changes
  1. Deletes all girl names from the database
  2. This prepares for clean insertion of 1000 enriched girl names
*/

-- Delete all girl names
DELETE FROM names WHERE gender = 'girl';