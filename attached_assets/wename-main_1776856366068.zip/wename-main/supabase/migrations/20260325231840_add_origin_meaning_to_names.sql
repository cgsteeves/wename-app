/*
  # Add origin and meaning columns to names table

  1. Changes
    - Add `origin` (text) column to names table - stores the cultural/linguistic origin of the name
    - Add `meaning` (text) column to names table - stores the meaning or significance of the name

  2. Notes
    - Both columns are nullable to maintain backward compatibility
    - No RLS changes needed as existing policies already cover these columns
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'names' AND column_name = 'origin'
  ) THEN
    ALTER TABLE names ADD COLUMN origin text;
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'names' AND column_name = 'meaning'
  ) THEN
    ALTER TABLE names ADD COLUMN meaning text;
  END IF;
END $$;
