import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const emailHtml = (magicLink: string) => `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Log into your WeName Account</title>
</head>
<body style="margin:0;padding:0;background-color:#f2ead8;font-family:Arial,sans-serif;-webkit-font-smoothing:antialiased;">

  <div style="display:none;max-height:0;overflow:hidden;mso-hide:all;">
    Tap to sign in — no password needed!
  </div>

  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color:#f2ead8;">
    <tr>
      <td align="center" style="padding:40px 16px;">

        <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="max-width:520px;background-color:#ece4d0;border-radius:16px;border:1px solid #d4c9a8;box-shadow:0 4px 20px rgba(139,115,85,0.15);">

          <tr>
            <td align="center" style="padding:36px 32px 16px;">
              <img src="https://cwpanlrimbccdgzchkdo.supabase.co/storage/v1/object/public/email%20images/Email%20image.png" alt="Baby logo" width="80" height="80" style="display:block;width:80px;height:80px;border:0;margin-bottom:12px;" />
              <h1 style="margin:0;font-family:Arial,sans-serif;font-size:23px;font-weight:700;color:#3d2b1a;letter-spacing:-0.3px;">
                Sign Up or Log In
              </h1>
            </td>
          </tr>

          <tr>
            <td style="padding:0 32px;">
              <div style="height:1px;background:linear-gradient(90deg,transparent,#c9bfa0,transparent);"></div>
            </td>
          </tr>

          <tr>
            <td style="padding:24px 32px;">
              <p style="margin:0 0 16px;font-family:Arial,sans-serif;font-size:16px;line-height:1.6;color:#7a6a58;">
                Hi there!
              </p>
              <p style="margin:0 0 24px;font-family:Arial,sans-serif;font-size:16px;line-height:1.6;color:#7a6a58;">
                Tap the button below to sign up or log in to your account. This link is magic — no password needed! It'll expire in 10 minutes, so don't wait too long.
              </p>

              <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">
                <tr>
                  <td align="center" style="padding:8px 0 24px;">
                    <a href="${magicLink}" target="_blank" style="display:inline-block;background-color:#2e6aad;color:#ffffff;font-family:Arial,sans-serif;font-size:16px;font-weight:600;text-decoration:none;padding:12px 36px;border-radius:999px;">
                      Log In
                    </a>
                  </td>
                </tr>
              </table>

              <p style="margin:0 0 8px;font-family:Arial,sans-serif;font-size:13px;line-height:1.5;color:#9e8e7e;">
                If the button doesn't work, copy and paste this link into your browser:
              </p>
              <p style="margin:0;font-family:Arial,sans-serif;font-size:12px;line-height:1.5;color:#2e6aad;word-break:break-all;">
                <a href="${magicLink}" style="color:#2e6aad;">${magicLink}</a>
              </p>
            </td>
          </tr>

          <tr>
            <td style="padding:0 32px;">
              <div style="height:1px;background:linear-gradient(90deg,transparent,#c9bfa0,transparent);"></div>
            </td>
          </tr>

          <tr>
            <td style="padding:16px 32px 32px;">
              <p style="margin:0;font-family:Arial,sans-serif;font-size:12px;line-height:1.5;color:#b0a090;text-align:center;">
                If you didn't request this email, you can safely ignore it.<br/>
                &copy; WeName · <a href="https://wename.app" style="color:#b0a090;text-decoration:none;">wename.app</a>
              </p>
            </td>
          </tr>

        </table>
      </td>
    </tr>
  </table>

</body>
</html>`;

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const { email, redirectTo } = await req.json();

    if (!email) {
      return new Response(JSON.stringify({ error: "Email is required" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
      { auth: { autoRefreshToken: false, persistSession: false } }
    );

    const { data, error: linkError } = await supabaseAdmin.auth.admin.generateLink({
      type: "magiclink",
      email: email.trim().toLowerCase(),
      options: {
        redirectTo: redirectTo || "https://wename.app/auth/callback",
      },
    });

    if (linkError || !data?.properties?.action_link) {
      console.error("Failed to generate magic link:", linkError);
      return new Response(
        JSON.stringify({ error: linkError?.message || "Failed to generate magic link" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const magicLink = data.properties.action_link;

    const sendgridApiKey = Deno.env.get("SENDGRID_API_KEY");
    if (!sendgridApiKey) {
      return new Response(JSON.stringify({ error: "SendGrid API key not configured" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const sgResponse = await fetch("https://api.sendgrid.com/v3/mail/send", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${sendgridApiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        personalizations: [{ to: [{ email: email.trim().toLowerCase() }] }],
        from: { email: "admin@wename.app", name: "WeName" },
        subject: "Log in to WeName",
        content: [
          {
            type: "text/plain",
            value: `Hi there!\n\nClick the link below to log in to your WeName account. This link expires in 10 minutes.\n\n${magicLink}\n\nIf you didn't request this, you can ignore this email.\n\n© WeName · wename.app`,
          },
          {
            type: "text/html",
            value: emailHtml(magicLink),
          },
        ],
      }),
    });

    if (!sgResponse.ok) {
      const sgError = await sgResponse.text();
      console.error("SendGrid error:", sgError);
      return new Response(JSON.stringify({ error: "Failed to send email" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({ success: true }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    console.error("Unexpected error:", err);
    return new Response(JSON.stringify({ error: "Internal server error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
