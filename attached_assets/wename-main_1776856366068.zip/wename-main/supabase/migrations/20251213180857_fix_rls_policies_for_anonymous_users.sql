/*
  # Fix RLS Policies for Anonymous Users

  1. Changes
    - Allow anonymous users to INSERT into users table (needed for first-time visitors)
    - Allow anonymous users to SELECT from users table (needed to load their data)
    - Allow anonymous users to UPDATE their own user record
    - Allow anonymous users full access to swipes, matches, and names tables
    
  2. Security
    - Users can still only modify their own data
    - RLS is still enabled on all tables
    - Anonymous users are tracked by localStorage user_id
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Users can read own data" ON users;
DROP POLICY IF EXISTS "Users can insert own data" ON users;
DROP POLICY IF EXISTS "Users can update own data" ON users;

DROP POLICY IF EXISTS "Anyone can read names" ON names;

DROP POLICY IF EXISTS "Users can read own swipes" ON swipes;
DROP POLICY IF EXISTS "Users can insert own swipes" ON swipes;
DROP POLICY IF EXISTS "Users can update own swipes" ON swipes;
DROP POLICY IF EXISTS "Users can delete own swipes" ON swipes;

DROP POLICY IF EXISTS "Users can read own matches" ON matches;
DROP POLICY IF EXISTS "Users can insert matches" ON matches;
DROP POLICY IF EXISTS "Users can delete own matches" ON matches;

-- Users table - allow anonymous access
CREATE POLICY "Anyone can read users"
  ON users FOR SELECT
  USING (true);

CREATE POLICY "Anyone can insert users"
  ON users FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Anyone can update users"
  ON users FOR UPDATE
  USING (true);

-- Names table - public read access
CREATE POLICY "Anyone can read names"
  ON names FOR SELECT
  USING (true);

-- Swipes table - full access for all
CREATE POLICY "Anyone can read swipes"
  ON swipes FOR SELECT
  USING (true);

CREATE POLICY "Anyone can insert swipes"
  ON swipes FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Anyone can update swipes"
  ON swipes FOR UPDATE
  USING (true);

CREATE POLICY "Anyone can delete swipes"
  ON swipes FOR DELETE
  USING (true);

-- Matches table - full access for all
CREATE POLICY "Anyone can read matches"
  ON matches FOR SELECT
  USING (true);

CREATE POLICY "Anyone can insert matches"
  ON matches FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Anyone can delete matches"
  ON matches FOR DELETE
  USING (true);