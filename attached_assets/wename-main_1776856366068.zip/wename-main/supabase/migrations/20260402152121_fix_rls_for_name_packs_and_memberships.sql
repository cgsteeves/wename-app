/*
  # Fix RLS Policies for name_packs and name_pack_memberships

  ## Changes
  - Add public read policy to name_packs (RLS was enabled but no policy existed — blocked all reads)
  - Enable RLS on name_pack_memberships and add public read policy
  - Enable RLS on names table and add public read policy

  All three tables are reference/catalog data that authenticated users must be able to read freely.
*/

-- name_packs: add missing SELECT policy
CREATE POLICY "Anyone can read name packs"
  ON name_packs FOR SELECT
  TO authenticated
  USING (true);

-- name_pack_memberships: enable RLS and allow authenticated reads
ALTER TABLE name_pack_memberships ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read pack memberships"
  ON name_pack_memberships FOR SELECT
  TO authenticated
  USING (true);

-- names: enable RLS and allow authenticated reads
ALTER TABLE names ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read names"
  ON names FOR SELECT
  TO authenticated
  USING (true);
