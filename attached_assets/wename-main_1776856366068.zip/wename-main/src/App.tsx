import { useState, useEffect, useRef } from 'react';
import { useUser } from './hooks/useUser';
import { SwipeView } from './components/SwipeView';
import NamesView from './components/NamesView';
import SettingsPage from './components/SettingsPage';
import BottomNav from './components/BottomNav';
import OnboardingFlow from './components/onboarding/OnboardingFlow';
import { AuthProvider } from './context/AuthContext';
import { AuthCallback } from './components/auth/AuthCallback';
import { JoinView } from './components/JoinView';
import { SettingsSubPage } from './components/settings/SettingsHub';
import { PrivacyPolicyPage } from './components/settings/PrivacyPolicyPage';
import { TermsOfServicePage } from './components/settings/TermsOfServicePage';
import { ContactPage } from './components/settings/ContactPage';
import { DeleteAccountPage } from './components/settings/DeleteAccountPage';

type Tab = 'swipe' | 'names' | 'settings';
type Gender = 'boy' | 'girl' | 'either';

function isAuthCallbackRoute(): boolean {
  return window.location.pathname === '/auth/callback';
}

function isPrivacyRoute(): boolean {
  return window.location.pathname === '/privacy';
}

function isTermsRoute(): boolean {
  return window.location.pathname === '/terms';
}

function isSupportRoute(): boolean {
  return window.location.pathname === '/support';
}

function isDeleteAccountRoute(): boolean {
  return window.location.pathname === '/delete-account';
}

function getJoinToken(): string | null {
  const match = window.location.pathname.match(/^\/join\/(.+)$/);
  return match ? match[1] : null;
}

function getRedirectParam(): string | null {
  return new URLSearchParams(window.location.search).get('redirect');
}

function MainApp() {
  const { user, loading, updateUser, removePartner } = useUser();
  const [activeTab, setActiveTab] = useState<Tab>('swipe');
  const [settingsInitialPage, setSettingsInitialPage] = useState<SettingsSubPage | null>(null);
  const [onboarded, setOnboarded] = useState<boolean>(
    () => localStorage.getItem('onboarded') === 'true'
  );
  const redirectHandled = useRef(false);

  const [showLoader, setShowLoader] = useState(true);
  const loaderTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (!loading) {
      loaderTimer.current = setTimeout(() => setShowLoader(false), 100);
    } else {
      if (loaderTimer.current) clearTimeout(loaderTimer.current);
      setShowLoader(true);
    }
    return () => { if (loaderTimer.current) clearTimeout(loaderTimer.current); };
  }, [loading]);

  useEffect(() => {
    if (loading || !user || !onboarded || redirectHandled.current) return;
    const redirect = getRedirectParam();
    if (redirect === 'partner') {
      redirectHandled.current = true;
      window.history.replaceState({}, '', '/');
      setSettingsInitialPage('partner');
      setActiveTab('settings');
    }
  }, [loading, user, onboarded]);

  const handleOnboardingComplete = (_gender: Gender) => {
    localStorage.setItem('onboarded', 'true');
    setOnboarded(true);
  };

  if (showLoader) {
    return (
      <div className="min-h-screen bg-parchment flex flex-col items-center justify-center gap-4">
        <p className="font-display text-base text-muted-foreground">Loading...</p>
      </div>
    );
  }

  if (!onboarded) {
    return <OnboardingFlow onComplete={handleOnboardingComplete} />;
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-parchment flex items-center justify-center">
        <div className="text-center px-6">
          <h1 className="text-3xl font-bold font-hand text-grass mb-2">
            Welcome to WeName
          </h1>
          <p className="text-foreground font-display text-lg">
            Something went wrong. Please refresh the page.
          </p>
        </div>
      </div>
    );
  }

  const isBoy = user.baby_gender !== 'girl';

  return (
    <div className="h-dvh max-w-md mx-auto flex flex-col bg-parchment">
      <div className="flex-1 min-h-0 flex flex-col">
        {activeTab === 'swipe' && (
          <SwipeView
            user={user}
            updateUser={updateUser}
            onNavigateToPartner={() => {
              setSettingsInitialPage('partner');
              setActiveTab('settings');
            }}
          />
        )}
        {activeTab === 'names' && (
          <NamesView
            user={user}
            updateUser={updateUser}
            onNavigateToPartner={() => {
              setSettingsInitialPage('partner');
              setActiveTab('settings');
            }}
          />
        )}
        {activeTab === 'settings' && (
          <SettingsPage
            user={user}
            onUpdate={updateUser}
            onRemovePartner={removePartner}
            onClose={() => setActiveTab('swipe')}
            initialPage={settingsInitialPage}
          />
        )}
      </div>

      <BottomNav
        active={activeTab}
        onTabChange={(tab) => {
          if (tab !== 'settings') setSettingsInitialPage(null);
          setActiveTab(tab);
        }}
        isBoy={isBoy}
      />
    </div>
  );
}

function App() {
  if (isAuthCallbackRoute()) {
    return (
      <AuthProvider>
        <AuthCallback />
      </AuthProvider>
    );
  }

  if (isPrivacyRoute()) {
    return (
      <div className="h-screen overflow-y-auto bg-parchment">
        <div className="max-w-2xl mx-auto flex flex-col min-h-full">
          <PrivacyPolicyPage onBack={() => { window.location.href = '/'; }} />
        </div>
      </div>
    );
  }

  if (isTermsRoute()) {
    return (
      <div className="h-screen overflow-y-auto bg-parchment">
        <div className="max-w-2xl mx-auto flex flex-col min-h-full">
          <TermsOfServicePage onBack={() => { window.location.href = '/'; }} />
        </div>
      </div>
    );
  }

  if (isSupportRoute()) {
    return (
      <div className="h-screen overflow-y-auto bg-parchment">
        <div className="max-w-2xl mx-auto flex flex-col min-h-full">
          <ContactPage onBack={() => { window.location.href = '/'; }} />
        </div>
      </div>
    );
  }

  if (isDeleteAccountRoute()) {
    return (
      <AuthProvider>
        <div className="h-screen overflow-y-auto bg-parchment">
          <div className="max-w-2xl mx-auto flex flex-col min-h-full">
            <DeleteAccountPage onBack={() => { window.location.href = '/'; }} />
          </div>
        </div>
      </AuthProvider>
    );
  }

  const joinToken = getJoinToken();
  if (joinToken) {
    return <JoinView token={joinToken} />;
  }

  return (
    <AuthProvider>
      <MainApp />
    </AuthProvider>
  );
}

export default App;
