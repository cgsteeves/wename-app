/*
  # Fix names SELECT policy for anonymous users

  ## Problem
  The app uses a custom users table without Supabase Auth sessions, so
  auth.uid() is always NULL. After inserting a user-created name, the
  SELECT policy blocks reading it back because auth.uid() = NULL.

  ## Changes
  - Replace the restrictive SELECT policy with one that allows all users
    to read catalog names (user_created = false) and all user-created names.
    The app enforces its own data access rules via the custom users table.
*/

DROP POLICY IF EXISTS "Users can read catalog and owned or partner names" ON names;

CREATE POLICY "Anyone can read names"
  ON names
  FOR SELECT
  USING (true);
