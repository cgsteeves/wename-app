import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface RequestPayload {
  gender: "boy" | "girl";
  likedNames: string[];
  matchedNames?: string[];
  partnerLikedNames?: string[];
  excludeNames?: string[];
  style?: "classic" | "modern" | "unique" | null;
  lastName?: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const {
      gender,
      likedNames,
      matchedNames = [],
      partnerLikedNames = [],
      excludeNames = [],
      style,
      lastName,
    }: RequestPayload = await req.json();

    const genderLabel = gender === "boy" ? "boy" : "girl";

    const hasLiked = likedNames.length > 0;
    const hasMatched = matchedNames.length > 0;
    const hasPartnerLiked = partnerLikedNames.length > 0;

    let tasteContext = "";
    if (hasMatched && hasLiked) {
      tasteContext = `Both parents have agreed and matched on these names (highest priority for style): ${matchedNames.slice(0, 10).join(", ")}. The user has personally liked: ${likedNames.slice(0, 12).join(", ")}.`;
      if (hasPartnerLiked) {
        tasteContext += ` Their partner has also liked: ${partnerLikedNames.slice(0, 8).join(", ")}.`;
      }
      tasteContext += " Use all of these to understand the couple's shared taste.";
    } else if (hasMatched) {
      tasteContext = `Both parents matched on these names: ${matchedNames.slice(0, 10).join(", ")}. Suggest names with a very similar style and feel.`;
    } else if (hasLiked) {
      tasteContext = `The user has personally liked: ${likedNames.slice(0, 15).join(", ")}.`;
      if (hasPartnerLiked) {
        tasteContext += ` Their partner has liked: ${partnerLikedNames.slice(0, 8).join(", ")}.`;
      }
      tasteContext += " Suggest names with a similar style or feel.";
    } else {
      tasteContext = "Suggest a variety of beautiful, timeless names.";
    }

    let styleContext = "";
    if (style === "classic") {
      styleContext = "Focus on timeless, traditional names with long histories — think elegant and enduring.";
    } else if (style === "modern") {
      styleContext = "Focus on fresh, contemporary names that feel current and stylish.";
    } else if (style === "unique") {
      styleContext = "Focus on rare, distinctive names that stand out — uncommon but beautiful.";
    }

    const lastNameContext = lastName
      ? `The baby's last name will be "${lastName}". Make sure the first names flow well with it.`
      : "";

    const excludeContext = excludeNames.length > 0
      ? `IMPORTANT: Do NOT suggest any of these names (they have already been seen or swiped): ${excludeNames.join(", ")}.`
      : "";

    const prompt = `You are a helpful baby name expert. Suggest 12 unique baby ${genderLabel} names.
${tasteContext}
${styleContext}
${lastNameContext}
${excludeContext}

Return ONLY a JSON array of objects, nothing else. Each object must have:
- "name": the baby name (string)
- "meaning": a short 1-sentence meaning or origin (string)
- "gender": "${genderLabel}" (string, always this exact value)
- "reason": a warm, personalized 1-sentence explanation of why this name suits the parents' taste (string)

Example format:
[{"name":"Aria","meaning":"Italian origin meaning 'air' or 'song'.","gender":"girl","reason":"Like Isla and Luna, Aria has a lyrical, melodic quality you seem to love."}]

Do not include markdown, code blocks, or any text outside the JSON array.`;

    const openaiKey = Deno.env.get("OPENAI_API_KEY");
    if (!openaiKey) {
      return new Response(JSON.stringify({ error: "OpenAI API key not configured" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const openaiRes = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${openaiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [{ role: "user", content: prompt }],
        max_tokens: 1800,
        temperature: 0.8,
        stream: true,
      }),
    });

    if (!openaiRes.ok || !openaiRes.body) {
      const errorText = await openaiRes.text();
      return new Response(JSON.stringify({ error: `OpenAI error: ${openaiRes.status}`, detail: errorText }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const encoder = new TextEncoder();
    const decoder = new TextDecoder();

    const stream = new ReadableStream({
      async start(controller) {
        const reader = openaiRes.body!.getReader();
        let buffer = "";
        let jsonBuffer = "";

        try {
          while (true) {
            const { done, value } = await reader.read();
            if (done) break;

            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split("\n");
            buffer = lines.pop() ?? "";

            for (const line of lines) {
              const trimmed = line.trim();
              if (!trimmed || trimmed === "data: [DONE]") continue;
              if (!trimmed.startsWith("data: ")) continue;

              try {
                const parsed = JSON.parse(trimmed.slice(6));
                const delta = parsed?.choices?.[0]?.delta?.content ?? "";
                if (delta) {
                  jsonBuffer += delta;

                  const items: string[] = [];
                  let depth = 0;
                  let start = -1;

                  for (let i = 0; i < jsonBuffer.length; i++) {
                    const ch = jsonBuffer[i];
                    if (ch === "{") {
                      if (depth === 0) start = i;
                      depth++;
                    } else if (ch === "}") {
                      depth--;
                      if (depth === 0 && start !== -1) {
                        items.push(jsonBuffer.slice(start, i + 1));
                        start = -1;
                      }
                    }
                  }

                  for (const item of items) {
                    try {
                      const obj = JSON.parse(item);
                      if (obj.name && obj.gender) {
                        controller.enqueue(encoder.encode(JSON.stringify(obj) + "\n"));
                      }
                    } catch {
                      // incomplete object, skip
                    }
                  }

                  if (items.length > 0) {
                    const lastBrace = jsonBuffer.lastIndexOf("}");
                    jsonBuffer = lastBrace >= 0 ? jsonBuffer.slice(lastBrace + 1) : jsonBuffer;
                  }
                }
              } catch {
                // malformed SSE chunk, skip
              }
            }
          }
        } finally {
          controller.close();
        }
      },
    });

    return new Response(stream, {
      headers: {
        ...corsHeaders,
        "Content-Type": "text/plain; charset=utf-8",
        "X-Content-Type-Options": "nosniff",
        "Cache-Control": "no-cache",
      },
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: String(err) }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
