import { useState, useEffect, useRef } from 'react';
import { Sparkles, RefreshCw, Plus, Check } from 'lucide-react';
import { supabase } from '../lib/supabase';
import boyCardBg from '../assets/boy-card-rolling-hills.jpg';

interface NameSuggestionsProps {
  user: any;
  likedNames: string[];
  matchedNames?: string[];
  partnerLikedNames?: string[];
  excludeNames?: string[];
  onNameAdded?: (name: string, gender: 'boy' | 'girl') => void;
}

interface Suggestion {
  name: string;
  meaning: string;
  gender: 'boy' | 'girl';
  reason?: string;
}

type StyleFilter = 'classic' | 'modern' | 'unique' | null;

export default function NameSuggestions({
  user,
  likedNames,
  matchedNames = [],
  partnerLikedNames = [],
  excludeNames = [],
  onNameAdded,
}: NameSuggestionsProps) {
  const settingsGender: 'boy' | 'girl' = user.baby_gender === 'girl' ? 'girl' : 'boy';

  const [selectedStyle, setSelectedStyle] = useState<StyleFilter>(null);
  const [suggestions, setSuggestions] = useState<Suggestion[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [addedIds, setAddedIds] = useState<Set<string>>(new Set());
  const [hasLoaded, setHasLoaded] = useState(false);
  const [shownNames, setShownNames] = useState<Set<string>>(new Set());

  const hasFetchedOnMount = useRef(false);

  const selectedGender = settingsGender;
  const isBoy = selectedGender === 'boy';
  const accentColor = isBoy ? 'hsl(214 55% 38%)' : 'hsl(345 55% 40%)';

  useEffect(() => {
    if (!hasFetchedOnMount.current && likedNames.length >= 3) {
      hasFetchedOnMount.current = true;
      fetchSuggestions(false);
    }
  }, [likedNames.length]);

  useEffect(() => {
    if (hasFetchedOnMount.current) {
      fetchSuggestions(false);
    }
  }, [selectedStyle]);

  async function fetchSuggestions(isRefresh: boolean) {
    setLoading(true);
    setError('');
    setSuggestions([]);
    setAddedIds(new Set());

    const allExclude = isRefresh
      ? [...excludeNames, ...Array.from(shownNames)]
      : [...excludeNames];

    try {
      const url = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/suggest-names`;
      const res = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
        },
        body: JSON.stringify({
          gender: selectedGender,
          likedNames,
          matchedNames,
          partnerLikedNames,
          excludeNames: allExclude,
          style: selectedStyle,
          lastName: user.baby_last_name || '',
        }),
      });

      if (!res.ok || !res.body) {
        setError('Could not load suggestions. Please try again.');
        setLoading(false);
        return;
      }

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let lineBuffer = '';
      const fetched: Suggestion[] = [];

      setLoading(false);
      setHasLoaded(true);

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        lineBuffer += decoder.decode(value, { stream: true });
        const lines = lineBuffer.split('\n');
        lineBuffer = lines.pop() ?? '';

        for (const line of lines) {
          const trimmed = line.trim();
          if (!trimmed) continue;
          try {
            const obj: Suggestion = JSON.parse(trimmed);
            if (obj.name && obj.gender) {
              fetched.push(obj);
              setSuggestions((prev) => [...prev, obj]);
              setShownNames((prev) => new Set([...prev, obj.name]));
            }
          } catch {
            // partial line, skip
          }
        }
      }

      if (fetched.length === 0) {
        setError('Could not load suggestions. Please try again.');
      }
    } catch {
      setError('Something went wrong. Please try again.');
      setLoading(false);
    }
  }

  function handleAddToLiked(suggestion: Suggestion) {
    const key = suggestion.name + suggestion.gender;
    console.log('[NameSuggestions] handleAddToLiked clicked:', suggestion.name, suggestion.gender);
    console.log('[NameSuggestions] Current addedIds:', Array.from(addedIds));

    if (addedIds.has(key)) {
      console.log('[NameSuggestions] Already added, skipping');
      return;
    }

    console.log('[NameSuggestions] Adding to addedIds set');
    setAddedIds((prev) => new Set([...prev, key]));
    setShownNames((prev) => new Set([...prev, suggestion.name]));

    // Notify parent component to add the name to local state
    console.log('[NameSuggestions] About to call onNameAdded callback');
    console.log('[NameSuggestions] onNameAdded exists?', !!onNameAdded);
    if (onNameAdded) {
      console.log('[NameSuggestions] Calling onNameAdded with:', suggestion.name, suggestion.gender);
      onNameAdded(suggestion.name, suggestion.gender);
      console.log('[NameSuggestions] onNameAdded callback completed');
    } else {
      console.log('[NameSuggestions] ERROR: onNameAdded callback is not defined!');
    }
  }

  const genderTileStyle = (gender: 'boy' | 'girl', index: number): React.CSSProperties => {
    if (gender === 'girl') {
      return {
        background: `radial-gradient(ellipse 120% 80% at 85% 60%, rgba(255,182,193,0.55) 0%, transparent 55%), radial-gradient(ellipse 80% 100% at 10% 30%, rgba(255,160,170,0.3) 0%, transparent 50%), linear-gradient(135deg, rgba(255,228,225,0.92) 0%, rgba(255,210,215,0.88) 40%, rgba(255,240,242,0.95) 100%)`,
        border: '1px solid hsl(345 50% 68%)',
      };
    }
    return {
      backgroundImage: `url('${boyCardBg}')`,
      backgroundPosition: `center ${(index * 17) % 60}%`,
      backgroundSize: 'cover',
      border: '1px solid hsl(214 50% 62%)',
    };
  };

  const pillBase = 'flex-1 py-1.5 rounded-lg text-xs font-display font-medium border transition-all';
  const pillInactive = 'bg-white/40 text-muted-foreground border-border/30';
  const pillBoy = 'bg-boy/10 text-boy border-boy/20';
  const pillGirl = 'bg-girl-pink/10 text-girl-pink border-girl-pink/20';
  const pillAccent = isBoy ? pillBoy : pillGirl;

  const tooFewNames = likedNames.length < 3;

  return (
    <div className="flex-1 min-h-0 flex flex-col">
      <div className="flex-shrink-0 pt-2 pb-2">
        <div className="flex gap-2">
          {(['classic', 'modern', 'unique'] as const).map((s) => (
            <button
              key={s}
              onClick={() => setSelectedStyle(selectedStyle === s ? null : s)}
              className={`${pillBase} capitalize ${selectedStyle === s ? pillAccent : pillInactive}`}
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      {tooFewNames && !hasLoaded && (
        <div className={`mb-3 rounded-xl p-4 text-center border ${isBoy ? 'bg-boy/5 border-boy/15' : 'bg-girl-pink/5 border-girl-pink/15'}`}>
          <Sparkles size={24} className={`mx-auto mb-2 ${isBoy ? 'text-boy' : 'text-girl-pink'}`} />
          <p className="text-sm font-display text-muted-foreground leading-snug">
            Like a few more names while swiping to unlock personalized suggestions.
          </p>
        </div>
      )}

      <div className="flex-1 min-h-0 overflow-y-auto pb-2">
        {loading ? (
          <div className="space-y-1.5 pt-1">
            {Array.from({ length: 8 }).map((_, i) => (
              <div
                key={i}
                className="relative rounded-lg overflow-hidden animate-pulse"
                style={{
                  border: isBoy ? '1px solid hsl(214 50% 62%)' : '1px solid hsl(345 50% 68%)',
                  background: isBoy
                    ? 'linear-gradient(90deg, hsl(214 72% 93%) 0%, hsl(210 65% 91%) 100%)'
                    : 'linear-gradient(135deg, rgba(255,228,225,0.9) 0%, rgba(255,210,215,0.85) 100%)',
                }}
              >
                <div className="flex items-center gap-2.5 px-3 py-2.5">
                  <div className="flex-1 space-y-1.5">
                    <div
                      className="h-4 rounded w-24"
                      style={{ background: isBoy ? 'hsl(214 40% 80%)' : 'hsl(345 40% 82%)' }}
                    />
                    <div
                      className="h-3 rounded w-40"
                      style={{ background: isBoy ? 'hsl(214 30% 86%)' : 'hsl(345 30% 88%)' }}
                    />
                  </div>
                  <div
                    className="w-7 h-7 rounded-full flex-shrink-0"
                    style={{ background: isBoy ? 'hsl(214 40% 82%)' : 'hsl(345 40% 84%)' }}
                  />
                </div>
              </div>
            ))}
          </div>
        ) : suggestions.length > 0 ? (
          <div className="space-y-1.5 pt-1">
            {suggestions.map((s, index) => {
              const key = s.name + s.gender;
              const added = addedIds.has(key);
              const tileStyle = genderTileStyle(s.gender, index);

              return (
                <div
                  key={key}
                  className="relative rounded-lg font-display shadow-md overflow-hidden"
                  style={{ border: tileStyle.border }}
                >
                  {s.gender === 'boy' && (
                    <>
                      <div className="absolute inset-0 bg-cover bg-center" style={{
                        backgroundImage: tileStyle.backgroundImage,
                        backgroundPosition: tileStyle.backgroundPosition,
                        backgroundSize: tileStyle.backgroundSize,
                      }} />
                      <div className="absolute inset-0" style={{ background: 'linear-gradient(90deg, hsl(214 72% 88% / 0.82) 0%, hsl(210 65% 86% / 0.72) 100%)' }} />
                    </>
                  )}
                  {s.gender === 'girl' && (
                    <div className="absolute inset-0" style={{ background: tileStyle.background as string }} />
                  )}

                  <div className="relative z-10 w-full px-3 py-2.5">
                    <div className="flex items-start gap-2.5">
                      <div className="flex-1 min-w-0">
                        <span
                          className="font-medium text-base block"
                          style={{ color: s.gender === 'girl' ? 'hsl(345 55% 38%)' : 'hsl(214 55% 30%)' }}
                        >
                          {s.name}
                        </span>
                        <span className="text-xs text-muted-foreground leading-snug block pr-1">
                          {s.meaning}
                        </span>
                      </div>
                      <button
                        onClick={() => handleAddToLiked(s)}
                        disabled={added}
                        className={`flex-shrink-0 rounded-lg px-2.5 py-1 text-xs font-display font-medium flex items-center gap-1 transition-all mt-0.5 ${
                          added
                            ? 'bg-green-100 text-green-600 border border-green-300'
                            : s.gender === 'girl'
                            ? 'bg-white/60 text-girl-pink border border-girl-pink/30 hover:bg-girl-pink/10'
                            : 'bg-white/60 text-boy border border-boy/30 hover:bg-boy/10'
                        }`}
                        title={added ? 'Added to Your Picks' : 'Add to My Picks'}
                      >
                        {added ? <><Check size={11} /><span>Added</span></> : <><Plus size={11} /><span>Add to My Picks</span></>}
                      </button>
                    </div>
                    {s.reason && (
                      <div
                        className="mt-2 rounded-lg px-2.5 py-1.5"
                        style={{
                          background: s.gender === 'girl'
                            ? 'rgba(255,160,170,0.12)'
                            : 'rgba(100,140,200,0.10)',
                          border: s.gender === 'girl'
                            ? '1px solid hsl(345 50% 80%)'
                            : '1px solid hsl(214 50% 76%)',
                        }}
                      >
                        <p className="text-[10px] font-display font-semibold mb-0.5 uppercase tracking-wide"
                          style={{ color: s.gender === 'girl' ? 'hsl(345 45% 55%)' : 'hsl(214 45% 48%)' }}
                        >
                          Why you'll like this
                        </p>
                        <p className="text-xs leading-snug flex items-start gap-1"
                          style={{ color: s.gender === 'girl' ? 'hsl(345 45% 46%)' : 'hsl(214 45% 40%)' }}
                        >
                          <Sparkles size={9} className="flex-shrink-0 mt-0.5" />
                          <span>{s.reason}</span>
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}

            <button
              onClick={() => fetchSuggestions(true)}
              disabled={loading}
              className={`w-full mt-2 py-2.5 px-4 rounded-xl font-display font-medium text-sm transition-all flex items-center justify-center gap-2 ${
                isBoy
                  ? 'bg-boy/10 text-boy border border-boy/20 hover:bg-boy/20'
                  : 'bg-girl-pink/10 text-girl-pink border border-girl-pink/20 hover:bg-girl-pink/20'
              } disabled:opacity-50`}
            >
              <RefreshCw size={14} />
              <span>Refresh Suggestions</span>
            </button>
          </div>
        ) : !loading && hasLoaded ? (
          <div className="text-center py-8">
            <p className="text-muted-foreground font-display text-sm mb-3">
              No more new suggestions right now.
            </p>
            <button
              onClick={() => fetchSuggestions(true)}
              className={`py-2 px-5 rounded-xl font-display font-medium text-sm transition-all flex items-center justify-center gap-2 mx-auto ${
                isBoy
                  ? 'bg-boy/10 text-boy border border-boy/20 hover:bg-boy/20'
                  : 'bg-girl-pink/10 text-girl-pink border border-girl-pink/20 hover:bg-girl-pink/20'
              }`}
            >
              <RefreshCw size={14} />
              <span>Try Again</span>
            </button>
          </div>
        ) : !loading && !hasLoaded ? (
          <div className="text-center py-4">
            <button
              onClick={() => fetchSuggestions(false)}
              disabled={loading}
              className={`w-full py-2.5 px-4 rounded-xl font-display font-medium text-sm transition-all flex items-center justify-center gap-2 ${
                isBoy
                  ? 'bg-boy/10 text-boy border border-boy/20 hover:bg-boy/20'
                  : 'bg-girl-pink/10 text-girl-pink border border-girl-pink/20 hover:bg-girl-pink/20'
              } disabled:opacity-50`}
            >
              <Sparkles size={16} />
              <span>Generate Suggestions</span>
            </button>
          </div>
        ) : null}

        {error && (
          <p className="text-xs text-red-400 font-display mt-2 text-center">{error}</p>
        )}
      </div>
    </div>
  );
}
