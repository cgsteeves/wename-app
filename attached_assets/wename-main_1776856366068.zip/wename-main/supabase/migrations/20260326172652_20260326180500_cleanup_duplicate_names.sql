/*
  # Cleanup Duplicate Names

  This migration removes duplicate name entries, keeping only the enriched versions
  that have origin, meaning, and pronunciation data.

  ## Changes
  1. Deletes names without enrichment data (missing origin, meaning, or pronunciation)
  2. This ensures we have exactly 1000 unique names per gender with complete metadata
*/

-- Delete names that don't have the enriched data (origin, meaning, pronunciation)
DELETE FROM names 
WHERE origin IS NULL 
   OR meaning IS NULL 
   OR pronunciation IS NULL;

-- Verify no duplicate ranks remain
-- This should leave us with exactly 1000 boys and 1000 girls