import { supabase, PartnerInvite } from '../lib/supabase';

function generateToken(): string {
  const bytes = new Uint8Array(24);
  crypto.getRandomValues(bytes);
  return Array.from(bytes, b => b.toString(16).padStart(2, '0')).join('');
}

function generateShortCode(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  const bytes = new Uint8Array(8);
  crypto.getRandomValues(bytes);
  for (const b of bytes) {
    code += chars[b % chars.length];
  }
  return code;
}

export function getInviteUrl(token: string): string {
  return `${window.location.origin}/join/${token}`;
}

export async function createInvite(inviterId: string): Promise<PartnerInvite> {
  await supabase
    .from('partner_invites')
    .update({ status: 'expired' })
    .eq('inviter_id', inviterId)
    .eq('status', 'pending');

  const token = generateToken();
  const short_code = generateShortCode();

  const { data, error } = await supabase
    .from('partner_invites')
    .insert({
      token,
      short_code,
      inviter_id: inviterId,
      status: 'pending',
    })
    .select()
    .single();

  if (error) throw error;
  return data as PartnerInvite;
}

export async function getInviteByToken(token: string): Promise<PartnerInvite | null> {
  const { data } = await supabase
    .from('partner_invites')
    .select('*')
    .eq('token', token)
    .eq('status', 'pending')
    .maybeSingle();
  return data as PartnerInvite | null;
}

export async function getInviteByShortCode(code: string): Promise<PartnerInvite | null> {
  const { data } = await supabase
    .from('partner_invites')
    .select('*')
    .eq('short_code', code.toUpperCase())
    .eq('status', 'pending')
    .maybeSingle();
  return data as PartnerInvite | null;
}

export async function acceptInvite(
  invite: PartnerInvite,
  joinerId: string
): Promise<{ success: boolean; error?: string; inviterId?: string }> {
  const { data, error } = await supabase.rpc('accept_partner_invite', {
    p_token: invite.token,
    p_joiner_id: joinerId,
  });

  console.log('[acceptInvite] rpc response:', { data, error });

  if (error) {
    return { success: false, error: `RPC error: ${error.message}` };
  }

  const result = data as { success: boolean; error?: string; inviter_id?: string };
  return {
    success: result.success,
    error: result.error,
    inviterId: result.inviter_id,
  };
}
