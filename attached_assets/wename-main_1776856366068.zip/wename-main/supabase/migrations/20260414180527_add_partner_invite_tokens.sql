/*
  # Add Partner Invite Tokens

  ## Summary
  Introduces a dedicated invite token system for partner linking. This replaces
  the ad-hoc invite_code-in-URL approach with a proper invite record that includes
  a cryptographically safe URL token and a human-friendly short code as a fallback.

  ## New Tables
  - `partner_invites`
    - `id` (uuid, PK) — internal record ID
    - `token` (text, unique) — URL-safe random token, hard to guess (used in /join/:token)
    - `short_code` (text, unique) — 8-char human-friendly code (uppercase alphanum, fallback)
    - `inviter_id` (uuid, FK → users.id) — user who created the invite
    - `invitee_id` (uuid, FK → users.id, nullable) — user who accepted the invite
    - `status` (text) — 'pending' | 'accepted' | 'expired'
    - `created_at` (timestamptz)
    - `expires_at` (timestamptz) — 7 days from creation

  ## Security
  - RLS enabled on `partner_invites`
  - Inviter can read/delete their own pending invites
  - Anyone can read a pending invite by token or short_code (for join flow)
  - Only the invitee (authenticated user joining) can update status to 'accepted'

  ## Notes
  - The existing `invite_code` on the `users` table remains for backwards compatibility
  - New invites are created on-demand when a user taps "Invite Partner"
  - A user may only have one active (pending) invite at a time; old ones are superseded
*/

CREATE TABLE IF NOT EXISTS partner_invites (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  token text UNIQUE NOT NULL,
  short_code text UNIQUE NOT NULL,
  inviter_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  invitee_id uuid REFERENCES users(id) ON DELETE SET NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'expired')),
  created_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz NOT NULL DEFAULT (now() + interval '7 days')
);

CREATE INDEX IF NOT EXISTS partner_invites_token_idx ON partner_invites(token);
CREATE INDEX IF NOT EXISTS partner_invites_short_code_idx ON partner_invites(short_code);
CREATE INDEX IF NOT EXISTS partner_invites_inviter_id_idx ON partner_invites(inviter_id);

ALTER TABLE partner_invites ENABLE ROW LEVEL SECURITY;

-- Inviter can view their own invites
CREATE POLICY "Inviter can view own invites"
  ON partner_invites FOR SELECT
  TO authenticated, anon
  USING (inviter_id = (
    SELECT id FROM users WHERE id = (
      COALESCE(auth.uid(), (current_setting('request.jwt.claims', true)::json->>'sub')::uuid)
    )
    LIMIT 1
  ));

-- Anyone can read a pending invite by token (needed for join flow, even unauthenticated)
CREATE POLICY "Anyone can read pending invites"
  ON partner_invites FOR SELECT
  TO authenticated, anon
  USING (status = 'pending' AND expires_at > now());

-- Inviter can insert their own invites
CREATE POLICY "Inviter can create invites"
  ON partner_invites FOR INSERT
  TO authenticated, anon
  WITH CHECK (
    inviter_id IN (SELECT id FROM users WHERE id = inviter_id)
  );

-- Inviter can delete their own pending invites
CREATE POLICY "Inviter can delete own pending invites"
  ON partner_invites FOR DELETE
  TO authenticated, anon
  USING (inviter_id = (
    SELECT id FROM users WHERE id = inviter_id LIMIT 1
  ));

-- Allow updating status (accepting an invite)
CREATE POLICY "Allow updating invite status"
  ON partner_invites FOR UPDATE
  TO authenticated, anon
  USING (status = 'pending' AND expires_at > now())
  WITH CHECK (status IN ('accepted', 'expired'));
