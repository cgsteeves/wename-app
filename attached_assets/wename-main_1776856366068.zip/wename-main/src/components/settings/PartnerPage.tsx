import { useState, useEffect, useRef } from 'react';
import { Heart, UserMinus, Link2, AlertCircle, Check, Lock } from 'lucide-react';
import { supabase, User } from '../../lib/supabase';
import { SubPageHeader } from './SubPageHeader';
import { InvitePartnerView } from './InvitePartnerView';
import { getInviteByShortCode, acceptInvite } from '../../services/inviteService';
import { AuthModal } from '../auth/AuthModal';
import { useAuth } from '../../context/AuthContext';
import { setPostAuthRedirect } from '../../services/authService';

interface PartnerPageProps {
  user: User;
  onBack: () => void;
  onUpdate: (updates: Partial<User>) => Promise<void>;
  onRemovePartner: () => void;
}

type PartnerInfo = {
  display_name: string;
  baby_gender: 'boy' | 'girl' | 'either';
};

type SubView = 'main' | 'invite';

export function PartnerPage({ user, onBack, onUpdate, onRemovePartner }: PartnerPageProps) {
  const { isAuthenticated } = useAuth();
  const [subView, setSubView] = useState<SubView>('main');
  const [partnerInfo, setPartnerInfo] = useState<PartnerInfo | null>(null);
  const [partnerCode, setPartnerCode] = useState('');
  const [linking, setLinking] = useState(false);
  const [linkError, setLinkError] = useState('');
  const [linkSuccess, setLinkSuccess] = useState(false);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const pendingInviteRef = useRef(false);

  useEffect(() => {
    loadPartnerInfo();
  }, [user.partner_id]);

  useEffect(() => {
    if (isAuthenticated && pendingInviteRef.current) {
      pendingInviteRef.current = false;
      setShowAuthModal(false);
      setSubView('invite');
    }
  }, [isAuthenticated]);

  function handleInviteClick() {
    if (isAuthenticated) {
      setSubView('invite');
    } else {
      setPostAuthRedirect('partner');
      pendingInviteRef.current = true;
      setShowAuthModal(true);
    }
  }

  async function loadPartnerInfo() {
    if (!user.partner_id) {
      setPartnerInfo(null);
      return;
    }
    try {
      const { data } = await supabase
        .from('users')
        .select('display_name, baby_gender')
        .eq('id', user.partner_id)
        .maybeSingle();
      if (data) {
        setPartnerInfo({
          display_name: data.display_name || 'Partner',
          baby_gender: data.baby_gender || 'either',
        });
      }
    } catch (error) {
      console.error('Error loading partner info:', error);
    }
  }

  async function handleJoinWithCode() {
    const code = partnerCode.trim().toUpperCase();
    if (!code) return;
    setLinking(true);
    setLinkError('');
    setLinkSuccess(false);

    try {
      const invite = await getInviteByShortCode(code);

      if (!invite) {
        const { data: partner } = await supabase
          .from('users')
          .select('*')
          .eq('invite_code', code)
          .maybeSingle();

        if (!partner) {
          setLinkError('Invalid code. Please check and try again.');
          setLinking(false);
          return;
        }
        if (partner.id === user.id) {
          setLinkError('You cannot link to yourself.');
          setLinking(false);
          return;
        }
        if (partner.partner_id) {
          setLinkError('This user is already connected with someone else.');
          setLinking(false);
          return;
        }

        await supabase.from('users').update({ partner_id: partner.id }).eq('id', user.id);
        await supabase.from('users').update({ partner_id: user.id }).eq('id', partner.id);
        await onUpdate({ partner_id: partner.id });
        setPartnerCode('');
        setLinkSuccess(true);
        return;
      }

      const result = await acceptInvite(invite, user.id);
      if (!result.success) {
        setLinkError(result.error ?? 'Failed to connect. Please try again.');
        setLinking(false);
        return;
      }

      await onUpdate({ partner_id: invite.inviter_id });
      setPartnerCode('');
      setLinkSuccess(true);
    } catch {
      setLinkError('Failed to link partner. Please try again.');
    } finally {
      setLinking(false);
    }
  }

  if (subView === 'invite') {
    return (
      <InvitePartnerView
        userId={user.id}
        onBack={() => setSubView('main')}
      />
    );
  }

  return (
    <>
    {showAuthModal && (
      <AuthModal
        onClose={() => { setShowAuthModal(false); pendingInviteRef.current = false; }}
        preHeader="You're one step away from matching together"
        title="Invite your partner & start matching"
        body="Create your account to share your link and instantly see your matches together."
      />
    )}
    <div className="flex-1 min-h-0 flex flex-col bg-parchment overflow-y-auto">
      <SubPageHeader title="Partner" onBack={onBack} />

      <div className="flex-1 px-4 pb-10 pt-2 space-y-4">
        {user.partner_id ? (
          <>
            {/* Connected state */}
            <div className="bg-card rounded-2xl border border-border/60 shadow-sm px-4 py-5">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-full bg-rose-100 flex items-center justify-center">
                  <Heart size={22} className="text-rose-500 fill-rose-500" />
                </div>
                <div>
                  <p className="font-display font-bold text-foreground">
                    {partnerInfo?.display_name || 'Partner'}
                  </p>
                  <p className="text-xs text-grass font-display font-semibold">Connected</p>
                </div>
              </div>

              {partnerInfo && (
                <div className="bg-muted rounded-xl px-3 py-2.5 flex items-center justify-between">
                  <span className="text-xs text-muted-foreground font-display">Partner's preference</span>
                  <span className="text-xs font-display font-semibold text-foreground capitalize">
                    {partnerInfo.baby_gender === 'either' ? 'Either' : partnerInfo.baby_gender}
                  </span>
                </div>
              )}
            </div>

            <p className="text-xs text-muted-foreground font-display text-center px-4">
              You and your partner will see matches when you both like the same name.
            </p>

            <div className="pt-4 border-t border-border/50">
              <button
                onClick={onRemovePartner}
                className="w-full py-3 rounded-2xl border border-destructive/30 bg-destructive/5 text-destructive font-display font-semibold text-sm flex items-center justify-center gap-2 active:scale-95 transition-all"
              >
                <UserMinus size={16} />
                Unlink Partner
              </button>
            </div>
          </>
        ) : (
          <>
            {/* Hero / Invite CTA */}
            <div className="bg-gradient-to-br from-rose-50 to-amber-50 border border-rose-100 rounded-2xl px-5 py-6 flex flex-col items-center text-center gap-3">
              <div className="w-14 h-14 rounded-full bg-white shadow-sm flex items-center justify-center">
                <Heart size={26} className="text-rose-400 fill-rose-400" />
              </div>
              <div>
                <h2 className="font-display font-bold text-lg text-foreground mb-1">Find names together</h2>
                <p className="text-sm text-muted-foreground font-display leading-relaxed">
                  Invite your partner to swipe on names and discover the ones you both love.
                </p>
              </div>
              {!isAuthenticated && (
                <div className="flex items-center gap-2 bg-amber-50 border border-amber-200 rounded-xl px-3.5 py-2.5">
                  <Lock size={13} className="text-amber-600 shrink-0" />
                  <p className="font-display text-xs text-amber-700 leading-snug">
                    A free account is required to invite your partner via link.
                  </p>
                </div>
              )}
              <button
                onClick={handleInviteClick}
                className="mt-1 w-full py-3.5 bg-rose-500 text-white rounded-xl font-display font-bold text-sm flex items-center justify-center gap-2 active:scale-95 transition-all shadow-md hover:bg-rose-600"
              >
                <Heart size={16} className="fill-white" />
                Invite Partner
              </button>
            </div>

            {/* Join with code */}
            <div className="bg-card rounded-2xl border border-border/60 shadow-sm px-4 py-5 space-y-3">
              <div>
                <p className="font-display text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-0.5">
                  Join with code
                </p>
                <p className="font-display text-xs text-muted-foreground">
                  Got a code from your partner? Enter it here.
                </p>
              </div>

              {linkSuccess ? (
                <div className="flex items-center gap-2 bg-grass/10 border border-grass/20 rounded-xl px-4 py-3">
                  <Check size={16} className="text-grass shrink-0" />
                  <p className="font-display text-sm text-grass font-semibold">You're connected!</p>
                </div>
              ) : (
                <>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={partnerCode}
                      onChange={(e) => { setPartnerCode(e.target.value.toUpperCase()); setLinkError(''); }}
                      placeholder="Enter code"
                      maxLength={8}
                      className="flex-1 px-3.5 py-3 rounded-xl border border-border bg-background font-mono text-sm uppercase text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring transition"
                    />
                    <button
                      onClick={handleJoinWithCode}
                      disabled={linking || !partnerCode.trim()}
                      className="px-4 py-3 bg-boy text-white rounded-xl font-display font-semibold text-sm flex items-center gap-1.5 disabled:opacity-50 disabled:cursor-not-allowed active:scale-95 transition-all"
                    >
                      <Link2 size={14} />
                      {linking ? 'Joining...' : 'Join'}
                    </button>
                  </div>

                  {linkError && (
                    <div className="flex items-center gap-1.5">
                      <AlertCircle size={12} className="text-destructive shrink-0" />
                      <p className="text-xs text-destructive font-display">{linkError}</p>
                    </div>
                  )}
                </>
              )}
            </div>

            <p className="text-xs text-muted-foreground font-display text-center px-4 pt-1">
              You'll see a match whenever you and your partner both swipe right on the same name.
            </p>
          </>
        )}
      </div>
    </div>
    </>
  );
}
