/*
  # Baby Name Picker - Database Schema

  1. New Tables
    - `users`
      - `id` (uuid, primary key)
      - `display_name` (text) - User's name
      - `baby_last_name` (text) - Baby's last name
      - `baby_gender` (text) - boy, girl, or unknown
      - `partner_id` (uuid) - Reference to partner user
      - `invite_code` (text, unique) - Code for inviting partner
      - `created_at` (timestamp)
    
    - `names`
      - `id` (uuid, primary key)
      - `text` (text) - The baby name
      - `gender` (text) - boy or girl
      - `created_at` (timestamp)
    
    - `swipes`
      - `id` (uuid, primary key)
      - `user_id` (uuid) - User who swiped
      - `name_id` (uuid) - Name that was swiped
      - `liked` (boolean) - True if liked, false if disliked
      - `created_at` (timestamp)
      - Unique constraint on (user_id, name_id)
    
    - `matches`
      - `id` (uuid, primary key)
      - `name_id` (uuid) - The matched name
      - `user_a_id` (uuid) - First user
      - `user_b_id` (uuid) - Second user
      - `gender` (text) - Name gender
      - `created_at` (timestamp)
      - Unique constraint on (name_id, user_a_id, user_b_id)

  2. Security
    - Enable RLS on all tables
    - Users can read/write their own data
    - Users can read partner's swipes for match detection
    - Public read access to names table
*/

-- Users table
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  display_name text DEFAULT '',
  baby_last_name text DEFAULT '',
  baby_gender text DEFAULT 'unknown' CHECK (baby_gender IN ('boy', 'girl', 'unknown')),
  partner_id uuid REFERENCES users(id) ON DELETE SET NULL,
  invite_code text UNIQUE NOT NULL,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_users_invite_code ON users(invite_code);

ALTER TABLE users ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own data"
  ON users FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can insert own data"
  ON users FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Users can update own data"
  ON users FOR UPDATE
  TO authenticated
  USING (true);

-- Names table
CREATE TABLE IF NOT EXISTS names (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  text text NOT NULL,
  gender text NOT NULL CHECK (gender IN ('boy', 'girl')),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE names ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read names"
  ON names FOR SELECT
  TO authenticated
  USING (true);

-- Swipes table
CREATE TABLE IF NOT EXISTS swipes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name_id uuid NOT NULL REFERENCES names(id) ON DELETE CASCADE,
  liked boolean NOT NULL DEFAULT false,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, name_id)
);

CREATE INDEX IF NOT EXISTS idx_swipes_user_id ON swipes(user_id);
CREATE INDEX IF NOT EXISTS idx_swipes_name_id ON swipes(name_id);

ALTER TABLE swipes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own swipes"
  ON swipes FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can insert own swipes"
  ON swipes FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Users can update own swipes"
  ON swipes FOR UPDATE
  TO authenticated
  USING (true);

CREATE POLICY "Users can delete own swipes"
  ON swipes FOR DELETE
  TO authenticated
  USING (true);

-- Matches table
CREATE TABLE IF NOT EXISTS matches (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name_id uuid NOT NULL REFERENCES names(id) ON DELETE CASCADE,
  user_a_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  user_b_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  gender text NOT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE(name_id, user_a_id, user_b_id)
);

CREATE INDEX IF NOT EXISTS idx_matches_user_a ON matches(user_a_id);
CREATE INDEX IF NOT EXISTS idx_matches_user_b ON matches(user_b_id);

ALTER TABLE matches ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own matches"
  ON matches FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can insert matches"
  ON matches FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Users can delete own matches"
  ON matches FOR DELETE
  TO authenticated
  USING (true);

-- Insert starter names (40 names)
INSERT INTO names (text, gender) VALUES
  ('Oliver', 'boy'),
  ('Noah', 'boy'),
  ('Liam', 'boy'),
  ('Elijah', 'boy'),
  ('James', 'boy'),
  ('Lucas', 'boy'),
  ('Mason', 'boy'),
  ('Ethan', 'boy'),
  ('Alexander', 'boy'),
  ('Henry', 'boy'),
  ('Sebastian', 'boy'),
  ('Benjamin', 'boy'),
  ('Theodore', 'boy'),
  ('Owen', 'boy'),
  ('Jackson', 'boy'),
  ('Leo', 'boy'),
  ('Charlie', 'boy'),
  ('Max', 'boy'),
  ('Jack', 'boy'),
  ('William', 'boy')
ON CONFLICT DO NOTHING;

INSERT INTO names (text, gender) VALUES
  ('Emma', 'girl'),
  ('Olivia', 'girl'),
  ('Ava', 'girl'),
  ('Sophia', 'girl'),
  ('Isabella', 'girl'),
  ('Charlotte', 'girl'),
  ('Amelia', 'girl'),
  ('Mia', 'girl'),
  ('Harper', 'girl'),
  ('Evelyn', 'girl'),
  ('Luna', 'girl'),
  ('Ella', 'girl'),
  ('Grace', 'girl'),
  ('Lily', 'girl'),
  ('Scarlett', 'girl'),
  ('Chloe', 'girl'),
  ('Zoe', 'girl'),
  ('Nora', 'girl'),
  ('Hazel', 'girl'),
  ('Aurora', 'girl')
ON CONFLICT DO NOTHING;