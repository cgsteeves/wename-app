import { useState, useEffect } from 'react';
import { supabase, User } from '../lib/supabase';

const USER_ID_KEY = 'baby_picker_user_id';

function generateInviteCode(): string {
  return Math.random().toString(36).substring(2, 10).toUpperCase();
}

export function useUser() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadUser();
  }, []);

  async function loadUser() {
    try {
      let userId = localStorage.getItem(USER_ID_KEY);
      console.log('[useUser] Loading user, stored ID:', userId);

      if (userId) {
        const { data, error } = await supabase
          .from('users')
          .select('*')
          .eq('id', userId)
          .maybeSingle();

        if (error) throw error;

        if (data) {
          console.log('[useUser] Found existing user:', data.id);
          setUser(data as User);
          setLoading(false);
          return;
        } else {
          console.log('[useUser] No user found with stored ID, will create new');
        }
      }

      const inviteCode = new URLSearchParams(window.location.search).get('invite');

      if (inviteCode) {
        const { data: inviter } = await supabase
          .from('users')
          .select('*')
          .eq('invite_code', inviteCode)
          .maybeSingle();

        if (inviter && !inviter.partner_id) {
          const newUser = await createUser();
          if (newUser) {
            await linkPartners(newUser.id, inviter.id);
            await loadUser();
          }
          return;
        }
      }

      const newUser = await createUser();
      if (newUser) {
        setUser(newUser);
      }
    } catch (error) {
      console.error('Error loading user:', error);
    } finally {
      setLoading(false);
    }
  }

  async function createUser(): Promise<User | null> {
    try {
      const { data, error } = await supabase
        .from('users')
        .insert({
          invite_code: generateInviteCode(),
        })
        .select()
        .single();

      if (error) throw error;

      const newUser = data as User;
      localStorage.setItem(USER_ID_KEY, newUser.id);
      console.log('[useUser] Created new user and saved to localStorage:', newUser.id);
      return newUser;
    } catch (error) {
      console.error('Error creating user:', error);
      return null;
    }
  }

  async function linkPartners(userId1: string, userId2: string) {
    try {
      await supabase
        .from('users')
        .update({ partner_id: userId2 })
        .eq('id', userId1);

      await supabase
        .from('users')
        .update({ partner_id: userId1 })
        .eq('id', userId2);
    } catch (error) {
      console.error('Error linking partners:', error);
    }
  }

  async function updateUser(updates: Partial<User>) {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from('users')
        .update(updates)
        .eq('id', user.id)
        .select()
        .single();

      if (error) throw error;
      setUser(data as User);
    } catch (error) {
      console.error('Error updating user:', error);
    }
  }

  async function removePartner() {
    if (!user || !user.partner_id) return;

    try {
      await supabase
        .from('users')
        .update({ partner_id: null })
        .eq('id', user.partner_id);

      await supabase
        .from('users')
        .update({ partner_id: null })
        .eq('id', user.id);

      await supabase
        .from('matches')
        .delete()
        .or(`user_a_id.eq.${user.id},user_b_id.eq.${user.id}`);

      setUser({ ...user, partner_id: null });
    } catch (error) {
      console.error('Error removing partner:', error);
    }
  }

  return { user, loading, updateUser, removePartner, reloadUser: loadUser };
}
