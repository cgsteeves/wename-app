#!/usr/bin/env python3
"""Generate SQL migrations for girl names from CSV data."""

import csv
import sys
from pathlib import Path

def escape_sql_string(s):
    """Escape single quotes in SQL strings."""
    return s.replace("'", "''")

def generate_migration(names, start_rank, end_rank, filename):
    """Generate a migration file for a range of names."""

    # Filter names for this range
    batch_names = [n for n in names if start_rank <= n['rank'] <= end_rank]

    if not batch_names:
        return None

    # Generate SQL
    sql_lines = [
        "/*",
        f"  # Insert Girl Names {start_rank}-{end_rank}",
        "",
        f"  This migration inserts girl names ranked {start_rank}-{end_rank} with enriched data.",
        "",
        "  ## Names Added",
        f"  - Ranks {start_rank}-{end_rank} of popular girl names",
        "  - Complete metadata for each name",
        "*/",
        "",
        "INSERT INTO names (text, gender, rank, origin, meaning, pronunciation) VALUES"
    ]

    # Add each name
    for i, name in enumerate(batch_names):
        comma = "," if i < len(batch_names) - 1 else ";"
        sql_lines.append(
            f"('{escape_sql_string(name['text'])}', 'girl', {name['rank']}, "
            f"'{escape_sql_string(name['origin'])}', '{escape_sql_string(name['meaning'])}', "
            f"'{escape_sql_string(name['pronunciation'])}'){comma}"
        )

    sql_lines.append("ON CONFLICT (text, gender) DO NOTHING;")

    return "\n".join(sql_lines)

# Read CSV data from the document
csv_data = """name,rank,origin,meaning,pronunciation
Olivia,1,Latin,"Olive tree, symbolizing peace.",oh-LIV-ee-uh
Emma,2,Germanic,Whole or universal.,EM-uh
...
""" # This would contain the full CSV, but we'll read from the actual CSV file

# Parse CSV
names = []
csv_file = Path(sys.argv[1]) if len(sys.argv) > 1 else None

if csv_file and csv_file.exists():
    with open(csv_file, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            names.append({
                'text': row['name'],
                'rank': int(row['rank']),
                'origin': row['origin'].replace('|', ', '),
                'meaning': row['meaning'],
                'pronunciation': row['pronunciation']
            })

# Generate migrations for ranges we need (401-1000)
ranges = [
    (401, 600),
    (601, 800),
    (801, 1000)
]

output_dir = Path("supabase/migrations")
output_dir.mkdir(parents=True, exist_ok=True)

for start, end in ranges:
    filename = f"20260326180{start//100 + 2:03d}_insert_girl_names_{start}_{end}"
    sql = generate_migration(names, start, end, filename)

    if sql:
        output_file = output_dir / f"{filename}.sql"
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(sql)
        print(f"Generated: {output_file}")

print(f"\nTotal names processed: {len(names)}")
