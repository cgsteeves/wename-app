import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface OnboardingWelcomeProps {
  onGetStarted: () => void;
  onEnterCode: (code: string) => void;
}

export default function OnboardingWelcome({ onGetStarted, onEnterCode }: OnboardingWelcomeProps) {
  const [showCodeInput, setShowCodeInput] = useState(false);
  const [code, setCode] = useState('');

  return (
    <div className="relative h-dvh max-w-md mx-auto flex flex-col overflow-hidden">
      <img
        src="/onboarding-welcome-bg_(1).jpg"
        alt=""
        className="absolute inset-0 w-full h-full object-cover"
        draggable={false}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-black/5 via-transparent to-black/20" />

      <div className="relative z-10 flex flex-col h-full px-8">
        <div className="flex-1 min-h-[20%]" />

        <motion.div
          className="flex flex-col items-center text-center"
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: 'easeOut' }}
        >
          <div className="bg-[hsl(38,45%,96%)/80] backdrop-blur-md rounded-3xl px-8 py-8 shadow-xl border border-[hsl(35,40%,85%)/70]" style={{ background: 'hsla(38,45%,96%,0.82)', borderColor: 'hsla(35,40%,80%,0.65)' }}>
            <img
              src="/ChatGPT_Image_Mar_30,_2026,_02_49_34_PM.png"
              alt="WeName logo"
              className="w-24 h-24 mx-auto mb-4 drop-shadow-md"
              draggable={false}
            />
            <h1 className="text-3xl font-bold font-display text-foreground leading-tight">
              Welcome to WeName
            </h1>
            <p className="mt-1 text-base font-display text-accent font-semibold">
              Find Your Baby Name Together
            </p>
            <p className="mt-3 text-sm font-display text-muted-foreground max-w-[260px] mx-auto leading-relaxed">
              Swipe names you love, match with your partner, and build a shortlist together.
            </p>
          </div>
        </motion.div>

        <div className="flex-1 min-h-[8%]" />

        <motion.div
          className="flex flex-col gap-3 pb-14"
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.25, ease: 'easeOut' }}
        >
          <button
            onClick={onGetStarted}
            className="w-full py-4 rounded-2xl bg-primary text-primary-foreground font-display font-semibold text-base shadow-lg active:scale-[0.98] transition-transform"
          >
            Get started
          </button>

          <AnimatePresence mode="wait">
            {!showCodeInput ? (
              <motion.button
                key="show-code"
                onClick={() => setShowCodeInput(true)}
                className="w-full py-3.5 rounded-2xl bg-white/70 backdrop-blur-sm border border-white/60 text-foreground/70 font-display text-sm shadow-sm active:scale-[0.98] transition-transform"
                initial={{ opacity: 1 }}
                exit={{ opacity: 0 }}
              >
                I already have a partner code
              </motion.button>
            ) : (
              <motion.div
                key="code-input"
                className="flex gap-2"
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.3 }}
              >
                <input
                  type="text"
                  placeholder="Enter partner code"
                  value={code}
                  onChange={(e) => setCode(e.target.value.toUpperCase())}
                  className="flex-1 px-4 py-3.5 rounded-2xl border border-white/60 bg-white/70 backdrop-blur-sm font-display text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary uppercase tracking-widest text-center shadow-sm"
                  maxLength={8}
                  autoFocus
                />
                <button
                  onClick={() => code.length > 0 && onEnterCode(code)}
                  disabled={code.length === 0}
                  className="px-5 py-3 rounded-2xl bg-accent text-accent-foreground font-display font-semibold text-sm shadow-md disabled:opacity-40 active:scale-[0.98] transition-transform"
                >
                  Join
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </div>
    </div>
  );
}
