import { User as UserIcon, Users, Star, Shield, HelpCircle, Share2, Package } from 'lucide-react';
import { User } from '../../lib/supabase';
import { SettingsRow, SettingsSection } from './SettingsRow';

export type SettingsSubPage = 'profile' | 'partner' | 'premium' | 'account' | 'support' | 'namepacks';

interface SettingsHubProps {
  user: User;
  partnerName: string | null;
  onNavigate: (page: SettingsSubPage) => void;
}

export function SettingsHub({ user, partnerName, onNavigate }: SettingsHubProps) {
  const partnerSummary = user.partner_id
    ? `Connected with ${partnerName || 'Partner'}`
    : 'Invite your partner';

  const profileSummary = user.display_name || 'Set up your profile';
  const premiumSummary = user.plan_tier === 'premium' ? 'Premium plan' : 'Free plan';

  const handleShare = async () => {
    const shareData = {
      title: 'OurBabyName',
      text: 'My partner and I are picking baby names together — check out OurBabyName!',
      url: 'https://ourbabyname.app',
    };
    if (navigator.share) {
      try { await navigator.share(shareData); } catch {}
    } else {
      await navigator.clipboard.writeText(`${shareData.text} ${shareData.url}`);
    }
  };

  const handleReview = () => {
    window.open('https://apps.apple.com/app/ourbabyname', '_blank');
  };

  return (
    <div className="flex-1 min-h-0 flex flex-col bg-parchment overflow-y-auto">
      <div className="px-5 pt-8 pb-4 shrink-0">
        <div className="flex items-center justify-center gap-2 mb-1">
          <span className="text-2xl">🌿</span>
          <h1 className="text-3xl font-bold font-hand text-grass">Settings</h1>
          <span className="text-2xl">☀️</span>
        </div>
        <p className="text-center text-sm text-muted-foreground font-display">
          Customize your experience
        </p>
      </div>

      <div className="flex-1 px-4 pb-8 space-y-5">
        <SettingsSection label="Your Account">
          <SettingsRow
            icon={<UserIcon size={17} className="text-boy" />}
            iconBg="bg-blue-100"
            title="Profile"
            summary={profileSummary}
            onClick={() => onNavigate('profile')}
          />
          <SettingsRow
            icon={<Users size={17} className="text-rose-500" />}
            iconBg="bg-rose-100"
            title="Partner"
            summary={partnerSummary}
            onClick={() => onNavigate('partner')}
          />
        </SettingsSection>

        <SettingsSection label="App">
          <SettingsRow
            icon={<Package size={17} className="text-grass" />}
            iconBg="bg-green-100"
            title="Name Packs"
            summary="Choose your swipe collections"
            onClick={() => onNavigate('namepacks')}
          />
          <SettingsRow
            icon={<Star size={17} className="text-amber-500" />}
            iconBg="bg-amber-100"
            title="Premium"
            summary={premiumSummary}
            onClick={() => onNavigate('premium')}
          />
        </SettingsSection>

        <SettingsSection label="More">
          <SettingsRow
            icon={<Shield size={17} className="text-slate-500" />}
            iconBg="bg-slate-100"
            title="Account"
            summary="Save your progress"
            onClick={() => onNavigate('account')}
          />
          <SettingsRow
            icon={<HelpCircle size={17} className="text-teal-500" />}
            iconBg="bg-teal-100"
            title="Support & Legal"
            summary="Help, privacy, and terms"
            onClick={() => onNavigate('support')}
          />
        </SettingsSection>

        <div className="space-y-3 pt-2">
          <button
            onClick={handleReview}
            className="w-full flex items-center gap-4 px-5 py-4 rounded-2xl bg-amber-50 border border-amber-200 active:scale-[0.98] transition-transform shadow-sm hover:shadow-md"
          >
            <div className="w-10 h-10 rounded-xl bg-amber-100 flex items-center justify-center shrink-0">
              <Star size={18} className="text-amber-500" />
            </div>
            <div className="flex-1 text-left">
              <p className="font-display font-bold text-sm text-amber-900">Leave a Review</p>
              <p className="text-xs text-amber-700 font-display mt-0.5">Your feedback helps us grow</p>
            </div>
            <span className="text-amber-400 text-base">›</span>
          </button>

          <button
            onClick={handleShare}
            className="w-full flex items-center gap-4 px-5 py-4 rounded-2xl bg-green-50 border border-green-200 active:scale-[0.98] transition-transform shadow-sm hover:shadow-md"
          >
            <div className="w-10 h-10 rounded-xl bg-green-100 flex items-center justify-center shrink-0">
              <Share2 size={18} className="text-grass" />
            </div>
            <div className="flex-1 text-left">
              <p className="font-display font-bold text-sm text-green-900">Share with Friends</p>
              <p className="text-xs text-green-700 font-display mt-0.5">Spread the love to expectant parents</p>
            </div>
            <span className="text-green-400 text-base">›</span>
          </button>
        </div>
      </div>

      <img src="/grass-flower-border.png" alt="" className="w-full h-20 object-cover object-bottom shrink-0" />
    </div>
  );
}
