/*
  # Remove Duplicate user_code Column

  1. Changes
    - Drop the `user_code` column since `invite_code` already exists and serves the same purpose
    
  2. Notes
    - The previous migration accidentally added a duplicate column
    - We'll use the existing `invite_code` column for partner linking
*/

-- Drop the duplicate user_code column if it exists
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'users' AND column_name = 'user_code'
  ) THEN
    ALTER TABLE users DROP COLUMN user_code;
  END IF;
END $$;