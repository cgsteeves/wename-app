/*
  # Add Unique Constraint to Names Table

  1. Changes
    - Add unique constraint on (text, gender) combination in names table
    - This prevents duplicate name entries for the same gender
    - Ensures data integrity and prevents confusion in the swipe interface

  2. Notes
    - This constraint allows the same name text to exist for different genders
    - For example, "Jordan" can exist as both a boy name and a girl name
    - If a duplicate already exists, the constraint will prevent future duplicates
*/

-- Add unique constraint to prevent duplicate names for the same gender
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint 
    WHERE conname = 'names_text_gender_unique'
  ) THEN
    ALTER TABLE names 
    ADD CONSTRAINT names_text_gender_unique 
    UNIQUE (text, gender);
  END IF;
END $$;

-- Remove any existing duplicates before applying constraint (if needed)
-- This keeps the oldest entry for each duplicate
DELETE FROM names a
USING names b
WHERE a.id > b.id 
  AND a.text = b.text 
  AND a.gender = b.gender;